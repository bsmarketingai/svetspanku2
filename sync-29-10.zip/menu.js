// Sdílená data hlavní navigace. Používá Hlavicka, MegaMenu, MobilniMenu, patička a Kategorie.
// Struktura kategorií podle Muralu klienta (8. 10. 2026). Odkazy: Kategorie <Nazev>.dc.html#s=<L2>&p=<L3> (stránka L1 = samostatný soubor, L2/L3 přes hash).
export const MENU = [
  {
    "label": "Postele z masivu",
    "slug": "postele",
    "href": "Kategorie_Postele.dc.html",
    "groups": [
      {
        "title": "Postele podle rozměrů",
        "image": "/_blob/9459bc77080c613fe49b26658905c0d9",
        "href": "Kategorie_Postele.dc.html#s=0",
          "items": [
          {
            "label": "80 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=0"
          },
          {
            "label": "90 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=1"
          },
          {
            "label": "100 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=2"
          },
          {
            "label": "120 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=3"
          },
          {
            "label": "140 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=4"
          },
          {
            "label": "160 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=5"
          },
          {
            "label": "180 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=6"
          },
          {
            "label": "200 × 200",
            "href": "Kategorie_Postele.dc.html#s=0&p=7"
          },
          {
            "label": "Prodloužené postele",
            "href": "Kategorie_Postele.dc.html#s=0&p=8"
          },
          {
            "label": "Rozšířené postele pro 3",
            "href": "Kategorie_Postele.dc.html#s=0&p=9"
          }
        ]
      },
      {
        "title": "Manželské postele z masivu",
        "image": "/_blob/cead5c69b22e38051d5480ee3e14c348",
        "href": "Kategorie_Postele.dc.html#s=1",
        "items": [
          {
            "label": "MULTI modulární postele",
            "href": "Kategorie_Postele.dc.html#s=1&p=0"
          },
          {
            "label": "Masivní postele",
            "href": "Kategorie_Postele.dc.html#s=1&p=1"
          },
          {
            "label": "Kontinentální a boxspring postele",
            "href": "Kategorie_Postele.dc.html#s=1&p=2"
          },
          {
            "label": "Postele s úložným prostorem",
            "href": "Kategorie_Postele.dc.html#s=1&p=3"
          },
          {
            "label": "Postele s nočními stolky",
            "href": "Kategorie_Postele.dc.html#s=1&p=4"
          },
          {
            "label": "Čalouněné postele",
            "href": "Kategorie_Postele.dc.html#s=1&p=5"
          },
          {
            "label": "Kombinované postele dřevo a látka",
            "href": "Kategorie_Postele.dc.html#s=1&p=6"
          },
          {
            "label": "Postele s integrovaným LED osvětlením",
            "href": "Kategorie_Postele.dc.html#s=1&p=7"
          }
        ]
      },
      {
        "title": "Čalouněné postele",
        "image": "/_blob/83b97877b4eeaa401d7d46a9fa01dd17",
        "href": "Kategorie_Postele.dc.html#s=2",
        "items": [
          {
            "label": "Čalouněné postele s úložným prostorem",
            "href": "Kategorie_Postele.dc.html#s=2&p=0"
          },
          {
            "label": "Boxspring postele",
            "href": "Kategorie_Postele.dc.html#s=2&p=1"
          },
          {
            "label": "Kombinované postele dřevo a látka",
            "href": "Kategorie_Postele.dc.html#s=2&p=2"
          },
          {
            "label": "Boční panely s LED a USB",
            "href": "Kategorie_Postele.dc.html#s=2&p=3"
          }
        ]
      },
      {
        "title": "Kombinované postele dřevo a čalounění",
        "image": "/_blob/2b07a10ad8eb024c6ef53104343b301c",
        "href": "Kategorie_Postele.dc.html#s=3",
        "items": [
          {
            "label": "Postele s čalouněným čelem",
            "href": "Kategorie_Postele.dc.html#s=3&p=0"
          },
          {
            "label": "Postele s dřevěným čelem",
            "href": "Kategorie_Postele.dc.html#s=3&p=1"
          }
        ]
      },
      {
        "title": "Postele s úložným prostorem",
        "image": "/_blob/3c98d27c417e1d9ccb47b84ffe13df76",
        "href": "Kategorie_Postele.dc.html#s=4",
        "items": [
          {
            "label": "Masivní postele",
            "href": "Kategorie_Postele.dc.html#s=4&p=0"
          },
          {
            "label": "Čalouněné postele",
            "href": "Kategorie_Postele.dc.html#s=4&p=1"
          },
          {
            "label": "Kombinované postele dřevo a látka",
            "href": "Kategorie_Postele.dc.html#s=4&p=2"
          }
        ]
      },
      {
        "title": "Postele s nočními stolky",
        "image": "/_blob/bf9ee623a3c7f6bdd65949a31b2b28ab",
        "href": "Kategorie_Postele.dc.html#s=5",
        "items": [
          {
            "label": "Postele s úložným prostorem",
            "href": "Kategorie_Postele.dc.html#s=5&p=0"
          }
        ]
      },
      {
        "title": "MULTI – modulární postele",
        "image": "/_blob/0e8664e98d4e03179bcd7446fb1b686c",
        "href": "Kategorie_Postele.dc.html#s=6",
        "items": [
          {
            "label": "Rám postele bez úložného prostoru",
            "href": "Kategorie_Postele.dc.html#s=6&p=0"
          },
          {
            "label": "Rám postele s úložným prostorem",
            "href": "Kategorie_Postele.dc.html#s=6&p=1"
          },
          {
            "label": "Čelo postele",
            "href": "Kategorie_Postele.dc.html#s=6&p=2"
          }
        ]
      },
      {
        "title": "Kontinentální a boxspring postele",
        "image": "/_blob/c2272a0e9ca10090147050821599f427",
        "href": "Kategorie_Postele.dc.html#s=7",
        "items": [
          {
            "label": "Boxspring postele",
            "href": "Kategorie_Postele.dc.html#s=7&p=0"
          },
          {
            "label": "Postele s úložným prostorem",
            "href": "Kategorie_Postele.dc.html#s=7&p=1"
          }
        ]
      },
      {
        "title": "Vysoké postele",
        "image": "/_blob/6bd4fa31ef2d1d29da5b49da70514a96",
        "href": "Kategorie_Postele.dc.html#s=8",
        "items": [
          {
            "label": "Masivní postele",
            "href": "Kategorie_Postele.dc.html#s=8&p=0"
          },
          {
            "label": "Čalouněné postele",
            "href": "Kategorie_Postele.dc.html#s=8&p=1"
          },
          {
            "label": "Kombinované postele dřevo a látka",
            "href": "Kategorie_Postele.dc.html#s=8&p=2"
          }
        ]
      },
      {
        "title": "Patrové postele",
        "image": "/_blob/796b776bdf1d4a9bf31b094689547727",
        "href": "Kategorie_Postele.dc.html#s=9",
        "items": []
      },
      {
        "title": "Jednolůžkové postele",
        "image": "/_blob/cbd39695e60222550587109c72c8c52b",
        "href": "Kategorie_Postele.dc.html#s=10",
        "items": [
          {
            "label": "Masivní postele",
            "href": "Kategorie_Postele.dc.html#s=10&p=0"
          },
          {
            "label": "Masivní postele s úložným prostorem",
            "href": "Kategorie_Postele.dc.html#s=10&p=1"
          },
          {
            "label": "Čalouněné postele",
            "href": "Kategorie_Postele.dc.html#s=10&p=2"
          },
          {
            "label": "Kombinované postele dřevo a látka",
            "href": "Kategorie_Postele.dc.html#s=10&p=3"
          }
        ]
      },
      {
        "title": "Dětské postele",
        "image": "/_blob/372550141951862e0591a3e1d5baab98",
        "href": "Kategorie_Postele.dc.html#s=11",
        "items": [
          {
            "label": "Patrové postele",
            "href": "Kategorie_Postele.dc.html#s=11&p=0"
          },
          {
            "label": "Nízké postele",
            "href": "Kategorie_Postele.dc.html#s=11&p=1"
          }
        ]
      },
      {
        "title": "Rozkládací postele / pohovky",
        "image": "/_blob/7248cf07bd3a1e7a83b38dfc5d15d179",
        "href": "Kategorie_Postele.dc.html#s=12",
        "items": []
      },
      {
        "title": "LED osvětlení k posteli",
        "image": "/_blob/8e840d302ff9d7f742f55c829e285d66",
        "href": "Kategorie_Postele.dc.html#s=13",
        "items": []
      },
      {
        "title": "Noční stolky a police",
        "image": "/_blob/68fdf603437e1500e3757d7ca59801f5",
        "href": "Kategorie_Postele.dc.html#s=14",
        "items": []
      },
      {
        "title": "Úložné prostory",
        "image": "/_blob/706482b09df7c053e95817ed6aee84af",
        "href": "Kategorie_Postele.dc.html#s=15",
        "items": []
      },
      {
        "title": "KOMPLETY / Sety",
        "image": "/_blob/dfd6a27a2785e850d62aedd773271533",
        "href": "Kategorie_Postele.dc.html#s=16",
        "items": []
      }
    ],
    "banners": [
      {
        "label": "Black Friday – nakupte se slevami až 60 %",
        "sub": "Jen do 30. listopadu, na vybrané matrace a komplety",
        "href": "#akce",
        "image": "/_blob/edd56eee566f1d974d13fb31f14a8118",
        "imagePos": "30% 30%"
      },
      {
        "label": "Cenově zvýhodněné komplety se slevou až 30 %",
        "sub": "Postel, rošt a matrace v jedné objednávce",
        "href": "#komplety",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd",
        "imagePos": "center 40%"
      }
    ],
    "articles": [
      {
        "title": "Jak správně vybrat matraci a na co si dát pozor?",
        "href": "Clanek.dc.html",
        "image": "/_blob/a4bdfc3ddeb575fee8768a3cf2019524"
      },
      {
        "title": "Postel z masivu, nebo čalouněná? Srovnání po pěti letech",
        "href": "Clanek.dc.html",
        "image": "/_blob/50fbc8ecc5ccb479e539edd24a0148e8"
      }
    ],
    "popular": [
      "Postel LEVITA",
      "Postel s úložným prostorem",
      "Postel 180 × 200",
      "Masiv smrk"
    ],
    "promo": {
      "title": "Výroba na míru",
      "text": "Postel vyrobíme v rozměru, který potřebujete. Do 4 týdnů.",
      "cta": "Nezávazná poptávka",
      "href": "Kategorie.dc.html"
    }
  },
  {
    "label": "Matrace",
    "slug": "matrace",
    "href": "Kategorie_Matrace.dc.html",
    "groups": [
      {
        "title": "Podle rozměrů",
        "href": "Kategorie_Matrace.dc.html#s=0",
          "items": [
          {
            "label": "80 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=0"
          },
          {
            "label": "90 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=1"
          },
          {
            "label": "100 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=2"
          },
          {
            "label": "120 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=3"
          },
          {
            "label": "140 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=4"
          },
          {
            "label": "160 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=5"
          },
          {
            "label": "180 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=6"
          },
          {
            "label": "200 × 200",
            "href": "Kategorie_Matrace.dc.html#s=0&p=7"
          },
          {
            "label": "Prodloužené rozměry",
            "href": "Kategorie_Matrace.dc.html#s=0&p=8"
          },
          {
            "label": "Atypické rozměry",
            "href": "Kategorie_Matrace.dc.html#s=0&p=9"
          }
        ]
      },
      {
        "title": "Podle tuhosti",
        "href": "Kategorie_Matrace_Tuhost.dc.html",
        "items": [
          {
            "label": "Velmi tvrdé matrace",
            "href": "Kategorie_Matrace_Tuhost.dc.html#s=1&p=0"
          },
          {
            "label": "Tvrdé matrace",
            "href": "Kategorie_Matrace_Tuhost.dc.html#s=1&p=1"
          },
          {
            "label": "Středně tvrdé matrace",
            "href": "Kategorie_Matrace_Tuhost.dc.html#s=1&p=2"
          },
          {
            "label": "Mírně tvrdé matrace",
            "href": "Kategorie_Matrace_Tuhost.dc.html#s=1&p=3"
          },
          {
            "label": "Měkké přizpůsobivé matrace",
            "href": "Kategorie_Matrace_Tuhost.dc.html#s=1&p=4"
          },
          {
            "label": "Velmi měkké matrace",
            "href": "Kategorie_Matrace_Tuhost.dc.html#s=1&p=5"
          }
        ]
      },
      {
        "title": "Podle materiálů / typu",
        "href": "Kategorie_Matrace.dc.html#s=2",
        "items": [
          {
            "label": "Pěnové matrace",
            "href": "Kategorie_Matrace.dc.html#s=2&p=0"
          },
          {
            "label": "Matrace s paměťovou pěnou",
            "href": "Kategorie_Matrace.dc.html#s=2&p=1"
          },
          {
            "label": "Matrace s latexem",
            "href": "Kategorie_Matrace.dc.html#s=2&p=2"
          },
          {
            "label": "Taštičkové pružinové matrace",
            "href": "Kategorie_Matrace.dc.html#s=2&p=3"
          },
          {
            "label": "Hybridní matrace",
            "href": "Kategorie_Matrace.dc.html#s=2&p=4"
          },
          {
            "label": "Zdravotní matrace",
            "href": "Kategorie_Matrace.dc.html#s=2&p=5"
          },
          {
            "label": "Antimikrobiální matrace",
            "href": "Kategorie_Matrace.dc.html#s=2&p=6"
          },
          {
            "label": "Matrace bez zón – pro děti",
            "href": "Kategorie_Matrace.dc.html#s=2&p=7"
          },
          {
            "label": "Zónové ortopedické matrace",
            "href": "Kategorie_Matrace.dc.html#s=2&p=8"
          },
          {
            "label": "Vrchní matrace – toppery",
            "href": "Kategorie_Matrace.dc.html#s=2&p=9"
          },
          {
            "label": "Matrace pro 2",
            "href": "Kategorie_Matrace.dc.html#s=2&p=10"
          },
          {
            "label": "Matrace na 90 nocí na zkoušku",
            "href": "Kategorie_Matrace.dc.html#s=2&p=11"
          }
        ]
      },
      {
        "title": "Podle spáče",
        "href": "Kategorie_Matrace.dc.html#s=3",
        "items": [
          {
            "label": "Matrace pro děti",
            "href": "Kategorie_Matrace.dc.html#s=3&p=0"
          },
          {
            "label": "Matrace pro dospělé",
            "href": "Kategorie_Matrace.dc.html#s=3&p=1"
          },
          {
            "label": "Matrace pro seniory",
            "href": "Kategorie_Matrace.dc.html#s=3&p=2"
          },
          {
            "label": "Matrace pro alergiky",
            "href": "Kategorie_Matrace.dc.html#s=3&p=3"
          },
          {
            "label": "Matrace pro páry",
            "href": "Kategorie_Matrace.dc.html#s=3&p=4"
          },
          {
            "label": "Zdravotní matrace",
            "href": "Kategorie_Matrace.dc.html#s=3&p=5"
          },
          {
            "label": "Antimikrobiální matrace",
            "href": "Kategorie_Matrace.dc.html#s=3&p=6"
          },
          {
            "label": "Matrace bez zón – pro děti",
            "href": "Kategorie_Matrace.dc.html#s=3&p=7"
          },
          {
            "label": "Zónové ortopedické matrace",
            "href": "Kategorie_Matrace.dc.html#s=3&p=8"
          },
          {
            "label": "Matrace pro 2",
            "href": "Kategorie_Matrace.dc.html#s=3&p=9"
          }
        ]
      },
      {
        "title": "Matrace pro páry",
        "href": "Kategorie_Matrace.dc.html#s=4",
        "items": []
      },
      {
        "title": "Prémiové matrace",
        "href": "Kategorie_Matrace.dc.html#s=5",
        "items": []
      },
      {
        "title": "Ortopedické matrace",
        "href": "Kategorie_Matrace.dc.html#s=6",
        "items": [
          {
            "label": "Pěnové matrace",
            "href": "Kategorie_Matrace.dc.html#s=6&p=0"
          },
          {
            "label": "Matrace s paměťovou pěnou",
            "href": "Kategorie_Matrace.dc.html#s=6&p=1"
          },
          {
            "label": "Matrace s latexem",
            "href": "Kategorie_Matrace.dc.html#s=6&p=2"
          },
          {
            "label": "Taštičkové pružinové matrace",
            "href": "Kategorie_Matrace.dc.html#s=6&p=3"
          }
        ]
      },
      {
        "title": "Matrace pro alergiky",
        "href": "Kategorie_Matrace.dc.html#s=7",
        "items": []
      },
      {
        "title": "Dětské matrace",
        "href": "Kategorie_Matrace.dc.html#s=8",
        "items": [
          {
            "label": "Matrace do postýlky",
            "href": "Kategorie_Matrace.dc.html#s=8&p=0"
          }
        ]
      },
      {
        "title": "Vrchní matrace – toppery",
        "href": "Kategorie_Matrace.dc.html#s=9",
        "items": []
      },
      {
        "title": "Chrániče matrací",
        "href": "Kategorie_Matrace.dc.html#s=10",
        "items": []
      },
      {
        "title": "Potahy na matrace",
        "href": "Kategorie_Matrace.dc.html#s=11",
        "items": []
      },
      {
        "title": "Levné matrace",
        "href": "Kategorie_Matrace.dc.html#s=12",
        "items": []
      },
      {
        "title": "Průvodce výběrem matrace",
        "href": "Kategorie_Matrace.dc.html#s=13",
        "items": []
      }
    ],
    "popular": [
      "Matrace 180 × 200",
      "Taštičková matrace",
      "Matrace pro bolavá záda",
      "Topper 5 cm"
    ],
    "promo": {
      "title": "Nevíte, kterou matraci?",
      "text": "Osm otázek a doporučíme model podle vaší váhy, polohy spánku a rozpočtu.",
      "cta": "Průvodce výběrem",
      "href": "PruvodceMatrace.dc.html"
    }
  },
  {
    "label": "Rošty",
    "slug": "rosty",
    "href": "Kategorie_Rosty.dc.html",
    "groups": [
      {
        "title": "Lamelové rošty pevné (nepolohovací)",
        "href": "Kategorie_Rosty.dc.html#s=0",
        "items": []
      },
      {
        "title": "Lamelové rošty polohovací (manuálně)",
        "href": "Kategorie_Rosty.dc.html#s=1",
        "items": []
      },
      {
        "title": "Lamelové rošty polohovací (elektricky)",
        "href": "Kategorie_Rosty.dc.html#s=2",
        "items": []
      },
      {
        "title": "Lamelové rošty výklopné (pro úložný prostor)",
        "href": "Kategorie_Rosty.dc.html#s=3",
        "items": []
      },
      {
        "title": "Laťkové rošty",
        "href": "Kategorie_Rosty.dc.html#s=4",
        "items": []
      }
    ],
    "popular": [
      "Lamelový rošt 180 × 200",
      "Polohovací rošt",
      "Rošt s pojezdem"
    ]
  },
  {
    "label": "Výhodné komplety / sety",
    "slug": "komplety",
    "href": "Kategorie_Komplety.dc.html",
    "groups": [
      {
        "title": "Postel + rošt + matrace",
        "href": "Kategorie_Komplety.dc.html#s=0",
        "items": []
      },
      {
        "title": "Postel s úložným prostorem + rošt + matrace",
        "href": "Kategorie_Komplety.dc.html#s=1",
        "items": []
      },
      {
        "title": "Set ložnice",
        "href": "Kategorie_Komplety.dc.html#s=2",
        "items": []
      }
    ],
    "banners": [
      {
        "label": "Black Friday – nakupte se slevami až 60 %",
        "sub": "Jen do 30. listopadu, na vybrané matrace a komplety",
        "href": "#akce",
        "image": "/_blob/edd56eee566f1d974d13fb31f14a8118",
        "imagePos": "30% 30%"
      },
      {
        "label": "Cenově zvýhodněné komplety se slevou až 30 %",
        "sub": "Postel, rošt a matrace v jedné objednávce",
        "href": "#komplety",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd",
        "imagePos": "center 40%"
      }
    ],
    "articles": [
      {
        "title": "Jak správně vybrat matraci a na co si dát pozor?",
        "href": "Clanek.dc.html",
        "image": "/_blob/a4bdfc3ddeb575fee8768a3cf2019524"
      },
      {
        "title": "Postel z masivu, nebo čalouněná? Srovnání po pěti letech",
        "href": "Clanek.dc.html",
        "image": "/_blob/50fbc8ecc5ccb479e539edd24a0148e8"
      }
    ],
    "popular": [
      "Komplet 160 × 200",
      "Sleva 30 % na sety"
    ]
  },
  {
    "label": "Nábytek",
    "slug": "nabytek",
    "href": "Kategorie_Nabytek.dc.html",
    "groups": [
      {
        "title": "Komody",
        "href": "Kategorie_Nabytek.dc.html#s=0",
        "items": [
          {
            "label": "Komody s dveřmi",
            "href": "Kategorie_Nabytek.dc.html#s=0&p=0"
          },
          {
            "label": "Komody se zásuvkami",
            "href": "Kategorie_Nabytek.dc.html#s=0&p=1"
          },
          {
            "label": "Závěsné komody a skříňky",
            "href": "Kategorie_Nabytek.dc.html#s=0&p=2"
          },
          {
            "label": "LED osvětlení komod",
            "href": "Kategorie_Nabytek.dc.html#s=0&p=3"
          }
        ]
      },
      {
        "title": "Skříně",
        "href": "Kategorie_Nabytek.dc.html#s=1",
        "items": [
          {
            "label": "Skříně s posuvnými dveřmi",
            "href": "Kategorie_Nabytek.dc.html#s=1&p=0"
          },
          {
            "label": "Samostatné skříně",
            "href": "Kategorie_Nabytek.dc.html#s=1&p=1"
          },
          {
            "label": "LED osvětlení skříní",
            "href": "Kategorie_Nabytek.dc.html#s=1&p=2"
          }
        ]
      },
      {
        "title": "Dětský nábytek",
        "href": "Kategorie_Nabytek.dc.html#s=2",
        "items": [
          {
            "label": "Dětské postele",
            "href": "Kategorie_Nabytek.dc.html#s=2&p=0"
          },
          {
            "label": "Dětské komody a skříně",
            "href": "Kategorie_Nabytek.dc.html#s=2&p=1"
          },
          {
            "label": "Truhly a boxy",
            "href": "Kategorie_Nabytek.dc.html#s=2&p=2"
          },
          {
            "label": "Úložné prostory",
            "href": "Kategorie_Nabytek.dc.html#s=2&p=3"
          },
          {
            "label": "Závěsné police a skříňky",
            "href": "Kategorie_Nabytek.dc.html#s=2&p=4"
          }
        ]
      },
      {
        "title": "Noční stolky",
        "href": "Kategorie_Nabytek.dc.html#s=3",
        "items": [
          {
            "label": "Noční stolky bez zásuvek",
            "href": "Kategorie_Nabytek.dc.html#s=3&p=0"
          },
          {
            "label": "Noční stolky se zásuvkami",
            "href": "Kategorie_Nabytek.dc.html#s=3&p=1"
          }
        ]
      },
      {
        "title": "Zrcadla",
        "href": "Kategorie_Nabytek.dc.html#s=4",
        "items": []
      },
      {
        "title": "Hodiny",
        "href": "Kategorie_Nabytek.dc.html#s=5",
        "items": []
      },
      {
        "title": "Police",
        "href": "Kategorie_Nabytek.dc.html#s=6",
        "items": []
      }
    ],
    "popular": [
      "Noční stolek masiv",
      "Komoda smrk"
    ]
  },
  {
    "label": "Polštáře / přikrývky",
    "slug": "polstare",
    "href": "Kategorie_Polstare.dc.html",
    "groups": [
      {
        "title": "Polštáře",
        "href": "Kategorie_Polstare.dc.html#s=0",
        "items": [
          {
            "label": "Anatomické polštáře",
            "href": "Kategorie_Polstare.dc.html#s=0&p=0"
          },
          {
            "label": "Klasické polštáře",
            "href": "Kategorie_Polstare.dc.html#s=0&p=1"
          },
          {
            "label": "Dětské polštáře",
            "href": "Kategorie_Polstare.dc.html#s=0&p=2"
          },
          {
            "label": "Ortopedické polštáře",
            "href": "Kategorie_Polstare.dc.html#s=0&p=3"
          },
          {
            "label": "Antialergické polštáře",
            "href": "Kategorie_Polstare.dc.html#s=0&p=4"
          },
          {
            "label": "Dekorační polštáře",
            "href": "Kategorie_Polstare.dc.html#s=0&p=5"
          },
          {
            "label": "HEMPhoria polštáře s obsahem konopí",
            "href": "Kategorie_Polstare.dc.html#s=0&p=6"
          }
        ]
      },
      {
        "title": "Přikrývky",
        "href": "Kategorie_Polstare.dc.html#s=1",
        "items": [
          {
            "label": "Přikrývky s dutým vláknem",
            "href": "Kategorie_Polstare.dc.html#s=1&p=0"
          },
          {
            "label": "HEMPhoria přikrývky s obsahem konopí",
            "href": "Kategorie_Polstare.dc.html#s=1&p=1"
          }
        ]
      },
      {
        "title": "Sety",
        "href": "Kategorie_Polstare.dc.html#s=2",
        "items": [
          {
            "label": "Přikrývka s polštářem",
            "href": "Kategorie_Polstare.dc.html#s=2&p=0"
          },
          {
            "label": "Sety 1+1",
            "href": "Kategorie_Polstare.dc.html#s=2&p=1"
          }
        ]
      }
    ],
    "banners": [
      {
        "label": "Black Friday – nakupte se slevami až 60 %",
        "sub": "Jen do 30. listopadu, na vybrané matrace a komplety",
        "href": "#akce",
        "image": "/_blob/edd56eee566f1d974d13fb31f14a8118",
        "imagePos": "30% 30%"
      },
      {
        "label": "Cenově zvýhodněné komplety se slevou až 30 %",
        "sub": "Postel, rošt a matrace v jedné objednávce",
        "href": "#komplety",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd",
        "imagePos": "center 40%"
      }
    ],
    "articles": [
      {
        "title": "Jak správně vybrat matraci a na co si dát pozor?",
        "href": "Clanek.dc.html",
        "image": "/_blob/a4bdfc3ddeb575fee8768a3cf2019524"
      },
      {
        "title": "Postel z masivu, nebo čalouněná? Srovnání po pěti letech",
        "href": "Clanek.dc.html",
        "image": "/_blob/50fbc8ecc5ccb479e539edd24a0148e8"
      }
    ],
    "popular": [
      "Anatomický polštář",
      "Celoroční přikrývka"
    ]
  },
  {
    "label": "Lůžkoviny / povlečení",
    "slug": "luzkoviny",
    "href": "Kategorie_Luzkoviny.dc.html",
    "groups": [
      {
        "title": "one COLOR jednobarevné povlečení",
        "href": "Kategorie_Luzkoviny.dc.html#s=0",
        "items": [
          {
            "label": "Povlečení na polštáře",
            "href": "Kategorie_Luzkoviny.dc.html#s=0&p=0"
          },
          {
            "label": "Povlečení na přikrývky",
            "href": "Kategorie_Luzkoviny.dc.html#s=0&p=1"
          },
          {
            "label": "Prostěradla na vysoké matrace",
            "href": "Kategorie_Luzkoviny.dc.html#s=0&p=2"
          },
          {
            "label": "Jersey prostěradla",
            "href": "Kategorie_Luzkoviny.dc.html#s=0&p=3"
          }
        ]
      },
      {
        "title": "Povlečení se vzorem",
        "href": "Kategorie_Luzkoviny.dc.html#s=1",
        "items": [
          {
            "label": "Dárkové sety povlečení",
            "href": "Kategorie_Luzkoviny.dc.html#s=1&p=0"
          },
          {
            "label": "Bavlněné povlečení (renforce + perkál)",
            "href": "Kategorie_Luzkoviny.dc.html#s=1&p=1"
          },
          {
            "label": "Saténové povlečení – 100% bavlna",
            "href": "Kategorie_Luzkoviny.dc.html#s=1&p=2"
          },
          {
            "label": "Mako satén",
            "href": "Kategorie_Luzkoviny.dc.html#s=1&p=3"
          },
          {
            "label": "Flanelové povlečení",
            "href": "Kategorie_Luzkoviny.dc.html#s=1&p=4"
          },
          {
            "label": "Dětské povlečení",
            "href": "Kategorie_Luzkoviny.dc.html#s=1&p=5"
          }
        ]
      },
      {
        "title": "Prostěradla a chrániče matrací",
        "href": "Kategorie_Luzkoviny.dc.html#s=2",
        "items": [
          {
            "label": "Chrániče matrací",
            "href": "Kategorie_Luzkoviny.dc.html#s=2&p=0"
          },
          {
            "label": "Prostěradla na vysoké matrace",
            "href": "Kategorie_Luzkoviny.dc.html#s=2&p=1"
          },
          {
            "label": "Jersey prostěradla",
            "href": "Kategorie_Luzkoviny.dc.html#s=2&p=2"
          }
        ]
      },
      {
        "title": "Potahy na matrace",
        "href": "Kategorie_Luzkoviny.dc.html#s=3",
        "items": []
      }
    ],
    "popular": [
      "Povlečení 140 × 200",
      "Napínací prostěradlo"
    ]
  },
  {
    "label": "Akce a výprodej",
    "slug": "akce",
    "href": "Kategorie.dc.html",
    "highlight": true
  }
];

export const UTILITY = [
  {
    "label": "Výroba na míru",
    "href": "#vyroba-na-miru"
  },
  {
    "label": "Jak vybrat matraci",
    "href": "#poradna"
  },
  {
    "label": "Prodejny",
    "href": "#prodejny"
  },
  {
    "label": "Kontakty",
    "href": "Kontakty.dc.html"
  }
];

if (typeof window !== 'undefined') { window.MENU = MENU; window.MENU_UTILITY = UTILITY; }
