// Texty stránek kategorií z Excelu kategorií (sloupce H1, Krátký popis nad výpisem, Dlouhý popis pod výpisem, FAQ). Generuje gen_texty.py, neupravovat ručně.
// Klíč = navržená URL (pole url v menu.js). long = bloky {t:'h'|'p'|'ol'|'ul'}, faq = [{question, answer}].
export const TEXTY = {
 "/postele-z-masivu/": {
  "h1": "Postele z masivu",
  "short": "Postele z masivního buku, jasanu a dubu, které vyrábíme ve vlastní dílně na jižní Moravě. Bez dřevotřísky, v libovolném rozměru a s dovozem i montáží.",
  "long": [
   {
    "t": "p",
    "text": "Masivní postel je nákup na desítky let. Všechny postele Světspánku.cz vyrábíme ve vlastní dílně v Hrušovanech u Brna z masivního buku, jasanu a dubu. Dřevo pochází převážně z českých lesů, menší část ze Slovenska. Dřevotřísku nepoužíváme nikde – ani v roštu úložného prostoru, ani v částech, které nejsou vidět."
   },
   {
    "t": "h",
    "text": "Jak vybrat postel z masivu"
   },
   {
    "t": "p",
    "text": "Začněte rozměrem. Rozměr postele se uvádí podle ložné plochy, tedy podle matrace: pro jednoho dospělého doporučujeme šířku 90–120 cm, pro dva alespoň 160 cm, nejoblíbenější je 180×200 cm. Potom zvolte typ – manželská, jednolůžková, dětská a patrová, rozkládací, čalouněná nebo kontinentální (boxspring) postel – a nakonec výbavu: úložný prostor až 1000 litrů, noční stolky zabudované v čele nebo LED osvětlení se senzorem pohybu."
   },
   {
    "t": "h",
    "text": "Výška postele a dřevina"
   },
   {
    "t": "p",
    "text": "Rámy vyrábíme s výškou bočnice 40, 45 a 50 cm. Nižší postel působí vzdušně, vyšší (50 cm) se snáz opouští a ocení ji senioři i lidé s bolestmi zad. Buk je pevný a světlý, jasan má výraznou kresbu, dub je nejtvrdší a nejdražší. Všechny dřeviny nabízíme v několika odstínech, ve kterých vyrábíme i noční stolky, komody a skříně."
   },
   {
    "t": "h",
    "text": "Postel na míru"
   },
   {
    "t": "p",
    "text": "Protože postele vyrábíme sami, upravíme rozměr, výšku čela i výšku rámu. Rozsah úprav omezuje jen pevnost konstrukce – změna o 10 cm není problém, větší úpravy vždy posoudíme individuálně. Atyp výrobu téměř neprodlouží, běžný termín je zhruba 4–6 týdnů. Do čela lze zabudovat i USB zásuvku."
   },
   {
    "t": "h",
    "text": "Dovoz, montáž a vyzkoušení"
   },
   {
    "t": "p",
    "text": "Postel vám dovezeme a smontujeme. Než se rozhodnete, můžete si postele i matrace vyzkoušet na pěti prodejnách – v Brně, dvakrát v Praze, v Olomouci a v Ostravě. K posteli rovnou vyberte rošt a matraci; jako komplet vyjde celá sestava výhodněji."
   }
  ],
  "faq": [
   {
    "question": "Z jakého dřeva Světspánku.cz vyrábí postele?",
    "answer": "Postele vyrábíme z masivního buku, jasanu a dubu ve vlastní dílně v Hrušovanech u Brna. Dřevo pochází převážně z Česka, menší část ze Slovenska, a dřevotřísku nepoužíváme v žádné části postele."
   },
   {
    "question": "Jaký rozměr postele zvolit pro dva dospělé?",
    "answer": "Pro dva dospělé doporučujeme alespoň 160×200 cm, kdy má každý 80 cm. Nejoblíbenější je postel 180×200 cm, ve které má každý z partnerů 90 cm – tolik jako na běžném jednolůžku."
   },
   {
    "question": "Vyrobíte postel z masivu v atypickém rozměru?",
    "answer": "Ano. Postele vyrábíme sami, takže upravíme rozměr, výšku čela i výšku rámu. Úpravy omezuje jen pevnost konstrukce a atyp prodlouží výrobu jen minimálně – běžný termín je zhruba 4–6 týdnů."
   },
   {
    "question": "Jak vysoká může být postel z masivu?",
    "answer": "Rámy vyrábíme s výškou bočnice 40, 45 nebo 50 cm. Výsledná výška ložné plochy pak závisí na roštu a matraci; nejvyšší varianta s bočnicí 50 cm usnadní vstávání seniorům a lidem s bolestmi zad."
   },
   {
    "question": "Dovezete a smontujete postel?",
    "answer": "Ano, postele z masivu vám dovezeme a smontujeme. Podmínky a cenu dopravy s montáží najdete v informacích o nákupu, případně vám je sdělí prodejci."
   },
   {
    "question": "Kde si mohu postele z masivu vyzkoušet?",
    "answer": "Na pěti prodejnách Světspánku.cz – v Brně, dvakrát v Praze, v Olomouci a v Ostravě. Vystavujeme postele v různých dřevinách a odstínech i matrace, na kterých si můžete lehnout."
   }
  ]
 },
 "/postele-z-masivu/podle-rozmeru/": {
  "h1": "Postele z masivu podle rozměru",
  "short": "Vyberte si postel podle rozměru – od jednolůžka 80×200 po velkorysé dvojlůžko 200×200 cm. Jiný rozměr vyrobíme na míru.",
  "long": [
   {
    "t": "p",
    "text": "Rozměr je první, co při výběru postele řešíte: kolik místa máte v ložnici, kolik lidí bude na posteli spát a jak velkou matraci už případně máte. Postele z masivu nabízíme ve všech běžných šířkách od 80 do 200 cm a ve standardní délce 200 cm, pro vyšší postavy i v prodloužených délkách."
   },
   {
    "t": "p",
    "text": "Rozměr postele se vždy uvádí podle ložné plochy, tedy podle velikosti matrace – postel samotná je o rám větší. Pro dva dospělé doporučujeme alespoň 160×200 cm, pro jednoho dospělého 90–120 cm na šířku. Pokud vám žádný rozměr nesedí, vyrobíme postel na míru ve vlastní dílně."
   }
  ],
  "faq": [
   {
    "question": "Je rozměr postele uvedený včetně rámu?",
    "answer": "Ne. Rozměr postele odpovídá ložné ploše, tedy velikosti matrace. Vnější rozměr postele je o rám a čelo větší – přesné vnější rozměry najdete v detailu každého modelu."
   },
   {
    "question": "Jaký rozměr postele je nejlepší pro dva?",
    "answer": "Pohodlné minimum pro dva dospělé je 160×200 cm. Kdo se v noci hodně otáčí nebo má větší ložnici, ocení 180×200 cm, a nejvíc místa nabízí postel 200×200 cm."
   },
   {
    "question": "Vyrobíte postel v rozměru, který tu není?",
    "answer": "Ano. Postele z masivu vyrábíme ve vlastní dílně, takže zvládneme i atypický rozměr – stačí ho napsat do dotazu u vybraného modelu a my ověříme, zda ho konstrukce dovolí."
   }
  ]
 },
 "/postele-z-masivu/postele-80x200/": {
  "h1": "Postele 80×200 cm z masivu",
  "short": "Jednolůžko 80×200 cm se hodí do dětského a studentského pokoje nebo do menší ložnice, kde je potřeba ušetřit místo.",
  "long": [
   {
    "t": "p",
    "text": "Postel 80×200 cm je nejužší běžné jednolůžko. Hodí se do dětského a studentského pokoje, do pokoje pro hosty a do podkrovních místností, kde rozhoduje každý centimetr. Pro dospělého, který spí sám každou noc, je spíš úzká – tam doporučujeme 90 nebo 100 cm."
   },
   {
    "t": "h",
    "text": "Co k posteli 80×200 patří"
   },
   {
    "t": "p",
    "text": "Do postele patří jeden rošt a jedna matrace 80×200 cm. Dvě postele 80×200 vedle sebe vytvoří dvojlůžko 160×200 cm, ve kterém má každý vlastní rám. Pod postel lze vložit úložný prostor na lůžkoviny nebo hračky."
   },
   {
    "t": "h",
    "text": "Kolik místa postel zabere"
   },
   {
    "t": "p",
    "text": "Vnější rozměr je o rám a čelo větší než 80×200 cm – počítejte zhruba s 90–95 cm na šířku. Přesné rozměry najdete u každého modelu. I nejužší postel stojí na masivní konstrukci z buku, jasanu nebo dubu, která se nebude viklat ani po letech."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je postel 80×200 cm vhodná?",
    "answer": "Postel 80×200 cm je vhodná pro děti, studenty a do pokojů pro hosty. Dospělému, který na posteli spí každou noc, doporučujeme spíš šířku 90 nebo 100 cm."
   },
   {
    "question": "Jaký rošt a matraci k posteli 80×200?",
    "answer": "K posteli 80×200 cm patří jeden rošt a jedna matrace ve stejném rozměru 80×200 cm. Oba najdete v kategoriích Rošty a Matrace podle rozměru."
   }
  ]
 },
 "/postele-z-masivu/postele-90x200/": {
  "h1": "Postele 90×200 cm z masivu",
  "short": "Nejčastější rozměr jednolůžka – postel 90×200 cm z masivu pro dospívající i dospělé.",
  "long": [
   {
    "t": "p",
    "text": "Postel 90×200 cm je nejběžnější jednolůžko – a zároveň nejvíc hledaný rozměr matrací. Je dost široká pro pohodlný spánek dospělého a vejde se i do menšího pokoje."
   },
   {
    "t": "h",
    "text": "Dvě postele 90×200 = dvojlůžko 180×200"
   },
   {
    "t": "p",
    "text": "Dvě postele 90×200 vedle sebe tvoří plnohodnotné dvojlůžko 180×200 cm. Je to praktické řešení, pokud chce každý z partnerů vlastní postel, jinou matraci nebo polohovací rošt, nebo pokud postele později rozdělíte do dvou pokojů."
   },
   {
    "t": "h",
    "text": "Matrace 90×200 a 30 nocí jistoty"
   },
   {
    "t": "p",
    "text": "Na vybrané matrace 90×200 cm platí služba 30 nocí jistoty: pokud vám tvrdost nesedí, do 30 nocí vám jádro zdarma vyměníme na kterékoli prodejně. K posteli patří jeden rošt 90×200."
   },
   {
    "t": "h",
    "text": "Výbava"
   },
   {
    "t": "p",
    "text": "Postele 90×200 nabízíme s úložným prostorem i bez něj a ve výškách bočnice 40, 45 a 50 cm."
   }
  ],
  "faq": [
   {
    "question": "Lze dvě postele 90×200 spojit do dvojlůžka?",
    "answer": "Ano. Dvě jednolůžka 90×200 cm vedle sebe vytvoří lůžko 180×200 cm a každý z partnerů pak může mít jinou matraci i jiný rošt."
   },
   {
    "question": "Platí na matrace 90×200 služba 30 nocí jistoty?",
    "answer": "Ano, u vybraných matrací v rozměru 90×200 cm vám do 30 nocí zdarma vyměníme jádro za jinou tvrdost ze stejné řady na kterékoli naší prodejně."
   }
  ]
 },
 "/postele-z-masivu/postele-100x200/": {
  "h1": "Postele 100×200 cm z masivu",
  "short": "Postel 100×200 cm – o kus širší jednolůžko pro ty, kdo chtějí při spánku víc místa.",
  "long": [
   {
    "t": "p",
    "text": "Postel 100×200 cm je o kus širší jednolůžko pro dospělé, kterým je 90 cm málo, ale dvojlůžko by v pokoji zabralo zbytečně moc místa. Deset centimetrů navíc oceníte hlavně, pokud se v noci často otáčíte nebo spíte roztažení."
   },
   {
    "t": "h",
    "text": "Rošt, matrace a dvojlůžko 200×200"
   },
   {
    "t": "p",
    "text": "K posteli patří jeden rošt a jedna matrace 100×200 cm. Dvě postele 100×200 vedle sebe tvoří velkorysé dvojlůžko 200×200 cm."
   },
   {
    "t": "h",
    "text": "Výbava"
   },
   {
    "t": "p",
    "text": "Postele 100×200 vyrábíme z masivního buku, jasanu a dubu, s úložným prostorem i bez něj a v několika výškách rámu."
   }
  ],
  "faq": [
   {
    "question": "Je postel 100×200 vhodná pro jednoho dospělého?",
    "answer": "Ano. Postel 100×200 cm je pohodlnější varianta klasického jednolůžka 90×200 – ocení ji hlavně lidé, kteří se v noci hodně otáčejí nebo chtějí víc prostoru."
   },
   {
    "question": "Seženu k posteli 100×200 matraci a rošt?",
    "answer": "Ano, matrace i rošty 100×200 cm jsou ve standardní nabídce Světspánku.cz a vyberete je v kategoriích Matrace a Rošty podle rozměru."
   }
  ]
 },
 "/postele-z-masivu/postele-120x200/": {
  "h1": "Postele 120×200 cm z masivu",
  "short": "Postel 120×200 cm – široké jednolůžko, ve kterém se pohodlně vyspí i dospělý se spoustou místa.",
  "long": [
   {
    "t": "p",
    "text": "Postel 120×200 cm stojí na pomezí jednolůžka a malého dvojlůžka. Pro jednoho dospělého je velmi pohodlná, pro dva je na každodenní spaní těsná – každý by měl jen 60 cm."
   },
   {
    "t": "h",
    "text": "Pro koho se hodí"
   },
   {
    "t": "p",
    "text": "Postel 120×200 se hodí do menších ložnic, garsoniér a pokojů dospívajících, kteří vyrostli z dětské postele. Je to také dobrá volba pro jednoho dospělého, který chce maximum místa, ale nemá prostor na dvojlůžko."
   },
   {
    "t": "h",
    "text": "Rošt a matrace"
   },
   {
    "t": "p",
    "text": "K posteli obvykle patří jeden rošt v celé šíři a jedna matrace 120×200 cm. Matraci vybírejte podle své hmotnosti a polohy spánku."
   }
  ],
  "faq": [
   {
    "question": "Vyspí se na posteli 120×200 dva lidé?",
    "answer": "Krátkodobě ano, ale každý má jen 60 cm. Na každodenní spaní dvou dospělých doporučujeme alespoň postel 160×200 cm."
   },
   {
    "question": "Jakou matraci k posteli 120×200?",
    "answer": "Do postele 120×200 cm patří jedna matrace 120×200 cm. Tvrdost vybírejte podle hmotnosti a polohy spánku – pomůže vám průvodce výběrem matrace."
   }
  ]
 },
 "/postele-z-masivu/postele-140x200/": {
  "h1": "Postele 140×200 cm z masivu",
  "short": "Postel 140×200 cm – nejmenší dvojlůžko pro páry, kterým nevadí spát blízko sebe, nebo pro jednoho s maximem pohodlí.",
  "long": [
   {
    "t": "p",
    "text": "Postel 140×200 cm je nejmenší rozměr, kterému se běžně říká dvojlůžko. Hodí se do menších ložnic a pro páry, které rády spí blízko sebe; pro jednoho dospělého je to naopak velmi prostorné lůžko."
   },
   {
    "t": "h",
    "text": "Jedna matrace, nebo dvě?"
   },
   {
    "t": "p",
    "text": "Do postele 140×200 se nejčastěji dává jedna matrace přes celou šíři, která nemá uprostřed spáru. Pokud každý z partnerů potřebuje jinou tvrdost, zvolte matraci pro páry Spring Variant s rozdílnou tvrdostí každé poloviny. Rošt může být jeden v celé šíři, nebo dva 70×200 cm."
   },
   {
    "t": "h",
    "text": "Výbava"
   },
   {
    "t": "p",
    "text": "Postel můžete doplnit úložným prostorem nebo vybrat model s nočními stolky v čele."
   }
  ],
  "faq": [
   {
    "question": "Je postel 140×200 dost velká pro dva?",
    "answer": "Pro páry, kterým nevadí spát blízko sebe, ano – každý má 70 cm. Kdo chce víc prostoru, ať zvolí postel 160×200 nebo 180×200 cm."
   },
   {
    "question": "Jakou matraci do postele 140×200?",
    "answer": "Nejčastěji jednu matraci 140×200 cm bez spáry. Pokud chce každý z partnerů jinou tvrdost, doporučujeme matraci pro páry Spring Variant s rozdílnou tvrdostí polovin."
   }
  ]
 },
 "/postele-z-masivu/postele-160x200/": {
  "h1": "Postele 160×200 cm z masivu",
  "short": "Manželská postel 160×200 cm – nejčastější volba pro pohodlný spánek dvou dospělých.",
  "long": [
   {
    "t": "p",
    "text": "Postel 160×200 cm je zlatá střední cesta mezi pohodlím a velikostí ložnice. Každý ze dvou spáčů má 80 cm a postel se vejde i do běžné panelákové ložnice."
   },
   {
    "t": "h",
    "text": "Dvě matrace 80×200"
   },
   {
    "t": "p",
    "text": "Do postele 160×200 se obvykle dávají dva rošty a dvě matrace 80×200 cm, takže si každý zvolí vlastní tvrdost a navzájem se méně rušíte. Kdo nechce spáru, může zvolit jednu matraci 160×200 cm nebo spáru zakrýt topperem."
   },
   {
    "t": "h",
    "text": "Kolik místa v ložnici"
   },
   {
    "t": "p",
    "text": "Vnější rozměr postele je o rám a čelo větší. Kolem postele počítejte alespoň s 50–60 cm volného místa, aby se dalo pohodlně vstávat a ustlat."
   },
   {
    "t": "h",
    "text": "Výbava"
   },
   {
    "t": "p",
    "text": "Pod postel se vejde úložný prostor, k dispozici jsou i modely s nočními stolky v čele a s LED osvětlením."
   }
  ],
  "faq": [
   {
    "question": "Jaké matrace se dávají do postele 160×200?",
    "answer": "Nejčastěji dvě matrace 80×200 cm na dvou roštech, takže každý z partnerů může mít jinou tvrdost. Pokud nechcete spáru, zvolte jednu matraci 160×200 cm."
   },
   {
    "question": "Vejde se postel 160×200 do menší ložnice?",
    "answer": "Většinou ano. Počítejte s vnějším rozměrem o rám a čelo větším a kolem postele alespoň s 50–60 cm volného místa pro pohodlné vstávání."
   }
  ]
 },
 "/postele-z-masivu/postele-180x200/": {
  "h1": "Postele 180×200 cm z masivu",
  "short": "Postel 180×200 cm – nejoblíbenější rozměr manželské postele s dostatkem místa pro oba.",
  "long": [
   {
    "t": "p",
    "text": "Postel 180×200 cm je nejhledanější rozměr manželské postele. Každý ze dvou spáčů má 90 cm – tedy tolik jako na běžném jednolůžku – a v noci se navzájem nerušíte."
   },
   {
    "t": "h",
    "text": "Dvě matrace 90×200 a 30 nocí jistoty"
   },
   {
    "t": "p",
    "text": "Do postele 180×200 se dávají dva rošty a dvě matrace 90×200 cm. Každý si zvolí vlastní tvrdost a na vybrané matrace 90×200 platí služba 30 nocí jistoty s bezplatnou výměnou jádra. Každá polovina může mít i jiný rošt, třeba polohovací."
   },
   {
    "t": "h",
    "text": "Úložný prostor až 1000 litrů"
   },
   {
    "t": "p",
    "text": "Pod postel 180×200 se vejde masivní úložný prostor o objemu až zhruba 1000 litrů – na lůžkoviny, přikrývky i sezónní oblečení. Přístup zajišťují dva výklopné rošty."
   },
   {
    "t": "h",
    "text": "Kolik místa v ložnici"
   },
   {
    "t": "p",
    "text": "Vnější rozměr je o rám a čelo větší, kolem postele počítejte s 50–60 cm volného místa."
   },
   {
    "t": "h",
    "text": "Výška postele a dřevina"
   },
   {
    "t": "p",
    "text": "Rám postele 180×200 vyrábíme s bočnicí 40, 45 nebo 50 cm. Vyšší postel se snáz opouští, nižší působí v ložnici vzdušněji. Vybírat můžete z masivního buku, jasanu a dubu v několika odstínech, ve kterých vyrobíme i noční stolky a komodu."
   },
   {
    "t": "h",
    "text": "Postel 180×200 jako komplet"
   },
   {
    "t": "p",
    "text": "Postel s dvěma rošty a dvěma matracemi 90×200 koupíte i jako výhodný komplet – vše rozměrově sedí a vyjde levněji než nákup zvlášť."
   }
  ],
  "faq": [
   {
    "question": "Proč je postel 180×200 nejoblíbenější?",
    "answer": "Každý z partnerů má 90 cm, tedy plnohodnotné jednolůžko, a nikdo se nemusí přizpůsobovat. Zároveň se postel 180×200 cm vejde do většiny běžných ložnic."
   },
   {
    "question": "Jaký úložný prostor se vejde pod postel 180×200?",
    "answer": "Pod postel 180×200 cm se vejde masivní úložný prostor o objemu až zhruba 1000 litrů, ke kterému se dostanete přes dva výklopné rošty."
   },
   {
    "question": "Kolik matrací a roštů patří do postele 180×200?",
    "answer": "Do postele 180×200 cm patří dvě matrace 90×200 cm a dva rošty 90×200 cm. Na vybrané matrace 90×200 platí 30 nocí jistoty s výměnou tvrdosti zdarma."
   }
  ]
 },
 "/postele-z-masivu/postele-200x200/": {
  "h1": "Postele 200×200 cm z masivu",
  "short": "Postel 200×200 cm – velkorysé dvojlůžko pro ty, kdo chtějí v ložnici maximum prostoru.",
  "long": [
   {
    "t": "p",
    "text": "Postel 200×200 cm je čtvercové dvojlůžko pro velké ložnice a pro všechny, kdo chtějí při spánku opravdu hodně místa – třeba když k vám občas přijdou spát děti."
   },
   {
    "t": "h",
    "text": "Matrace a rošty"
   },
   {
    "t": "p",
    "text": "Do postele 200×200 se obvykle dávají dva rošty a dvě matrace 100×200 cm, případně jedna matrace přes celou šíři. Masivní konstrukce z buku, jasanu nebo dubu unese i velkou ložnou plochu bez prohýbání."
   },
   {
    "t": "h",
    "text": "Ještě větší postel"
   },
   {
    "t": "p",
    "text": "Na přání vyrobíme i větší rozměr, například 220×220 cm. Před objednávkou si změřte ložnici – vnější rozměr postele je o rám a čelo větší a kolem postele by mělo zůstat alespoň 50–60 cm."
   }
  ],
  "faq": [
   {
    "question": "Vyrobíte i větší postel než 200×200?",
    "answer": "Ano, na přání vyrobíme i postel 220×220 cm nebo jiný atypický rozměr. Možnosti vždy posoudíme podle pevnosti konstrukce."
   },
   {
    "question": "Jaké matrace do postele 200×200?",
    "answer": "Nejčastěji dvě matrace 100×200 cm na dvou roštech, případně jednu matraci 200×200 cm přes celou šíři."
   }
  ]
 },
 "/postele-z-masivu/prodlouzene-postele/": {
  "h1": "Prodloužené postele z masivu",
  "short": "Postele v délce 210 nebo 220 cm pro vyšší postavy, aby nohy nikdy nekončily za matrací.",
  "long": [
   {
    "t": "p",
    "text": "Matrace má být zhruba o 20 cm delší, než je vaše výška. Pokud měříte přes 180 cm, standardní délka 200 cm vám nemusí stačit. Prodloužené postele vyrábíme ve vlastní dílně v délkách 210 a 220 cm, případně v jiné délce na míru. K prodloužené posteli dodáme i matraci a rošt v odpovídajícím rozměru."
   }
  ],
  "faq": [
   {
    "question": "Kdy potřebuji prodlouženou postel?",
    "answer": "Prodlouženou postel potřebujete, pokud měříte zhruba víc než 180 cm. Matrace by měla být alespoň o 20 cm delší, než je vaše výška."
   },
   {
    "question": "Seženu k prodloužené posteli matraci a rošt?",
    "answer": "Ano. Matrace i rošty Světspánku.cz vyrobí v prodloužené délce na míru, takže sestava bude rozměrově sedět."
   }
  ]
 },
 "/postele-z-masivu/postele-pro-3-osoby/": {
  "h1": "Rozšířené postele pro tři",
  "short": "Extra široké postele pro rodiny, které spí s dítětem, nebo pro všechny, kdo chtějí maximum prostoru.",
  "long": [
   {
    "t": "p",
    "text": "Spí u vás v posteli i dítě, nebo prostě chcete obrovské lůžko? Rozšířené postele vyrábíme v šířkách nad 200 cm na míru. Masivní konstrukce z buku, jasanu nebo dubu je dimenzovaná i na velkou ložnou plochu, matrace a rošty se skládají z několika dílů vedle sebe. Rozměr konzultujte s námi nebo na prodejně – poradíme, jak postel postavit, aby se vešla do ložnice a dobře se na ní spalo."
   }
  ],
  "faq": [
   {
    "question": "Jak široká může být postel pro tři?",
    "answer": "Postele širší než 200 cm vyrábíme na míru podle konstrukčních možností. Rozměr vždy konzultujeme individuálně, aby postel byla pevná a vešla se do ložnice."
   },
   {
    "question": "Jaké matrace se do rozšířené postele dávají?",
    "answer": "Do rozšířené postele se dává několik matrací stejné výšky vedle sebe, například tři matrace 80×200 nebo 90×200 cm. Spáry lze zakrýt topperem."
   }
  ]
 },
 "/postele-z-masivu/manzelske-postele-z-masivu/": {
  "h1": "Manželské postele z masivu",
  "short": "Dvoulůžkové postele z masivu od 140×200 až po 220×220 cm, vyrobené v naší dílně na jižní Moravě.",
  "long": [
   {
    "t": "p",
    "text": "Manželská postel je kus nábytku, na kterém strávíte třetinu života. Proto by měla být pevná, tichá a pohodlná. Dvoulůžka Světspánku.cz vyrábíme ve vlastní dílně z masivního buku, jasanu a dubu, s pevnými spoji a kvalitním kováním – postel se nebude viklat ani vrzat ani po letech."
   },
   {
    "t": "h",
    "text": "Jaký rozměr manželské postele zvolit"
   },
   {
    "t": "p",
    "text": "Nejmenší dvojlůžko začíná na 140×200 cm (každý má 70 cm). Nejčastěji se volí 160×200 cm a nejoblíbenější je 180×200 cm, kde má každý 90 cm jako na jednolůžku. Pro velké ložnice nabízíme 200×200 cm a na přání vyrobíme i 220×220 cm."
   },
   {
    "t": "h",
    "text": "Dvě matrace, nebo jedna?"
   },
   {
    "t": "p",
    "text": "Do dvojlůžka obvykle patří dvě matrace a dva rošty. Každý z partnerů si tak zvolí vlastní tvrdost a navzájem se méně rušíte. Kdo nechce spáru uprostřed, sáhne po jedné matraci přes celou šíři, po matraci pro páry Spring Variant nebo po topperu."
   },
   {
    "t": "h",
    "text": "Výška a výbava"
   },
   {
    "t": "p",
    "text": "Vybírat můžete výšku rámu (bočnice 40, 45 nebo 50 cm), tvar čela a odstín dřeva. Postel lze doplnit úložným prostorem až 1000 litrů, nočními stolky zabudovanými v čele nebo LED osvětlením se senzorem pohybu. Úpravy na míru – nejčastěji výška čela a rámu – výrobu téměř neprodlouží."
   }
  ],
  "faq": [
   {
    "question": "Jaké rozměry manželských postelí Světspánku.cz vyrábí?",
    "answer": "Manželské postele vyrábíme od 140×200 cm přes nejoblíbenější 160×200 a 180×200 cm až po 200×200 cm, na přání i 220×220 cm nebo v prodloužené délce."
   },
   {
    "question": "Jak vysoká má manželská postel být?",
    "answer": "Vyrábíme rámy s bočnicí 40, 45 a 50 cm. Vyšší postel se lépe opouští, proto ji ocení hlavně starší lidé a ti, kdo mají potíže se zády nebo s koleny."
   },
   {
    "question": "Může mít každý z partnerů jinou matraci?",
    "answer": "Ano. Do manželské postele obvykle patří dvě matrace a dva rošty, takže si každý může zvolit vlastní tvrdost, typ matrace i třeba polohovací rošt."
   },
   {
    "question": "Lze manželskou postel doplnit úložným prostorem?",
    "answer": "Ano. Pod manželskou postel z masivu lze vložit úložný prostor, který u rozměru 180×200 cm pojme až zhruba 1000 litrů."
   }
  ]
 },
 "/postele-z-masivu/postele-s-nocnimi-stolky/": {
  "h1": "Masivní postele s integrovanými nočními stolky",
  "short": "Postele, které mají noční stolky rovnou zabudované v rozšířeném čele – nemusíte nic dalšího vybírat.",
  "long": [
   {
    "t": "p",
    "text": "Nechcete řešit, jaké noční stolky k posteli vybrat, ale přesto je potřebujete? U těchto postelí jsou stolky součástí rozšířeného čela. Vše je ze stejného masivu a ve stejném odstínu, stolky se nikam neposouvají a pod nimi se snadno uklízí. Postel s integrovanými stolky vyrábíme v běžných rozměrech dvojlůžek a lze ji doplnit úložným prostorem."
   }
  ],
  "faq": [
   {
    "question": "Jsou noční stolky pevnou součástí postele?",
    "answer": "Ano. Noční stolky jsou zabudované v rozšířeném čele postele, ze stejného masivu a ve stejném odstínu, takže se nikam neposouvají a pod nimi se snadno uklízí."
   },
   {
    "question": "Lze postel s nočními stolky doplnit úložným prostorem?",
    "answer": "Ano, úložný prostor můžete pod postel s integrovanými nočními stolky vložit stejně jako u ostatních postelí z masivu."
   }
  ]
 },
 "/postele-z-masivu/postele-s-led-osvetlenim/": {
  "h1": "Postele z masivu s LED osvětlením",
  "short": "Masivní postele s LED osvětlením – jemné noční světlo pod postelí, které se rozsvítí, když ho potřebujete.",
  "long": [
   {
    "t": "p",
    "text": "LED osvětlení pod postelí vytváří v ložnici příjemnou atmosféru a v noci posvítí na cestu, aniž by vzbudilo partnera. Sady osvětlení skládáme z LED profilů, vypínačů, senzorů pohybu a USB zásuvek – některé lze ovládat i přes wifi. Osvětlení lze objednat rovnou s postelí, nebo ho k posteli z naší nabídky doplnit později."
   }
  ],
  "faq": [
   {
    "question": "Jak se LED osvětlení u postele ovládá?",
    "answer": "Podle zvolené sady vypínačem, senzorem pohybu nebo přes wifi. Senzor pohybu rozsvítí světlo pod postelí, jakmile v noci vstanete, a po chvíli ho zase zhasne."
   },
   {
    "question": "Mohu LED osvětlení k posteli dokoupit později?",
    "answer": "Ano. LED sady pod postel najdete samostatně v kategorii Doplňky k posteli a k posteli z naší nabídky je můžete doplnit kdykoli."
   }
  ]
 },
 "/postele-z-masivu/manzelske-postele-z-masivu/zvysena-postel/": {
  "h1": "Vysoké postele z masivu",
  "short": "Zvýšené postele s bočnicí 50 cm, ze kterých se pohodlně vstává – oceníte je hlavně v pokročilejším věku nebo při potížích se zády.",
  "long": [
   {
    "t": "p",
    "text": "Čím je postel vyšší, tím snáz se z ní vstává a tím méně se musíte při uléhání předklánět. Postele s horní hranou bočnice 50 cm jsou proto ideální pro seniory, pro lidi s bolestmi zad či kolen a pro všechny, kdo chtějí pohodlí. Výsledná výška ložné plochy závisí i na zvolené matraci a roštu. Vysokou postel lze doplnit úložným prostorem, který díky výšce pojme ještě víc věcí."
   }
  ],
  "faq": [
   {
    "question": "Jak vysoká je vysoká postel?",
    "answer": "Horní hrana bočnice vysoké postele je ve výšce 50 cm. Výsledná výška ložné plochy pak závisí na výšce zvoleného roštu a matrace."
   },
   {
    "question": "Pro koho je vysoká postel vhodná?",
    "answer": "Vysoká postel je vhodná pro seniory, pro lidi s bolestmi zad nebo kolen a pro každého, kdo chce vstávat a uléhat bez námahy."
   }
  ]
 },
 "/postele-z-masivu/postele-s-uloznym-prostorem/": {
  "h1": "Postele s úložným prostorem z masivu",
  "short": "Postele z masivu s úložným prostorem až 1000 litrů – místo na lůžkoviny, sezónní oblečení i kufry.",
  "long": [
   {
    "t": "p",
    "text": "Úložný prostor pod postelí je nejjednodušší způsob, jak v ložnici získat místo bez další skříně. Pod každou postel Světspánku.cz (kromě boxspringů) lze vložit masivní úložný prostor – u rozměru 180×200 cm o objemu až zhruba 1000 litrů."
   },
   {
    "t": "h",
    "text": "Co se do úložného prostoru vejde"
   },
   {
    "t": "p",
    "text": "Ložní prádlo, zimní přikrývky, sezónní oblečení, cestovní kufry i hračky. Celý úložný prostor je stejně jako postel ze dřeva, bez dřevotřísky, takže unese i těžší věci a nebude se deformovat ani vlhnout."
   },
   {
    "t": "h",
    "text": "Jak se k věcem dostanete"
   },
   {
    "t": "p",
    "text": "Přístup zajišťuje výklopný rošt, který se zvedá lehce a sám drží v otevřené poloze. U dvojlůžka jsou rošty obvykle dva, takže každá polovina postele se otevírá zvlášť. Matraci volte ohebnou a s rozumnou hmotností, ať se rošt zvedá pohodlně."
   },
   {
    "t": "h",
    "text": "Jaké postele s úložným prostorem nabízíme"
   },
   {
    "t": "p",
    "text": "Manželské postele od 140×200 do 200×200 cm, jednolůžka v šířkách 80–120 cm, čalouněné postele s masivní konstrukcí i kontinentální boxspring BEDSPRING ve speciální variantě s úložným prostorem. Postel s úložným prostorem, výklopným roštem a matrací koupíte i jako výhodný komplet."
   }
  ],
  "faq": [
   {
    "question": "Kolik se vejde do úložného prostoru pod postelí?",
    "answer": "U postele 180×200 cm až zhruba 1000 litrů, u menších rozměrů úměrně méně. Vejdou se lůžkoviny, přikrývky, sezónní oblečení i cestovní kufry."
   },
   {
    "question": "Jak se k věcem v úložném prostoru dostanu?",
    "answer": "Přes výklopný rošt, který se zvedá snadno a sám drží v otevřené poloze. U dvojlůžka jsou obvykle dva rošty, takže každá polovina se otevírá zvlášť."
   },
   {
    "question": "Lze úložný prostor dát pod jakoukoli postel?",
    "answer": "Úložný prostor lze vložit pod všechny postele Světspánku.cz kromě boxspringů. Pro boxspring nabízíme samostatnou variantu BEDSPRING s úložným prostorem."
   },
   {
    "question": "Je úložný prostor z dřevotřísky?",
    "answer": "Ne. Úložný prostor je stejně jako postel ze dřeva, bez dřevotřísky, takže unese i těžší věci a nebude se deformovat."
   }
  ]
 },
 "/postele-z-masivu/manzelske-postele-s-uloznym-prostorem/": {
  "h1": "Manželské postele s úložným prostorem z masivu",
  "short": "Dvoulůžka z masivu s úložným prostorem pod celou ložnou plochou – až 1000 litrů místa.",
  "long": [
   {
    "t": "p",
    "text": "Manželská postel s úložným prostorem je nejčastější volba do menších bytů. Pod celou plochou dvojlůžka vznikne prostor až zhruba 1000 litrů, ke kterému se dostanete přes výklopné rošty. Postel i úložný prostor vyrábíme z masivu, takže je celek pevný a tichý. Vyberte rozměr od 140×200 do 200×200 cm a výšku rámu podle sebe."
   }
  ],
  "faq": [
   {
    "question": "Kolik místa získám pod manželskou postelí?",
    "answer": "Pod manželskou postelí 180×200 cm získáte úložný prostor o objemu až zhruba 1000 litrů."
   },
   {
    "question": "Má každá polovina manželské postele vlastní přístup?",
    "answer": "Ano. U dvojlůžka jsou obvykle dva výklopné rošty, takže každá polovina úložného prostoru se otevírá zvlášť."
   }
  ]
 },
 "/postele-z-masivu/jednoluzkove-postele-s-uloznym-prostorem/": {
  "h1": "Jednolůžkové postele s úložným prostorem z masivu",
  "short": "Jednolůžka z masivu s úložným prostorem – ideální do dětských a studentských pokojů.",
  "long": [
   {
    "t": "p",
    "text": "V dětských, studentských i menších pokojích je každý úložný prostor k dobru. Jednolůžkové postele z masivu s úložným prostorem pod ložnou plochou pojmou lůžkoviny, hračky i sezónní věci. Přístup zajišťuje výklopný rošt. Vyrábíme v šířkách 80–120 cm."
   }
  ],
  "faq": [
   {
    "question": "V jakých šířkách vyrábíte jednolůžka s úložným prostorem?",
    "answer": "Jednolůžka s úložným prostorem vyrábíme ve standardních šířkách 80, 90, 100 a 120 cm, jiný rozměr na míru."
   },
   {
    "question": "Hodí se jednolůžko s úložným prostorem do dětského pokoje?",
    "answer": "Ano. Úložný prostor pod postelí je praktické místo na hračky a lůžkoviny a masivní konstrukce vydrží i divočejší zacházení."
   }
  ]
 },
 "/postele-z-masivu/calounene-postele-s-uloznym-prostorem/": {
  "h1": "Čalouněné postele s úložným prostorem z masivu",
  "short": "Čalouněné postele s masivní konstrukcí a velkým úložným prostorem pod ložnou plochou.",
  "long": [
   {
    "t": "p",
    "text": "Čalouněné postele spojují měkký, útulný vzhled s praktickým úložným prostorem. Konstrukce je i u čalouněných modelů z masivního dřeva, takže postel je pevná a úložný prostor unese i těžší věci. Vybírat můžete barvu a typ čalounění i rozměr postele."
   }
  ],
  "faq": [
   {
    "question": "Je čalouněná postel s úložným prostorem dost pevná?",
    "answer": "Ano. Nosná konstrukce čalouněných postelí Světspánku.cz je z masivního dřeva, čalounění tvoří jen povrch, takže postel i úložný prostor unesou i těžší věci."
   },
   {
    "question": "Lze u čalouněné postele vybrat barvu látky?",
    "answer": "Ano, u čalouněných postelí vybíráte barvu i typ látky. Vzorky si můžete prohlédnout na prodejně."
   }
  ]
 },
 "/postele-z-masivu/jednoluzkove-postele-z-masivu/": {
  "h1": "Jednolůžkové postele z masivu",
  "short": "Jednolůžka z masivu v šířkách 80 až 120 cm – pro dospělé, dospívající i do pokojů pro hosty.",
  "long": [
   {
    "t": "p",
    "text": "Jednolůžko nemusí být kompromis. Jednolůžkové postele Světspánku.cz vyrábíme ze stejného masivního buku, jasanu a dubu a ve stejné kvalitě jako manželské postele – v šířkách 80, 90, 100 a 120 cm."
   },
   {
    "t": "h",
    "text": "Jakou šířku jednolůžka zvolit"
   },
   {
    "t": "p",
    "text": "Šířka 80 cm se hodí pro děti a do pokojů pro hosty. Nejběžnější je 90×200 cm, které stačí většině dospělých. Kdo se v noci hodně otáčí, ocení 100 cm, a šířka 120 cm nabízí opravdu hodně místa pro jednoho. Pro vyšší postavy vyrobíme i prodlouženou délku."
   },
   {
    "t": "h",
    "text": "Výbava jednolůžek"
   },
   {
    "t": "p",
    "text": "Vybírat můžete modely s úložným prostorem, čalouněné varianty a nižší postele. Dvě jednolůžka 90×200 vedle sebe vytvoří manželské lůžko 180×200 cm."
   },
   {
    "t": "h",
    "text": "Jednolůžko, které se rozloží"
   },
   {
    "t": "p",
    "text": "Hledáte-li postel, která se během chvilky promění v dvojlůžko, podívejte se na rozkládací postele a pohovky."
   }
  ],
  "faq": [
   {
    "question": "Jaké šířky jednolůžek Světspánku.cz vyrábí?",
    "answer": "Jednolůžka vyrábíme standardně v šířkách 80, 90, 100 a 120 cm v délce 200 cm nebo prodloužené. Jiný rozměr vyrobíme na míru."
   },
   {
    "question": "Jakou matraci k jednolůžku vybrat?",
    "answer": "K jednolůžku patří jedna matrace ve stejném rozměru. Nejhledanější je rozměr 90×200 cm, na který u vybraných modelů platí služba 30 nocí jistoty s výměnou tvrdosti zdarma."
   },
   {
    "question": "Existuje jednolůžko, které se rozloží na dvojlůžko?",
    "answer": "Ano. Takové postele najdete v kategorii Rozkládací postele a pohovky – vybrané modely se z jednolůžka rozloží na plnohodnotné dvojlůžko."
   }
  ]
 },
 "/postele-z-masivu/calounene-jednoluzka/": {
  "h1": "Čalouněné jednolůžkové postele",
  "short": "Jednolůžka s čalouněným čelem nebo rámem a pevnou konstrukcí z masivního dřeva.",
  "long": [
   {
    "t": "p",
    "text": "Čalouněné čelo je příjemné na opření při čtení a ložnici dodá útulný vzhled. U čalouněných jednolůžek kombinujeme měkké čalounění s pevnou konstrukcí z masivu, takže postel je stabilní a vydrží roky. Vyberte si barvu i typ látky a rozměr od 80 do 120 cm."
   }
  ],
  "faq": [
   {
    "question": "Je konstrukce čalouněného jednolůžka z masivu?",
    "answer": "Ano. Nosná konstrukce čalouněných jednolůžek je z masivního dřeva a čalounění tvoří jen povrch čela a rámu."
   },
   {
    "question": "Jde čalounění postele čistit?",
    "answer": "Ano, způsob čištění závisí na zvolené látce. Doporučení k údržbě najdete u každé látky v detailu postele."
   }
  ]
 },
 "/postele-z-masivu/nizke-postele/": {
  "h1": "Nižší postele z masivu",
  "short": "Postele s nižší bočnicí 40 cm – subtilnější vzhled a lehký přístup k lůžku.",
  "long": [
   {
    "t": "p",
    "text": "Nižší postele s horní hranou bočnice 40 cm působí v ložnici lehce a vzdušně. Hodí se do podkrovních pokojů se šikmými stropy, do dětských pokojů a pro všechny, kdo mají raději nižší lůžko. Celková výška ložné plochy závisí na zvolené matraci a roštu. I nižší postele vyrábíme z masivního buku, jasanu nebo dubu."
   }
  ],
  "faq": [
   {
    "question": "Jak nízká je nízká postel z masivu?",
    "answer": "Horní hrana bočnice nízké postele je ve výšce 40 cm. Výsledná výška ložné plochy závisí na zvoleném roštu a matraci."
   },
   {
    "question": "Pro koho je nižší postel vhodná?",
    "answer": "Nižší postel se hodí do podkrovních pokojů se šikmými stropy, do dětských pokojů a pro ty, kdo mají raději nízké lůžko. Senioři obvykle ocení spíš vyšší postel."
   }
  ]
 },
 "/postele-z-masivu/detske-postele-z-masivu/": {
  "h1": "Dětské a patrové postele z masivu",
  "short": "Bezpečné postele z masivu pro nejmenší i rostoucí děti – jednolůžka i patrové postele.",
  "long": [
   {
    "t": "p",
    "text": "Dětská postel musí vydržet skákání, stěhování i několik dětí po sobě. Proto ji vyrábíme ze stejného masivu jako postele pro dospělé – z buku, jasanu nebo dubu, bez dřevotřísky. Samozřejmostí jsou zakulacené rohy a možnost doplnit ochranné zábrany."
   },
   {
    "t": "h",
    "text": "Dětská, nebo patrová postel?"
   },
   {
    "t": "p",
    "text": "Pro jedno dítě volte klasickou dětskou postel, ideálně v rozměru 90×200 cm, která vydrží až do dospívání. Pro sourozence a menší pokoje je praktická patrová postel, která ušetří polovinu místa na podlaze."
   },
   {
    "t": "h",
    "text": "Bezpečnost"
   },
   {
    "t": "p",
    "text": "Zakulacené rohy, pevné spoje a ochranné zábrany proti vypadnutí. U patrových postelí má horní lůžko zábranu a horní patro doporučujeme dětem od zhruba 6 let."
   },
   {
    "t": "h",
    "text": "Matrace pro děti"
   },
   {
    "t": "p",
    "text": "K dětské posteli doporučujeme dětskou matraci bez lepidel – vyrábíme je z bezpečných materiálů, s pevnější oporou pro rostoucí páteř. Postel s rošty a matracemi koupíte i jako výhodný dětský komplet."
   },
   {
    "t": "h",
    "text": "Jaký rozměr dětské postele"
   },
   {
    "t": "p",
    "text": "Postel 90×200 cm vydrží dítěti až do dospělosti, takže ji nemusíte za pár let měnit. Do menších pokojů a pro menší děti se hodí kratší rozměry – dostupné rozměry najdete u modelů. Pod postel lze vložit úložný prostor na hračky a lůžkoviny."
   },
   {
    "t": "h",
    "text": "Ladí s dětským nábytkem"
   },
   {
    "t": "p",
    "text": "Dětské postele vyrábíme ve stejných dřevinách a odstínech jako dětské komody, skříně, police a truhlu na hračky, takže celý pokoj bude jednotný."
   }
  ],
  "faq": [
   {
    "question": "Jsou dětské postele z masivu bezpečné?",
    "answer": "Ano. Dětské postele Světspánku.cz mají zakulacené rohy, pevné spoje a lze je doplnit ochrannými zábranami proti vypadnutí."
   },
   {
    "question": "Od kolika let je vhodná patrová postel?",
    "answer": "Horní patro patrové postele obvykle doporučujeme dětem od zhruba 6 let. Řiďte se i doporučením u konkrétního modelu."
   },
   {
    "question": "Jakou matraci do dětské postele vybrat?",
    "answer": "Do dětské postele doporučujeme dětskou matraci bez lepidel ve stejném rozměru jako postel. Dětské matrace mají pevnější oporu pro rostoucí páteř."
   }
  ]
 },
 "/postele-z-masivu/patrove-postele/": {
  "h1": "Patrové postele z masivu",
  "short": "Patrové postele z masivu pro sourozence a menší dětské pokoje – pevné, bezpečné a odolné.",
  "long": [
   {
    "t": "p",
    "text": "Patrová postel ušetří v dětském pokoji polovinu místa a děti ji milují. U nás je vyrobená z masivu, s pevnými spoji a ochrannou zábranou u horního lůžka, takže se nebude kývat ani při divočejším hraní. Některé modely lze později rozložit na dvě samostatné postele. Patrovou postel můžete koupit i jako komplet s rošty a matracemi."
   }
  ],
  "faq": [
   {
    "question": "Lze patrovou postel rozložit na dvě samostatné postele?",
    "answer": "U vybraných modelů patrových postelí ano. Informaci o rozložení najdete v detailu konkrétní postele."
   },
   {
    "question": "Prodáváte patrové postele i s matracemi?",
    "answer": "Ano. Patrovou postel můžete koupit jako dětský komplet s rošty a dětskými matracemi bez lepidel za výhodnější cenu."
   }
  ]
 },
 "/postele-z-masivu/detske-postele/": {
  "h1": "Dětské postele z masivu",
  "short": "Dětská jednolůžka z masivu se zakulacenými rohy a možností zábran proti vypadnutí.",
  "long": [
   {
    "t": "p",
    "text": "Dětské postele vyrábíme v rozměrech, které s dítětem vydrží roky – od prvního vlastního lůžka po pokoj školáka. Zakulacené rohy a zábrany proti vypadnutí zajistí bezpečí, masivní dřevo bez dřevotřísky zase odolnost a zdravé prostředí. Pod postel lze doplnit úložný prostor na hračky."
   }
  ],
  "faq": [
   {
    "question": "Lze k dětské posteli dokoupit zábranu?",
    "answer": "Ano. K dětským postelím z masivu lze doplnit ochranné zábrany proti vypadnutí."
   },
   {
    "question": "Jaký rozměr dětské postele zvolit?",
    "answer": "Postel 90×200 cm vydrží dítěti až do dospělosti. Pro menší děti a menší pokoje se hodí i kratší rozměr – dostupné rozměry najdete u modelů."
   }
  ]
 },
 "/postele-z-masivu/calounene-masivni-postele/": {
  "h1": "Čalouněné postele s konstrukcí z masivu",
  "short": "Postele, které spojují elegantní čalounění s pevnou konstrukcí z masivního dřeva.",
  "long": [
   {
    "t": "p",
    "text": "Čalouněná postel dodá ložnici útulnost a hotelový vzhled. Na rozdíl od běžných čalouněných postelí z dřevotřísky mají čalouněné postele Světspánku.cz nosnou konstrukci z masivního dřeva – jsou proto pevné, tiché a vydrží roky."
   },
   {
    "t": "h",
    "text": "Kolik čalounění chcete"
   },
   {
    "t": "p",
    "text": "V nabídce najdete modely s různou mírou čalounění – od postelí, kde je čalouněné jen čelo a masivní rám zůstává vidět, až po plně čalouněné postele. Čalouněné čelo je příjemné na opření při čtení."
   },
   {
    "t": "h",
    "text": "Výbava"
   },
   {
    "t": "p",
    "text": "Vybírat můžete barvu a typ látky, rozměr i výšku postele. Čalouněné postele lze doplnit úložným prostorem nebo bočními panely s LED osvětlením a USB zásuvkou pro nabíjení telefonu."
   },
   {
    "t": "h",
    "text": "Čalouněná, nebo boxspring?"
   },
   {
    "t": "p",
    "text": "Čalouněná postel má klasický rám s roštem a matrací. Boxspring je vyšší kontinentální postel, kde matrace leží na pružinovém základu. Pokud hledáte tento typ, podívejte se na kategorii kontinentálních a boxspring postelí."
   }
  ],
  "faq": [
   {
    "question": "Je čalouněná postel Světspánku.cz z masivu?",
    "answer": "Ano. Nosná konstrukce je z masivního dřeva, čalounění tvoří čelo a povrch rámu. Díky tomu je postel pevná a tichá i po letech."
   },
   {
    "question": "Mohu si u čalouněné postele vybrat látku a barvu?",
    "answer": "Ano, u čalouněných postelí vybíráte typ látky i barvu. Vzorky látek si můžete prohlédnout na prodejnách v Brně, Praze, Olomouci a Ostravě."
   },
   {
    "question": "Jaký je rozdíl mezi čalouněnou a boxspring postelí?",
    "answer": "Čalouněná postel má klasický rám s roštem a matrací. Boxspring je vyšší kontinentální postel, kde matrace leží na pružinovém základu místo roštu."
   }
  ]
 },
 "/postele-z-masivu/postele-drevo-a-calouneni/": {
  "h1": "Postele z masivu s čalouněním",
  "short": "Postele, ve kterých se potkává viditelné masivní dřevo s čalouněným čelem nebo rámem.",
  "long": [
   {
    "t": "p",
    "text": "Kombinované postele jsou pro ty, kdo nechtějí volit mezi krásou dřeva a pohodlím čalounění. Masivní rám a nohy zůstávají vidět, čelo nebo jeho část je čalouněná – opírá se o ni příjemně při čtení a postel působí měkčeji. Konstrukce je stejně jako u ostatních postelí z masivu, s kvalitním kováním a pevnými spoji."
   }
  ],
  "faq": [
   {
    "question": "Které části kombinované postele jsou čalouněné?",
    "answer": "Obvykle čelo nebo jeho část. Rám a nohy zůstávají z viditelného masivního dřeva."
   },
   {
    "question": "Lze zvolit odstín dřeva i barvu látky zvlášť?",
    "answer": "Ano, u kombinovaných postelí si odstín dřeva i barvu čalounění vyberete samostatně."
   }
  ]
 },
 "/postele-z-masivu/postele-s-led-a-usb/": {
  "h1": "Čalouněné postele s LED a USB",
  "short": "Čalouněné postele s bočními panely, ve kterých je LED osvětlení a USB zásuvka.",
  "long": [
   {
    "t": "p",
    "text": "Boční panely u čela postele nahrazují noční lampičku i nabíječku. LED osvětlení posvítí na čtení nebo v noci na cestu a USB zásuvka nabije telefon, aniž byste museli natahovat prodlužovačky. Vše je čistě zabudované v čalounění a nekazí vzhled postele."
   }
  ],
  "faq": [
   {
    "question": "K čemu slouží boční panely u postele?",
    "answer": "Boční panely u čela postele integrují LED osvětlení a USB zásuvku, takže nahradí noční lampičku i nabíječku u postele."
   },
   {
    "question": "Lze USB zásuvku zabudovat i do jiné postele?",
    "answer": "Ano. USB zásuvku lze integrovat do čela postelí, které vyrábíme na míru."
   }
  ]
 },
 "/postele-z-masivu/kontinentalni-a-boxspring-postele/": {
  "h1": "Kontinentální a boxspring postele",
  "short": "Vysoké kontinentální postele s bohatým čalouněním a výjimečným komfortem spánku.",
  "long": [
   {
    "t": "p",
    "text": "Kontinentální, boxspring nebo americká postel – různé názvy pro stejný typ vysoké postele, kde matrace leží na pružinovém základu (boxu) místo roštu a často ji doplňuje vrchní topper. Spí se na ní měkce a pohodlně, vstává se snadno a v ložnici působí luxusně."
   },
   {
    "t": "h",
    "text": "Jak boxspring funguje"
   },
   {
    "t": "p",
    "text": "Pružinový základ funguje jako další vrstva odpružení pod matrací. Tělo je podepřené rovnoměrně, matrace méně namáhaná a vysoká ložná plocha usnadňuje vstávání. Rošt k boxspringu nepotřebujete."
   },
   {
    "t": "h",
    "text": "Na čem záleží kvalita"
   },
   {
    "t": "p",
    "text": "Skutečnou kvalitu boxspringu neurčuje název, ale konstrukce a materiály. Boxspring postele kolekce BEDSPRING mají pevnou konstrukci a kvalitní komponenty, aby komfort vydržel roky. Látku i rozměr si vyberete sami."
   },
   {
    "t": "h",
    "text": "Boxspring s úložným prostorem"
   },
   {
    "t": "p",
    "text": "Klasický boxspring úložný prostor nemá. Proto nabízíme variantu BEDSPRING-ÚP MAXI s úložným prostorem zhruba 1000 litrů pod vyklápěcí ložnou plochou."
   }
  ],
  "faq": [
   {
    "question": "Co je boxspring postel?",
    "answer": "Boxspring je vysoká kontinentální postel, kde matrace leží na pružinovém základu (boxu) místo roštu. Často se doplňuje vrchním topperem."
   },
   {
    "question": "Má boxspring postel úložný prostor?",
    "answer": "Klasický boxspring ne. Světspánku.cz ale nabízí variantu BEDSPRING-ÚP MAXI s úložným prostorem o objemu zhruba 1000 litrů."
   },
   {
    "question": "Potřebuji k boxspringu rošt?",
    "answer": "Ne. Roli roštu u boxspring postele plní pružinový základ, na který se pokládá matrace."
   }
  ]
 },
 "/postele-z-masivu/boxspring-postele/": {
  "h1": "Boxspring postele",
  "short": "Klasické boxspring postele s pružinovým základem, matrací a vysokým komfortem.",
  "long": [
   {
    "t": "p",
    "text": "Boxspring postel spí měkce a zároveň pevně podepře tělo. Pružinový základ funguje jako další vrstva odpružení, matrace na něm vydrží déle a vysoká ložná plocha usnadňuje vstávání. Naše boxspring postele vyrábíme s pevnou konstrukcí a kvalitními komponenty, látku i rozměr si vyberete sami."
   }
  ],
  "faq": [
   {
    "question": "Je boxspring vhodný při bolestech zad?",
    "answer": "Mnoha lidem boxspring vyhovuje, protože kombinuje měkké uložení s oporou pružin. Tvrdost vždy doporučujeme vyzkoušet na prodejně a při potížích se poradit i s lékařem."
   },
   {
    "question": "Jak vysoká je boxspring postel?",
    "answer": "Boxspring postel je výrazně vyšší než klasická postel s roštem. Přesnou výšku ložné plochy najdete u každého modelu BEDSPRING."
   }
  ]
 },
 "/postele-z-masivu/boxspring-s-uloznym-prostorem/": {
  "h1": "Boxspring postele s úložným prostorem",
  "short": "Komfort kontinentální postele a k tomu zhruba 1000 litrů úložného prostoru.",
  "long": [
   {
    "t": "p",
    "text": "Varianta BEDSPRING-ÚP MAXI spojuje komfort boxspringu s chytrým využitím prostoru. Pod ložnou plochou se skrývá úložný prostor zhruba 1000 litrů, ke kterému se dostanete snadným vyklopením. Hodí se do menších bytů, kde chcete luxusní postel a zároveň místo na lůžkoviny a sezónní věci."
   }
  ],
  "faq": [
   {
    "question": "Kolik se vejde do boxspringu s úložným prostorem?",
    "answer": "Boxspring BEDSPRING-ÚP MAXI nabízí úložný prostor o objemu zhruba 1000 litrů podle rozměru postele."
   },
   {
    "question": "Je úložný prostor boxspringu snadno přístupný?",
    "answer": "Ano. Ložná plocha se vyklápí a drží v otevřené poloze, takže se k věcem pohodlně dostanete."
   }
  ]
 },
 "/postele-z-masivu/rozkladaci-postele-pohovky/": {
  "h1": "Rozkládací postele a pohovky z masivu",
  "short": "Elegantní pohovky z masivu, které během chvilky rozložíte na plnohodnotné lůžko.",
  "long": [
   {
    "t": "p",
    "text": "Rozkládací postele a pohovky z masivního dřeva jsou řešením pro malé byty, pracovny i pokoje pro hosty. Přes den slouží jako pohodlná pohovka, večer je rozložíte na lůžko, na kterém se dá spát i každý den – ne jen o víkendu."
   },
   {
    "t": "h",
    "text": "Proč rozkládací postel z masivu"
   },
   {
    "t": "p",
    "text": "Běžné rozkládací pohovky mají kostru z dřevotřísky a spí se na sedacích polštářích. Rozkládací postele Světspánku.cz mají celomasivní konstrukci, která snese časté rozkládání a nebude se viklat, a spí se na běžné matraci, kterou si vyberete podle sebe."
   },
   {
    "t": "h",
    "text": "Jak rozkládání funguje"
   },
   {
    "t": "p",
    "text": "Rozložení zvládnete během chvilky a bez nářadí. Vybrané modely se z jednolůžka rozloží na plnohodnotné dvojlůžko."
   },
   {
    "t": "h",
    "text": "Pro koho se hodí"
   },
   {
    "t": "p",
    "text": "Pro garsoniéry a malé byty, kde obývák slouží i jako ložnice, pro pokoje hostů, pracovny a pro studenty."
   },
   {
    "t": "h",
    "text": "Jakou matraci na rozkládací postel"
   },
   {
    "t": "p",
    "text": "Na rozkládací postel patří matrace, kterou si vyberete stejně jako do běžné postele – podle hmotnosti a polohy spánku. Pro každodenní spaní doporučujeme kvalitní pěnovou nebo taštičkovou matraci, pro občasné hosty postačí i levnější model. Rozměr matrace najdete u každého modelu rozkládací postele."
   }
  ],
  "faq": [
   {
    "question": "Je rozkládací postel vhodná na každodenní spaní?",
    "answer": "Ano. Na rozkládací postele Světspánku.cz se pokládají běžné matrace, takže se na nich dá pohodlně spát každý den, ne jen příležitostně."
   },
   {
    "question": "Jak náročné je rozložení postele?",
    "answer": "Rozložení zvládnete během chvilky a bez nářadí. Celomasivní konstrukce snese i časté rozkládání."
   },
   {
    "question": "Rozloží se postel na dvojlůžko?",
    "answer": "Vybrané modely ano – z jednolůžka vznikne plnohodnotné dvojlůžko. Informaci najdete v detailu každé postele."
   }
  ]
 },
 "/postele-z-masivu/multi-modularni-postele/": {
  "h1": "MULTI – modulární postele z masivu",
  "short": "Modulární systém MULTI – postel z masivu, kterou si poskládáte z rámu, čela a úložného prostoru podle svých představ.",
  "long": [
   {
    "t": "p",
    "text": "Systém MULTI je postel, která se přizpůsobí vám. Vyberete si rám s úložným prostorem nebo bez něj, k němu čelo podle svého vkusu a postel doplníte o další díly. Každý kus vyrábíme v naší dílně na jižní Moravě z pečlivě vybraného masivního buku, jasanu nebo dubu."
   },
   {
    "t": "p",
    "text": "Díky modularitě můžete postel časem měnit – dokoupit jiné čelo, přidat úložný prostor nebo ji přizpůsobit novému bytu. Spojuje českou poctivost, kvalitu a nadčasový design."
   }
  ],
  "faq": [
   {
    "question": "Jak funguje modulární postel MULTI?",
    "answer": "Postel MULTI se skládá z rámu (s úložným prostorem nebo bez něj), čela a dalších dílů, které kombinujete podle svého vkusu a potřeb."
   },
   {
    "question": "Mohu díly postele MULTI dokoupit později?",
    "answer": "Ano. Čelo nebo úložný prostor lze u postele MULTI doplnit nebo vyměnit i později, třeba při stěhování."
   },
   {
    "question": "Z jakého dřeva je postel MULTI?",
    "answer": "Modulární postele MULTI vyrábíme ve vlastní dílně z masivního buku, jasanu nebo dubu."
   }
  ]
 },
 "/postele-z-masivu/multi-modularni-postele/ram-bez-ulozneho-prostoru/": {
  "h1": "MULTI – rám bez úložného prostoru",
  "short": "Základní rám systému MULTI bez úložného prostoru – lehký vzhled a volné místo pod postelí.",
  "long": [
   {
    "t": "p",
    "text": "Rám MULTI bez úložného prostoru je základ pro ty, kdo chtějí vzdušnou postel s volným místem pod lůžkem – snadno se pod ní uklízí. K rámu vyberete čelo a rošt. Úložný prostor lze případně doplnit později."
   }
  ],
  "faq": [
   {
    "question": "Lze k rámu MULTI později přidat úložný prostor?",
    "answer": "Ano. Systém MULTI je modulární, takže úložný prostor lze k rámu doplnit i později."
   },
   {
    "question": "Je čelo součástí rámu MULTI?",
    "answer": "Ne. Čelo si u systému MULTI vybíráte samostatně podle svého vkusu."
   }
  ]
 },
 "/postele-z-masivu/multi-modularni-postele/ram-s-uloznym-prostorem/": {
  "h1": "MULTI – rám s úložným prostorem",
  "short": "Rám MULTI s integrovaným úložným prostorem – postel a úložné místo v jednom.",
  "long": [
   {
    "t": "p",
    "text": "Rám MULTI s úložným prostorem využije celé místo pod ložnou plochou. Přístup zajišťuje výklopný rošt, konstrukce je stejně jako zbytek postele z masivu. K rámu vyberete čelo podle svého vkusu."
   }
  ],
  "faq": [
   {
    "question": "Jak se otevírá úložný prostor v rámu MULTI?",
    "answer": "Úložný prostor v rámu MULTI se otevírá výklopným roštem, který drží v otevřené poloze."
   },
   {
    "question": "Kolik se vejde do úložného prostoru MULTI?",
    "answer": "Objem závisí na rozměru postele – u dvojlůžka 180×200 cm až zhruba 1000 litrů."
   }
  ]
 },
 "/postele-z-masivu/multi-modularni-postele/cela-postele/": {
  "h1": "MULTI – čelo postele",
  "short": "Čela k modulárním postelím MULTI – vyberte tvar a výšku podle svého interiéru.",
  "long": [
   {
    "t": "p",
    "text": "Čelo dává posteli charakter. Pro systém MULTI nabízíme několik tvarů a výšek čel z masivu, které lze kombinovat s oběma typy rámů. Čelo můžete také později vyměnit, když se změní váš interiér."
   }
  ],
  "faq": [
   {
    "question": "Lze čelo postele MULTI vyměnit za jiné?",
    "answer": "Ano. Čela systému MULTI jsou vyměnitelná, takže postel můžete přizpůsobit i novému interiéru."
   },
   {
    "question": "Mohu výšku čela upravit na míru?",
    "answer": "Ano. Úprava výšky čela patří k nejčastějším zakázkovým úpravám postelí Světspánku.cz."
   }
  ]
 },
 "/postele-z-masivu/doplnky-k-posteli/": {
  "h1": "Doplňky k posteli",
  "short": "Vše, co postel doplní: úložné prostory, LED osvětlení, noční stolky a police.",
  "long": [
   {
    "t": "p",
    "text": "Postel je základ, doplňky z ní dělají ložnici. Pod postel můžete vložit masivní úložný prostor, doplnit LED osvětlení se senzorem pohybu nebo k ní vybrat noční stolky a police ze stejného dřeva a ve stejném odstínu. Většinu doplňků lze objednat rovnou s postelí i dokoupit později."
   }
  ],
  "faq": [
   {
    "question": "Lze doplňky dokoupit k již koupené posteli?",
    "answer": "Ano. Úložné prostory i LED osvětlení lze k posteli Světspánku.cz doplnit i později."
   },
   {
    "question": "Budou doplňky ve stejném odstínu jako postel?",
    "answer": "Ano. Nábytek a doplňky vyrábíme ve stejných dřevinách a odstínech jako postele."
   }
  ]
 },
 "/postele-z-masivu/led-osvetleni-postele/": {
  "h1": "LED osvětlení postelí",
  "short": "LED sady pro osvětlení pod postelí – profily, vypínače, senzory pohybu i USB zásuvky.",
  "long": [
   {
    "t": "p",
    "text": "LED osvětlení pod postel promění ložnici v pohodlnější a elegantnější místo. Naše sady obsahují LED profily, různé typy vypínačů, senzory pohybu a USB zásuvky – vytvoří příjemné ambientní světlo přesně tam, kde ho potřebujete. K dispozici jsou i sady ovládané přes wifi nebo automaticky senzorem. Vše je navrženo pro rychlou a univerzální montáž pod většinu postelí."
   }
  ],
  "faq": [
   {
    "question": "Hodí se LED sada i pod postel jiného výrobce?",
    "answer": "LED sady Světspánku.cz jsou navržené pro rychlou a univerzální montáž pod většinu postelí, nejen pod naše."
   },
   {
    "question": "Jak funguje senzor pohybu u LED osvětlení?",
    "answer": "Když v noci vstanete, senzor pohybu rozsvítí světlo pod postelí a po chvíli ho sám zhasne, takže nikoho neoslní."
   }
  ]
 },
 "/postele-z-masivu/ulozne-prostory-z-masivu/": {
  "h1": "Úložné prostory pod postel z masivu",
  "short": "Masivní úložné prostory, které vložíte pod kteroukoli naši postel – až 1000 litrů místa navíc.",
  "long": [
   {
    "t": "p",
    "text": "Pod každou postel z naší nabídky (kromě boxspringů) můžete vložit úložný prostor z masivu. U manželské postele 180×200 cm získáte až zhruba 1000 litrů místa na lůžkoviny, přikrývky, sezónní oblečení i kufry. Úložný prostor se kombinuje s výklopným roštem, díky kterému se k věcem snadno dostanete. Stejně jako postele ho vyrábíme ze dřeva, bez dřevotřísky."
   }
  ],
  "faq": [
   {
    "question": "Pod které postele lze úložný prostor vložit?",
    "answer": "Masivní úložný prostor lze vložit pod všechny postele Světspánku.cz kromě boxspringů."
   },
   {
    "question": "Potřebuji k úložnému prostoru speciální rošt?",
    "answer": "Ano, k úložnému prostoru patří výklopný rošt, díky kterému se k věcem pod postelí snadno dostanete."
   }
  ]
 },
 "/matrace/": {
  "h1": "Matrace",
  "short": "Matrace z vlastní české výroby i prémiové řady – ve všech rozměrech, pěti stupních tvrdosti a na míru.",
  "long": [
   {
    "t": "p",
    "text": "Matrace rozhoduje o kvalitě spánku víc než cokoli jiného v ložnici. Matrace Světspánku.cz navrhujeme a materiály pro ně vybíráme tak, aby matrace dlouho zůstala pohodlná a zdravotně nezávadná – používáme například vodou ředitelná lepidla SIMALFA® a dětské matrace jsou úplně bez lepidel. Nejvyšší třídu tvoří naše prémiové řady ELARA a X AIR a nabídku doplňuje španělská značka Don Almohadon."
   },
   {
    "t": "h",
    "text": "Jak vybrat matraci ve třech krocích"
   },
   {
    "t": "ol",
    "items": [
     "Rozměr – matrace má sedět na rošt a být alespoň o 20 cm delší, než je vaše výška. Do dvojlůžek se obvykle dávají dvě matrace (např. 2× 90×200 do postele 180×200).",
     "Tvrdost – rozhoduje hmotnost a poloha spánku. Lehčí postavy a spáči na boku potřebují měkčí matraci, těžší postavy a spáči na zádech či břiše tvrdší. Tvrdost značíme na stupnici 1–5.",
     "Typ jádra – pěnová matrace dobře kopíruje tělo, taštičková lépe větrá a nepřenáší pohyb partnera, paměťová pěna uleví tlakovým bodům, latex je pružný a hybridní kombinuje pružiny s pěnou."
    ]
   },
   {
    "t": "h",
    "text": "Pro koho matraci hledáte"
   },
   {
    "t": "p",
    "text": "Máme matrace pro děti (bez lepidel), pro páry s rozdílnou tvrdostí každé poloviny, pro seniory, pro alergiky s antimikrobiální úpravou a antidekubitní matrace pro ležící."
   },
   {
    "t": "h",
    "text": "Na míru, na zkoušku a v prodejně"
   },
   {
    "t": "p",
    "text": "Každou matraci vyrobíme v atypickém rozměru na centimetr přesně. Na vybrané matrace 90×200 cm platí 30 nocí jistoty – pokud vám tvrdost nesedí, jádro zdarma vyměníme. A nejjistější je matraci vyzkoušet: čeká na vás pět prodejen v Brně, Praze, Olomouci a Ostravě. Záruka je podle modelu 24 až 120 měsíců."
   }
  ],
  "faq": [
   {
    "question": "Jak vybrat správnou tvrdost matrace?",
    "answer": "Tvrdost matrace vybírejte hlavně podle hmotnosti a polohy spánku. Těžší postava a spaní na zádech nebo břiše potřebuje tvrdší matraci, lehčí postava a spaní na boku měkčí. Světspánku.cz značí tvrdost na stupnici 1–5."
   },
   {
    "question": "Co je služba 30 nocí jistoty?",
    "answer": "U vybraných matrací 90×200 cm vám Světspánku.cz do 30 nocí zdarma vymění jádro za jinou tvrdost ze stejné řady. Jádro přivezete na kteroukoli prodejnu a potah si ponecháte."
   },
   {
    "question": "Vyrobíte matraci v atypickém rozměru?",
    "answer": "Ano. Každou matraci z nabídky Světspánku.cz vyrobíme v rozměru, který potřebujete, s přesností na centimetr. Stačí rozměr napsat do dotazu u produktu."
   },
   {
    "question": "Jakou záruku mají matrace Světspánku.cz?",
    "answer": "Záruka na matrace je podle modelu 24 až 120 měsíců. Přesnou délku záruky najdete u každé matrace, prémiová řada X AIR má záruku 10 let."
   },
   {
    "question": "Kde si mohu matrace vyzkoušet?",
    "answer": "Matrace si můžete vyzkoušet na pěti prodejnách Světspánku.cz – v Brně, dvakrát v Praze, v Olomouci a v Ostravě. Doporučujeme si na matraci lehnout alespoň na pár minut v poloze, ve které spíte."
   },
   {
    "question": "Jak dlouho vydrží kvalitní matrace?",
    "answer": "Kvalitní matrace obvykle vydrží 8–10 let. Životnost prodlouží vhodný rošt, který matraci odvětrává, pravidelné otáčení a chránič matrace."
   }
  ]
 },
 "/matrace/podle-rozmeru/": {
  "h1": "Matrace podle rozměru",
  "short": "Matrace ve všech běžných rozměrech od 80×200 do 200×200 cm a v atypických rozměrech na míru.",
  "long": [
   {
    "t": "p",
    "text": "Rozměr matrace se řídí rozměrem postele a roštu – matrace má na rošt přesně sedět, aby se neposouvala a měla po celé ploše oporu. Do dvojlůžek se obvykle dávají dvě matrace (například 2× 80×200 do postele 160×200), takže každý z partnerů si zvolí vlastní tvrdost. Matrace by měla být alespoň o 20 cm delší, než je vaše výška. Pokud potřebujete jiný rozměr, každou matraci vyrobíme na míru."
   }
  ],
  "faq": [
   {
    "question": "Jakou matraci do postele 160×200?",
    "answer": "Do postele 160×200 cm patří buď jedna matrace 160×200, nebo dvě matrace 80×200 cm. Dvě matrace umožní každému z partnerů zvolit jinou tvrdost."
   },
   {
    "question": "Jak dlouhá má matrace být?",
    "answer": "Matrace by měla být alespoň o 20 cm delší, než je vaše výška. Pokud měříte přes 180 cm, zvažte prodlouženou délku 210 nebo 220 cm."
   },
   {
    "question": "Vyrobíte matraci v atypickém rozměru?",
    "answer": "Ano. Každou matraci z nabídky Světspánku.cz vyrobíme v atypickém rozměru na centimetr přesně – rozměr napište do dotazu u produktu."
   }
  ]
 },
 "/matrace/matrace-80x200/": {
  "h1": "Matrace 80×200 cm",
  "short": "Matrace 80×200 cm do dětských a studentských postelí i do dvojlůžek 160×200.",
  "long": [
   {
    "t": "p",
    "text": "Matrace 80×200 cm patří do užších jednolůžek, dětských a studentských postelí a v páru do manželské postele 160×200 cm."
   },
   {
    "t": "h",
    "text": "Dvě matrace 80×200 do postele 160×200"
   },
   {
    "t": "p",
    "text": "Nejčastěji se matrace 80×200 kupují po dvou do dvojlůžka 160×200 cm. Každý z partnerů tak spí na své tvrdosti a pohyb jednoho se méně přenáší na druhého. Spáru mezi matracemi zakryje topper."
   },
   {
    "t": "h",
    "text": "Jakou matraci 80×200 vybrat"
   },
   {
    "t": "p",
    "text": "Pro děti doporučujeme dětské matrace bez lepidel. Pro dospělé vybírejte tvrdost podle hmotnosti a polohy spánku na stupnici 1–5 a typ jádra podle toho, jestli chcete pěnovou, taštičkovou nebo matraci z paměťové pěny. Na polohovací rošt volte ohebnou matraci."
   }
  ],
  "faq": [
   {
    "question": "Lze dát dvě matrace 80×200 do postele 160×200?",
    "answer": "Ano, je to nejčastější řešení. Každý z partnerů pak může mít jinou tvrdost a spáru mezi matracemi lze zakrýt topperem."
   },
   {
    "question": "Je matrace 80×200 vhodná pro dítě?",
    "answer": "Ano. Pro děti doporučujeme dětské matrace Světspánku.cz, které jsou bez lepidel a mají pevnější oporu pro rostoucí páteř."
   }
  ]
 },
 "/matrace/matrace-90x200/": {
  "h1": "Matrace 90×200 cm",
  "short": "Nejprodávanější rozměr matrací – 90×200 cm do jednolůžek i dvojlůžek 180×200.",
  "long": [
   {
    "t": "p",
    "text": "Matrace 90×200 cm je nejhledanější a nejprodávanější rozměr. Patří do klasického jednolůžka a dvě vedle sebe do nejoblíbenější manželské postele 180×200 cm."
   },
   {
    "t": "h",
    "text": "30 nocí jistoty"
   },
   {
    "t": "p",
    "text": "Právě v rozměru 90×200 platí u vybraných matrací služba 30 nocí jistoty: když zjistíte, že vám tvrdost nesedí, do 30 nocí vám jádro zdarma vyměníme za jinou tvrdost ze stejné řady na kterékoli prodejně. Potah si ponecháte."
   },
   {
    "t": "h",
    "text": "Výběr matrace 90×200"
   },
   {
    "t": "p",
    "text": "V rozměru 90×200 najdete všechny typy jader – pěnové, taštičkové, latexové, hybridní i z paměťové pěny – v pěti stupních tvrdosti. Patří sem i prémiové řady ELARA, X AIR a Don Almohadon. Do postele 180×200 můžete dát dvě různé matrace 90×200, každou s jinou tvrdostí."
   },
   {
    "t": "h",
    "text": "Jakou tvrdost matrace 90×200 zvolit"
   },
   {
    "t": "p",
    "text": "Tvrdost vybírejte podle hmotnosti a polohy spánku na stupnici 1–5: lehčí postavy a spáči na boku spíš měkčí, těžší postavy a spáči na zádech či na břiše tvrdší. Nejuniverzálnější je středně tvrdá matrace."
   },
   {
    "t": "h",
    "text": "Rošt a chránič 90×200"
   },
   {
    "t": "p",
    "text": "Matraci dejte na rošt 90×200, který ji zespodu odvětrá a prodlouží jí život. Pratelný chránič matrace 90×200 ochrání matraci před potem a nečistotami a snadno se vypere doma."
   }
  ],
  "faq": [
   {
    "question": "Platí na matrace 90×200 služba 30 nocí jistoty?",
    "answer": "Ano, u vybraných modelů v rozměru 90×200 cm. Do 30 nocí vám jádro zdarma vyměníme za jinou tvrdost ze stejné řady na kterékoli prodejně Světspánku.cz."
   },
   {
    "question": "Kolik matrací 90×200 potřebuji do postele 180×200?",
    "answer": "Do postele 180×200 cm patří dvě matrace 90×200 cm. Každý z partnerů si tak může vybrat jinou tvrdost i jiný typ matrace."
   }
  ]
 },
 "/matrace/matrace-100x200/": {
  "h1": "Matrace 100×200 cm",
  "short": "Matrace 100×200 cm do širších jednolůžek a dvojlůžek 200×200.",
  "long": [
   {
    "t": "p",
    "text": "Matrace 100×200 cm patří do širších jednolůžek a v páru do velkorysé postele 200×200 cm."
   },
   {
    "t": "h",
    "text": "Výběr"
   },
   {
    "t": "p",
    "text": "Matrace 100×200 vyberete ve všech typech – od pěnových po taštičkové – a v pěti stupních tvrdosti podle hmotnosti a polohy spánku. Pro dvojlůžko 200×200 cm volte dvě matrace 100×200, každou podle potřeb jednoho z partnerů."
   },
   {
    "t": "h",
    "text": "Dostupnost"
   },
   {
    "t": "p",
    "text": "Dostupnost a termín dodání se liší podle modelu a najdete je u každé matrace."
   }
  ],
  "faq": [
   {
    "question": "Do jaké postele patří matrace 100×200?",
    "answer": "Matrace 100×200 cm patří do jednolůžka 100×200 nebo v páru do dvojlůžka 200×200 cm."
   },
   {
    "question": "V jakých tvrdostech je matrace 100×200?",
    "answer": "Matrace 100×200 cm nabízíme ve všech pěti stupních tvrdosti Světspánku.cz, od velmi měkké po velmi tvrdou."
   }
  ]
 },
 "/matrace/matrace-120x200/": {
  "h1": "Matrace 120×200 cm",
  "short": "Matrace 120×200 cm do širokých jednolůžek a francouzských postelí.",
  "long": [
   {
    "t": "p",
    "text": "Matrace 120×200 cm je určená pro široká jednolůžka, ve kterých chcete mít opravdu hodně místa, a do menších dvojlůžek na občasné spaní."
   },
   {
    "t": "h",
    "text": "Výběr"
   },
   {
    "t": "p",
    "text": "Vybírat můžete ze všech typů jader a stupňů tvrdosti. Protože jde o jednu matraci pro jednoho člověka, tvrdost volte přesně podle své hmotnosti a polohy spánku. Pro vyšší postavy vyrobíme matraci i v prodloužené délce, například 120×210 cm."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je matrace 120×200?",
    "answer": "Matrace 120×200 cm je pro jednoho dospělého, který chce při spánku hodně místa, nebo do menšího dvojlůžka na občasné spaní dvou lidí."
   },
   {
    "question": "Vyrobíte matraci 120×210?",
    "answer": "Ano. Prodloužené délky, například 120×210 cm, vyrobí Světspánku.cz na míru."
   }
  ]
 },
 "/matrace/matrace-140x200/": {
  "h1": "Matrace 140×200 cm",
  "short": "Matrace 140×200 cm do menších dvojlůžek – jedna matrace přes celou šíři.",
  "long": [
   {
    "t": "p",
    "text": "Matrace 140×200 cm je druhý nejhledanější rozměr. Patří do menších manželských postelí 140×200 cm, kde se obvykle používá jedna matrace přes celou šíři bez spáry."
   },
   {
    "t": "h",
    "text": "Když chce každý jinou tvrdost"
   },
   {
    "t": "p",
    "text": "Jedna matrace znamená jednu tvrdost pro oba. Pokud se partneři výrazně liší hmotností nebo polohou spánku, zvolte matraci pro páry Spring Variant – má společný taštičkový základ a každá polovina dostane jiný vrchní topper. Případně tvrdost vybírejte podle těžšího z partnerů."
   },
   {
    "t": "h",
    "text": "Výběr"
   },
   {
    "t": "p",
    "text": "Matrace 140×200 nabízíme ve všech typech jader a pěti stupních tvrdosti."
   }
  ],
  "faq": [
   {
    "question": "Jedna matrace 140×200, nebo dvě užší?",
    "answer": "U šířky 140 cm se nejčastěji používá jedna matrace bez spáry. Pro rozdílnou tvrdost je ideální matrace pro páry Spring Variant s jiným topperem na každé polovině."
   },
   {
    "question": "Jakou tvrdost matrace zvolit pro dva?",
    "answer": "Buď podle těžšího z partnerů, nebo zvolte matraci s rozdílnou tvrdostí každé poloviny, například Spring Variant."
   }
  ]
 },
 "/matrace/matrace-160x200/": {
  "h1": "Matrace 160×200 cm",
  "short": "Matrace 160×200 cm – jedna velká, nebo dvě 80×200 do manželské postele.",
  "long": [
   {
    "t": "p",
    "text": "Do manželské postele 160×200 cm můžete dát jednu matraci 160×200 nebo dvě matrace 80×200."
   },
   {
    "t": "h",
    "text": "Jedna, nebo dvě matrace?"
   },
   {
    "t": "p",
    "text": "Jedna matrace nemá uprostřed spáru, ale oba spíte na stejné tvrdosti. Dvě matrace 80×200 umožní každému vlastní tvrdost a méně přenášejí pohyb. Pokud chcete obojí, sáhněte po matraci pro páry s rozdílnou tvrdostí každé poloviny nebo spáru zakryjte topperem 160×200."
   },
   {
    "t": "h",
    "text": "Kombinovatelné matrace"
   },
   {
    "t": "p",
    "text": "Dvě různé matrace by měly mít stejnou výšku, aby lůžko bylo rovné. Proto nabízíme matrace stejné výšky v rozdílných tvrdostech, které lze vzájemně kombinovat."
   }
  ],
  "faq": [
   {
    "question": "Je lepší jedna matrace 160×200, nebo dvě 80×200?",
    "answer": "Jedna matrace nemá spáru, dvě umožní každému z partnerů jinou tvrdost. Obojí spojuje matrace pro páry Spring Variant, případně dvě matrace zakryté topperem."
   },
   {
    "question": "Lze kombinovat dvě různé matrace stejné výšky?",
    "answer": "Ano. Světspánku.cz nabízí vzájemně kombinovatelné matrace stejné výšky v rozdílných tvrdostech, aby lůžko zůstalo rovné."
   }
  ]
 },
 "/matrace/matrace-180x200/": {
  "h1": "Matrace 180×200 cm",
  "short": "Matrace 180×200 cm nebo dvě matrace 90×200 do nejoblíbenější manželské postele.",
  "long": [
   {
    "t": "p",
    "text": "Postel 180×200 cm je nejoblíbenější dvojlůžko a obvykle se do ní dávají dvě matrace 90×200 cm. Každý z partnerů tak spí na své tvrdosti a navzájem se nerušíte."
   },
   {
    "t": "h",
    "text": "30 nocí jistoty pro oba"
   },
   {
    "t": "p",
    "text": "Na vybrané matrace 90×200 platí služba 30 nocí jistoty s výměnou jádra zdarma – a protože máte dvě matrace, každá se dá vyměnit zvlášť."
   },
   {
    "t": "h",
    "text": "Jedna matrace přes celou šíři"
   },
   {
    "t": "p",
    "text": "Pokud chcete lůžko bez spáry, vyrobíme i matraci 180×200 cm v jednom kuse, nebo spáru zakryjete topperem 180×200."
   }
  ],
  "faq": [
   {
    "question": "Kolik matrací do postele 180×200?",
    "answer": "Nejčastěji dvě matrace 90×200 cm, takže každý z partnerů má vlastní tvrdost. Pokud nechcete spáru, zvolte jednu matraci 180×200 nebo topper přes obě matrace."
   },
   {
    "question": "Platí 30 nocí jistoty i pro postel 180×200?",
    "answer": "Ano, pokud do postele zvolíte dvě vybrané matrace 90×200 cm. Jádro každé z nich lze do 30 nocí zdarma vyměnit za jinou tvrdost."
   }
  ]
 },
 "/matrace/matrace-200x200/": {
  "h1": "Matrace 200×200 cm",
  "short": "Matrace 200×200 cm nebo dvě matrace 100×200 do velkých dvojlůžek.",
  "long": [
   {
    "t": "p",
    "text": "Do postele 200×200 cm se nejčastěji dávají dvě matrace 100×200 cm, případně jedna matrace přes celou šíři."
   },
   {
    "t": "h",
    "text": "Výběr"
   },
   {
    "t": "p",
    "text": "Vybírat můžete ze všech typů jader a pěti stupňů tvrdosti. Dvě matrace 100×200 umožní každému vlastní tvrdost, spáru zakryje topper 200×200. Pro ještě větší postele vyrobíme matrace v atypickém rozměru, například 220×200 nebo 220×220 cm."
   }
  ],
  "faq": [
   {
    "question": "Jaké matrace do postele 200×200?",
    "answer": "Do postele 200×200 cm se dávají dvě matrace 100×200 cm, nebo jedna matrace 200×200 cm přes celou šíři."
   },
   {
    "question": "Vyrobíte matraci 220×200?",
    "answer": "Ano. Atypické rozměry matrací, například 220×200 cm, vyrobí Světspánku.cz na míru."
   }
  ]
 },
 "/matrace/matrace-podle-tvrdosti/": {
  "h1": "Matrace podle tvrdosti",
  "short": "Matrace v pěti stupních tvrdosti – vyberte podle své váhy a polohy, ve které nejčastěji spíte.",
  "long": [
   {
    "t": "p",
    "text": "Správná tvrdost matrace drží páteř v přirozené rovině. Příliš měkká matrace nechá pánev propadnout, příliš tvrdá nedovolí zabořit ramena a boky. Při výběru rozhoduje hlavně vaše hmotnost a poloha, ve které nejčastěji spíte."
   },
   {
    "t": "h",
    "text": "Stupnice tvrdosti 1–5"
   },
   {
    "t": "p",
    "text": "Tvrdost matrací Světspánku.cz značíme na stupnici 1 až 5:"
   },
   {
    "t": "ul",
    "items": [
     "1 – velmi měkká: lehčí postavy, spáči na boku",
     "2 – měkká: lehčí až střední postavy, střídání poloh",
     "3 – středně tvrdá: nejuniverzálnější volba pro většinu lidí",
     "4 – tvrdá: těžší postavy, spaní na zádech a na břiše",
     "5 – velmi tvrdá: nejvyšší hmotnosti a milovníci pevné podložky"
    ]
   },
   {
    "t": "p",
    "text": "Doporučenou hmotnost najdete u každé matrace."
   },
   {
    "t": "h",
    "text": "Poloha spánku"
   },
   {
    "t": "p",
    "text": "Spáči na boku potřebují, aby se rameno a bok zabořily – volí spíš měkčí matraci. Spáči na zádech a na břiše potřebují pevnější oporu bederní části."
   },
   {
    "t": "h",
    "text": "Když tvrdost netrefíte"
   },
   {
    "t": "p",
    "text": "U vybraných matrací 90×200 cm platí 30 nocí jistoty s výměnou jádra zdarma. A pokud každý z partnerů potřebuje jinou tvrdost, zvolte dvě matrace nebo matraci pro páry Spring Variant."
   }
  ],
  "faq": [
   {
    "question": "Podle čeho vybrat tvrdost matrace?",
    "answer": "Podle hmotnosti a polohy spánku. Čím těžší postava a čím víc spíte na zádech nebo na břiše, tím tvrdší matraci zvolte; lehčí postavy a spáči na boku potřebují měkčí."
   },
   {
    "question": "Co když tvrdost matrace netrefím?",
    "answer": "U vybraných matrací 90×200 cm vám Světspánku.cz do 30 nocí zdarma vymění jádro za jinou tvrdost ze stejné řady v rámci služby 30 nocí jistoty."
   },
   {
    "question": "Co dělat, když chce každý z partnerů jinou tvrdost?",
    "answer": "Zvolte dvě matrace s rozdílnou tvrdostí, nebo matraci pro páry Spring Variant, která má každou polovinu jinak tvrdou a uprostřed žádnou mezeru."
   },
   {
    "question": "Je tvrdá matrace zdravější pro záda?",
    "answer": "Ne automaticky. Zdravá je matrace, která odpovídá vaší hmotnosti a poloze spánku – pro lehčího člověka může být tvrdá matrace naopak nevhodná."
   }
  ]
 },
 "/matrace/matrace-podle-tvrdosti/velmi-mekke-matrace/": {
  "h1": "Velmi měkké matrace",
  "short": "Velmi měkké matrace pro lehčí postavy (orientačně do 60 kg) a spáče na boku.",
  "long": [
   {
    "t": "p",
    "text": "Velmi měkké matrace se příjemně přizpůsobí tělu – ramena a boky se hluboce zaboří a páteř zůstane rovná i u lehčích postav. Doporučujeme je orientačně pro hmotnost do 60 kg a pro ty, kdo spí převážně na boku. Hodí se i pro seniory a lidi s citlivými klouby."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je velmi měkká matrace?",
    "answer": "Velmi měkká matrace (stupeň 1/5) je pro lehčí postavy, spáče na boku a lidi s citlivými klouby, kterým vyhovuje hluboké zaboření ramen a boků."
   },
   {
    "question": "Není měkká matrace špatná pro záda?",
    "answer": "Ne, pokud odpovídá vaší hmotnosti. Lehčí člověk by se na tvrdé matraci neprohnul a jeho páteř by nezůstala v rovině."
   }
  ]
 },
 "/matrace/matrace-podle-tvrdosti/mekke-matrace/": {
  "h1": "Měkké matrace",
  "short": "Měkké matrace pro hmotnost orientačně 60–80 kg – příjemně se přizpůsobí, ale nepropadnete se.",
  "long": [
   {
    "t": "p",
    "text": "Měkké matrace jsou dobrou volbou pro ty, kdo během noci střídají polohy. Přizpůsobí se tělu, ale nepropadají se. Orientačně je doporučujeme pro hmotnost 60–80 kg a pro spaní na boku i na zádech."
   }
  ],
  "faq": [
   {
    "question": "Jaký je rozdíl mezi velmi měkkou a měkkou matrací?",
    "answer": "Měkká matrace (stupeň 2/5) dává o něco víc opory než velmi měkká a hodí se pro lehčí až střední postavy, které během noci střídají polohy."
   },
   {
    "question": "Je měkká matrace vhodná na spaní na zádech?",
    "answer": "Pro lehčí a střední postavy ano. Těžším spáčům na zádech doporučujeme spíš středně tvrdou nebo tvrdou matraci."
   }
  ]
 },
 "/matrace/matrace-podle-tvrdosti/stredne-tvrde-matrace/": {
  "h1": "Středně tvrdé matrace",
  "short": "Nejčastější volba – vyvážená opora pro většinu spáčů, orientačně 75–100 kg.",
  "long": [
   {
    "t": "p",
    "text": "Středně tvrdé matrace jsou nejuniverzálnější. Nabízejí vyváženou oporu pro většinu spáčů na boku i na zádech a orientačně je doporučujeme pro hmotnost 75–100 kg. Pokud nevíte, kterou tvrdost zvolit, středně tvrdá matrace je bezpečný začátek."
   }
  ],
  "faq": [
   {
    "question": "Je středně tvrdá matrace vhodná pro každého?",
    "answer": "Středně tvrdá matrace (stupeň 3/5) vyhovuje většině lidí a je nejčastější volbou. Velmi lehké a velmi těžké postavy by měly zvolit měkčí nebo tvrdší stupeň."
   },
   {
    "question": "Mohu tvrdost matrace později vyměnit?",
    "answer": "U vybraných matrací 90×200 cm ano – v rámci služby 30 nocí jistoty vám jádro do 30 nocí zdarma vyměníme za jinou tvrdost."
   }
  ]
 },
 "/matrace/matrace-podle-tvrdosti/tvrde-matrace/": {
  "h1": "Tvrdé matrace",
  "short": "Tvrdé matrace pro těžší postavy (orientačně 90–120 kg) a spaní na zádech nebo na břiše.",
  "long": [
   {
    "t": "p",
    "text": "Tvrdé matrace nedovolí pánvi propadnout se, takže záda zůstanou v rovině i u těžších postav. Doporučujeme je orientačně pro hmotnost 90–120 kg a pro spaní na zádech či na břiše. Pamatujte, že pocit tvrdosti závisí na hmotnosti – pro těžšího člověka bude stejná matrace působit měkčeji."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je tvrdá matrace?",
    "answer": "Tvrdá matrace (stupeň 4/5) je pro těžší postavy a pro spaní na zádech nebo na břiše, kdy je potřeba, aby se pánev nepropadala."
   },
   {
    "question": "Proč mi tvrdá matrace připadá měkčí než ostatním?",
    "answer": "Pocit tvrdosti závisí na hmotnosti. Pro těžšího člověka působí stejná matrace měkčeji než pro lehčího, proto tvrdost vždy vybírejte podle své váhy."
   }
  ]
 },
 "/matrace/matrace-podle-tvrdosti/velmi-tvrde-matrace/": {
  "h1": "Velmi tvrdé matrace",
  "short": "Velmi tvrdé matrace pro hmotnost nad 120 kg a pro ty, kdo chtějí cítit pevnou podložku.",
  "long": [
   {
    "t": "p",
    "text": "Velmi tvrdé matrace se minimálně prohýbají i při vysoké zátěži. Jsou určené pro těžší postavy (orientačně nad 120 kg) a pro všechny, kdo prostě rádi spí na pevné podložce. Zároveň jsou vhodnou volbou při hledání matrace s vysokou nosností."
   }
  ],
  "faq": [
   {
    "question": "Jakou matraci zvolit pro osobu s vysokou hmotností?",
    "answer": "Velmi tvrdou matraci (stupeň 5/5) s vysokou nosností. Maximální nosnost najdete u každého modelu Světspánku.cz."
   },
   {
    "question": "Nebude mi velmi tvrdá matrace nepohodlná?",
    "answer": "Pokud vážíte méně, může působit tvrdě. Doporučujeme ji před nákupem vyzkoušet na některé z pěti prodejen."
   }
  ]
 },
 "/matrace/matrace-pro-pary/": {
  "h1": "Matrace pro páry – Spring Variant",
  "short": "Partnerská matrace Spring Variant – každá polovina s jinou tvrdostí a bez mezery uprostřed.",
  "long": [
   {
    "t": "p",
    "text": "Každý z vás potřebuje jinou tvrdost, ale nechcete mezi sebou mít spáru? Matrace Komfort Spring Variant 30 cm má taštičkový systém a vrchní topper, který volíte zvlášť pro každou polovinu – ze čtyř variant. Uprostřed nevzniká žádná mezera, a přitom každý spí na své tvrdosti. Pokud zjistíte, že vám tvrdost nesedí, topper můžete do 30 dní zdarma vyměnit. Matrace přináší komfort kontinentálních postelí do běžného rámu s roštem."
   }
  ],
  "faq": [
   {
    "question": "Jak funguje matrace s rozdílnou tvrdostí polovin?",
    "answer": "Matrace pro páry Spring Variant má společný taštičkový základ a vrchní topper, který volíte zvlášť pro každou polovinu ze čtyř variant. Uprostřed tak nevzniká mezera."
   },
   {
    "question": "Mohu tvrdost matrace pro páry později změnit?",
    "answer": "Ano. Topper matrace Spring Variant lze do 30 dní zdarma vyměnit za jinou variantu tvrdosti."
   },
   {
    "question": "Hodí se matrace pro páry do postele 140×200?",
    "answer": "Ano, právě do užších dvojlůžek, kde se obvykle dává jedna matrace přes celou šíři, je matrace s rozdílnou tvrdostí polovin ideální."
   }
  ]
 },
 "/matrace/30-noci-jistoty-vymena-tvrdosti/": {
  "h1": "Matrace s výměnou tvrdosti – 30 nocí jistoty",
  "short": "Matrace, u kterých vám do 30 nocí zdarma vyměníme jádro za jinou tvrdost.",
  "long": [
   {
    "t": "p",
    "text": "Bojíte se, že netrefíte tvrdost? S námi neriskujete. K vybraným matracím v rozměru 90×200 cm získáváte službu 30 nocí jistoty zcela zdarma. Máte 30 nocí na poctivé vyzkoušení. Pokud vám tělo řekne, že potřebujete tvrdší nebo měkčí podklad, rozepnete potah a vyndáte vnitřní jádro. Čisté jádro přivezete na kteroukoli naši prodejnu (Brno, Praha, Olomouc, Ostrava) a na místě vám ho zdarma vyměníme za jinou variantu ze stejné modelové řady. Potah si ponecháte."
   }
  ],
  "faq": [
   {
    "question": "Pro které matrace služba 30 nocí jistoty platí?",
    "answer": "Služba 30 nocí jistoty platí pro vybrané matrace Světspánku.cz v rozměru 90×200 cm. Všechny najdete v této kategorii."
   },
   {
    "question": "Jak výměna tvrdosti probíhá?",
    "answer": "Do 30 nocí od nákupu vyndáte jádro z potahu, čisté ho přivezete na kteroukoli prodejnu (Brno, Praha, Olomouc, Ostrava) a my ho zdarma vyměníme za jinou tvrdost ze stejné řady. Potah si ponecháte."
   },
   {
    "question": "Kolik výměna tvrdosti stojí?",
    "answer": "Výměna jádra v rámci služby 30 nocí jistoty je zdarma."
   }
  ]
 },
 "/matrace/matrace-podle-typu-materialu/": {
  "h1": "Matrace podle typu a materiálu",
  "short": "Pěnové, pružinové, latexové i matrace z paměťové pěny – vyberte typ jádra podle svých potřeb.",
  "long": [
   {
    "t": "p",
    "text": "Typ jádra určuje, jak se matrace chová – jak kopíruje tělo, jak větrá, jestli přenáší pohyb partnera a jak se hodí na polohovací rošt."
   },
   {
    "t": "h",
    "text": "Přehled typů matrací"
   },
   {
    "t": "ul",
    "items": [
     "Pěnové (studená a klasická pěna) – lehké, tvarově stabilní, dobře kopírují tělo a hodí se na polohovací rošty.",
     "Z paměťové (líné) pěny – přizpůsobí se tvaru těla, uleví tlakovým bodům, oblíbené u spáčů na boku.",
     "Latexové – velmi pružné a prodyšné, vhodné i pro alergiky.",
     "Taštičkové – každá pružina ve vlastní taštičce, výborně větrají a nepřenášejí pohyb partnera.",
     "Hybridní – kombinují taštičkové pružiny s vrstvami pěn: opora pružin a komfort pěny."
    ]
   },
   {
    "t": "h",
    "text": "Jak vybrat"
   },
   {
    "t": "p",
    "text": "Pokud se v noci potíte, sáhněte po taštičkové nebo latexové matraci. Pro spaní na boku a citlivé klouby je vhodná paměťová pěna. Pro páry, které se navzájem ruší, taštičky. Na polohovací rošt volte ohebnou pěnovou nebo taštičkovou matraci. Rozdíl mezi typy si nejlépe vyzkoušíte na prodejně."
   }
  ],
  "faq": [
   {
    "question": "Jaký je rozdíl mezi pěnovou a taštičkovou matrací?",
    "answer": "Pěnová matrace lépe kopíruje tělo a je lehčí, taštičková lépe větrá a nepřenáší pohyb partnera, protože každá pružina pracuje samostatně."
   },
   {
    "question": "Je paměťová pěna vhodná pro každého?",
    "answer": "Paměťová pěna uleví tlakovým bodům a vyhovuje hlavně spáčům na boku a lidem s citlivými klouby. Někomu může být v létě teplejší než studená pěna."
   },
   {
    "question": "Jaký typ matrace na polohovací rošt?",
    "answer": "Na polohovací rošt patří ohebná matrace – pěnová, latexová nebo taštičková. Méně vhodné jsou tuhé matrace s klasickými spojenými pružinami."
   },
   {
    "question": "Jaká matrace je nejlepší, když se v noci potím?",
    "answer": "Nejlépe větrají taštičkové a latexové matrace. Pomůže i prodyšný potah a lamelový rošt, který matraci odvětrává zespodu."
   }
  ]
 },
 "/matrace/matrace-podle-typu-materialu/penove/": {
  "h1": "Matrace z klasických i studených pěn",
  "short": "Matrace ze studených i klasických pěn – prodyšné, odolné a tvarově stabilní.",
  "long": [
   {
    "t": "p",
    "text": "Pěnové matrace vyrábíme výhradně z kvalitních pěn – klasických, studených (HR) nebo jejich kombinací. Jsou prodyšné, tvarově stabilní, lehké a dobře se hodí i na polohovací rošty. Matrace s paměťovou pěnou mají vlastní kategorii."
   }
  ],
  "faq": [
   {
    "question": "Co je studená pěna?",
    "answer": "Studená (HR) pěna je pružnější a prodyšnější pěna s otevřenou strukturou buněk, která dlouho drží tvar a dobře podpírá tělo."
   },
   {
    "question": "Hodí se pěnová matrace na polohovací rošt?",
    "answer": "Ano. Pěnové matrace jsou ohebné, takže se na polohovací rošty hodí velmi dobře."
   }
  ]
 },
 "/matrace/matrace-podle-typu-materialu/s-pametovou-penou/": {
  "h1": "Matrace s paměťovou pěnou",
  "short": "Matrace s paměťovou (viscoelastickou) pěnou, která se přizpůsobí tvaru těla a uleví tlakovým bodům.",
  "long": [
   {
    "t": "p",
    "text": "Paměťová neboli líná pěna reaguje na teplotu a tlak těla, dokonale se přizpůsobí vašim křivkám a rovnoměrně rozloží váhu. Hlavní výhodou je minimální zpětný tlak – tělo se uvolní a odpočinek je hlubší. Ocení ji hlavně spáči na boku a lidé s bolestmi kloubů."
   }
  ],
  "faq": [
   {
    "question": "Co je líná pěna?",
    "answer": "Líná pěna je hovorový název pro paměťovou (viscoelastickou) pěnu, která reaguje na teplo a tlak těla a pomalu se přizpůsobí jeho tvaru."
   },
   {
    "question": "Není matrace z paměťové pěny v létě horká?",
    "answer": "Může být teplejší než studená pěna. Pro horké noci doporučujeme modely s prodyšnou vrstvou nebo taštičkové matrace."
   }
  ]
 },
 "/matrace/matrace-podle-typu-materialu/latexove/": {
  "h1": "Latexové matrace",
  "short": "Pružné latexové matrace s vysokou prodyšností, vhodné i pro alergiky.",
  "long": [
   {
    "t": "p",
    "text": "Latex je velmi pružný a odolný materiál, který rychle reaguje na pohyb a zároveň dobře podpírá tělo. Latexové matrace jsou prodyšné a díky své struktuře vhodné i pro alergiky."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je latexová matrace vhodná?",
    "answer": "Latexová matrace je vhodná pro ty, kdo chtějí pružnou a prodyšnou matraci, a pro alergiky."
   },
   {
    "question": "Hodí se latexová matrace na polohovací rošt?",
    "answer": "Ano. Latex je ohebný, takže se latexová matrace na polohovací rošt hodí."
   }
  ]
 },
 "/matrace/matrace-podle-typu-materialu/pruzinove-a-tastickove/": {
  "h1": "Pružinové a taštičkové matrace",
  "short": "Taštičkové matrace s pružinami v samostatných kapsách – výborná prodyšnost a žádné přenášení pohybu.",
  "long": [
   {
    "t": "p",
    "text": "U taštičkových matrací je každá pružina uložena v samostatné textilní taštičce, takže reaguje jen na tlak v místě zatížení. Matrace se neprohýbá celá najednou, nepřenáší pohyb partnera a díky vzduchu mezi pružinami výborně větrá. Taštičkové pružiny tvoří základ i prémiové řady ELARA."
   }
  ],
  "faq": [
   {
    "question": "Proč taštičková matrace nepřenáší pohyb?",
    "answer": "Každá pružina je v samostatné textilní taštičce a reaguje jen na tlak v místě zatížení, takže pohyb jednoho spáče se k druhému téměř nepřenáší."
   },
   {
    "question": "Jsou taštičkové matrace vhodné pro páry?",
    "answer": "Ano. Právě díky tomu, že nepřenášejí pohyb partnera, jsou taštičkové matrace oblíbenou volbou do manželských postelí."
   }
  ]
 },
 "/matrace/matrace-podle-typu-materialu/hybridni/": {
  "h1": "Hybridní matrace",
  "short": "Hybridní matrace kombinují taštičkové pružiny s vrstvami kvalitních pěn.",
  "long": [
   {
    "t": "p",
    "text": "Hybridní matrace spojují to nejlepší z obou světů – oporu a prodyšnost taštičkových pružin s přizpůsobivostí pěn. Výsledkem je matrace, která podepře tělo a zároveň uleví tlakovým bodům."
   }
  ],
  "faq": [
   {
    "question": "Co je hybridní matrace?",
    "answer": "Hybridní matrace kombinuje v jednom jádru taštičkové pružiny s vrstvami kvalitních pěn – oporu a prodyšnost pružin s přizpůsobivostí pěny."
   },
   {
    "question": "Pro koho je hybridní matrace?",
    "answer": "Pro ty, kdo chtějí pevnou oporu pružin a zároveň měkký komfort pěny, a pro páry, které se v noci navzájem ruší."
   }
  ]
 },
 "/matrace/premiove-matrace/": {
  "h1": "Prémiové matrace",
  "short": "Naše nejlepší matrace – řady ELARA, X AIR a Don Almohadon.",
  "long": [
   {
    "t": "p",
    "text": "Prémiové řady jsou pro ty, kdo od matrace chtějí maximum. ELARA je naše nejvyšší řada – s taštičkovými pružinami v 7 zónách a výškou 31 cm. X AIR kombinuje BIO pěnu VERDE® s odolnou pěnou XDURA® a antimikrobiálním potahem ULTRAFRESH®. Don Almohadon je renomovaná španělská značka s více než třicetiletou tradicí. Prémiové matrace si můžete vyzkoušet na našich prodejnách."
   }
  ],
  "faq": [
   {
    "question": "Čím se liší prémiové matrace od ostatních?",
    "answer": "Prémiové matrace ELARA, X AIR a Don Almohadon se liší materiály, výškou, propracovaností zón a delší zárukou – X AIR má záruku 10 let, ELARA 7 let."
   },
   {
    "question": "Kde si prémiové matrace vyzkouším?",
    "answer": "Prémiové matrace si můžete vyzkoušet na prodejnách Světspánku.cz. Dostupnost konkrétního modelu na prodejně ověříte u produktu."
   }
  ]
 },
 "/matrace/premiove-matrace-elara/": {
  "h1": "Prémiové matrace ELARA",
  "short": "Kolekce ELARA – výška 31 cm, taštičkové pružiny v 7 anatomických zónách a potah Collagen™.",
  "long": [
   {
    "t": "p",
    "text": "ELARA je to nejlepší, co si můžete pro zdravý spánek dopřát. Matrace jsou vysoké 31 cm, základ tvoří taštičkové pružiny rozdělené do 7 anatomických zón a nad nimi vrstvy kvalitních pěn. Řada ELARA nabízí čtyři tvrdosti – od měkké greengel S po tvrdou lavender XL. Na matrace ELARA poskytujeme záruku 7 let a u rozměru 90×200 na ně platí 30 nocí jistoty."
   }
  ],
  "faq": [
   {
    "question": "Jaké tvrdosti má řada ELARA?",
    "answer": "Řada ELARA má čtyři tvrdosti: greengel S (měkká), memory M (středně tvrdá), biogreen L (tvrdší) a lavender XL (velmi tvrdá)."
   },
   {
    "question": "Jakou záruku a výšku mají matrace ELARA?",
    "answer": "Matrace ELARA jsou vysoké 31 cm, mají taštičkové pružiny v 7 anatomických zónách a záruku 7 let."
   },
   {
    "question": "Pro koho je matrace ELARA?",
    "answer": "Matrace ELARA je pro všechny, kdo chtějí maximální komfort a oporu. Díky 7 zónám a čtyřem tvrdostem si vybere lehčí i těžší postava, spáč na boku i na zádech."
   }
  ]
 },
 "/matrace/premiove-matrace-x-air/": {
  "h1": "Prémiové matrace X AIR",
  "short": "Antimikrobiální matrace X AIR z BIO pěny VERDE® a XDURA® – extra životnost, pružnost a komfort.",
  "long": [
   {
    "t": "p",
    "text": "Řada X AIR spojuje inovace, hygienu a komfort. Matrace jsou vyrobené z kombinace BIO pěny VERDE® a vysoce odolné pěny XDURA®, které zaručují dlouhou životnost, výjimečnou prodyšnost a stabilní oporu těla. Antimikrobiální potah ULTRAFRESH® chrání před bakteriemi, plísněmi i roztoči, takže matrace jsou ideální pro alergiky. X AIR nabízíme ve třech tvrdostech a se zárukou 10 let."
   }
  ],
  "faq": [
   {
    "question": "Jsou matrace X AIR vhodné pro alergiky?",
    "answer": "Ano. Matrace X AIR mají antimikrobiální potah ULTRAFRESH®, který chrání před bakteriemi, plísněmi i roztoči."
   },
   {
    "question": "Jak vysoké jsou matrace X AIR a jakou mají záruku?",
    "answer": "Matrace X AIR jsou vysoké 25 cm a mají záruku 10 let. Vyrábějí se ve třech tvrdostech z BIO pěny VERDE® a pěny XDURA®."
   }
  ]
 },
 "/matrace/matrace-donalmohadon/": {
  "h1": "Matrace Don Almohadon",
  "short": "Matrace renomované španělské značky Don Almohadon s více než třicetiletou tradicí.",
  "long": [
   {
    "t": "p",
    "text": "Don Almohadon je španělská značka specializovaná na matrace, polštáře a doplňky pro zdravý spánek. Už více než 30 let spojuje moderní technologie, kvalitní pěnové materiály a přírodní textilie a patří k nejuznávanějším výrobcům na španělském trhu. Matrace Don Almohadon dovážíme přímo ze Španělska."
   }
  ],
  "faq": [
   {
    "question": "Kde se matrace Don Almohadon vyrábějí?",
    "answer": "Matrace Don Almohadon se vyrábějí ve Španělsku a Světspánku.cz je dováží přímo od výrobce."
   },
   {
    "question": "Vyrábí Don Almohadon i polštáře?",
    "answer": "Ano. Španělská značka Don Almohadon vyrábí kromě matrací také polštáře a doplňky pro zdravý spánek."
   }
  ]
 },
 "/matrace/detske-matrace/": {
  "h1": "Dětské matrace – bezpečný a zdravý spánek",
  "short": "Dětské matrace bez lepidel – komfortní ležení, správná opora páteře a hygiena pro rostoucí děti.",
  "long": [
   {
    "t": "p",
    "text": "Dětské matrace navrhujeme tak, aby nabízely komfortní ležení, správnou oporu rostoucí páteře a dokonalou hygienu. Všechny dětské matrace Světspánku.cz vyrábíme bez lepidel z kvalitních a bezpečných materiálů."
   },
   {
    "t": "h",
    "text": "Matrace do postýlky"
   },
   {
    "t": "p",
    "text": "Pro miminka a batolata nabízíme matrace do postýlek v rozměrech 120×60 a 140×70 cm. Mají pevnou, rovnou plochu, ve které se dítě nepropadá, a pratelný potah. Před nákupem změřte vnitřní rozměr postýlky."
   },
   {
    "t": "h",
    "text": "Matrace do dětské postele"
   },
   {
    "t": "p",
    "text": "Když dítě vyroste z postýlky, obvykle kolem 3–4 let, přichází čas na postel 90×200 cm. Dětské matrace v tomto rozměru mají pevnější oporu pro rostoucí páteř a vydrží až do dospívání."
   },
   {
    "t": "h",
    "text": "Jak tvrdá má dětská matrace být"
   },
   {
    "t": "p",
    "text": "Spíše pevnější. Děti jsou lehké a na měkké matraci by se jejich páteř nedostala do správné polohy. K dětské matraci doporučujeme pratelný chránič s membránou, který ochrání matraci i před nehodami."
   }
  ],
  "faq": [
   {
    "question": "Proč jsou dětské matrace bez lepidel?",
    "answer": "Kvůli maximální zdravotní nezávadnosti. Děti tráví spánkem velkou část dne, proto Světspánku.cz vyrábí všechny dětské matrace bez lepidel."
   },
   {
    "question": "Jak tvrdá má dětská matrace být?",
    "answer": "Dětská matrace má být spíše pevnější, aby rostoucí páteř měla dostatečnou oporu a dítě se nepropadalo."
   },
   {
    "question": "Jaké rozměry dětských matrací nabízíte?",
    "answer": "Do postýlek 120×60 a 140×70 cm a do dětských postelí 90×200 cm. Další rozměry vyrobíme na míru."
   }
  ]
 },
 "/matrace/matrace-do-postylky/": {
  "h1": "Matrace do dětské postýlky",
  "short": "Matrace do postýlek v rozměrech 120×60 a 140×70 cm – bez lepidel a z bezpečných materiálů.",
  "long": [
   {
    "t": "p",
    "text": "Miminka a batolata potřebují pevnou, rovnou a zdravotně nezávadnou matraci. Matrace do postýlek vyrábíme bez lepidel, s pratelným potahem, v nejběžnějších rozměrech 120×60 a 140×70 cm. Pevnost je zvolená tak, aby se dítě nepropadalo a mělo bezpečnou oporu."
   }
  ],
  "faq": [
   {
    "question": "Jaký rozměr matrace do postýlky zvolit?",
    "answer": "Nejčastěji 120×60 cm, pro větší postýlky 140×70 cm. Rozměr vždy ověřte podle vnitřní plochy postýlky, aby mezi matrací a čely nevznikla mezera."
   },
   {
    "question": "Lze potah matrace do postýlky prát?",
    "answer": "Ano. Potah dětských matrací do postýlky je pratelný."
   }
  ]
 },
 "/matrace/detske-matrace-90x200/": {
  "h1": "Dětské matrace 90×200",
  "short": "Dětské matrace 90×200 cm do postelí školáků a teenagerů – bez lepidel.",
  "long": [
   {
    "t": "p",
    "text": "Když dítě vyroste z postýlky, přichází čas na plnohodnotnou postel 90×200 cm. Dětské matrace v tomto rozměru mají pevnější oporu pro rostoucí páteř a vyrábíme je bez lepidel. Vydrží až do dospívání."
   }
  ],
  "faq": [
   {
    "question": "Od kolika let je vhodná matrace 90×200?",
    "answer": "Jakmile dítě přechází z postýlky do postele, obvykle kolem 3–4 let. Matrace 90×200 cm pak vydrží až do dospívání."
   },
   {
    "question": "Je dětská matrace jiná než matrace pro dospělé?",
    "answer": "Ano. Dětská matrace Světspánku.cz je bez lepidel a pevnost má zvolenou pro nižší hmotnost a rostoucí páteř."
   }
  ]
 },
 "/matrace/zdravotni-a-ortopedicke-matrace/": {
  "h1": "Zdravotní a ortopedické matrace",
  "short": "Matrace s anatomickými zónami a speciálními vlastnostmi pro zdravý spánek – pro seniory, alergiky i při bolestech zad.",
  "long": [
   {
    "t": "p",
    "text": "Zdravotní a ortopedické matrace mají zóny s rozdílnou tvrdostí, které podepřou bederní páteř a zároveň nechají zabořit ramena a boky. Páteř tak zůstává v přirozené poloze, svaly se uvolní a spánek je hlubší."
   },
   {
    "t": "h",
    "text": "Co dělá matraci zdravotní"
   },
   {
    "t": "ul",
    "items": [
     "Anatomické zóny – části matrace s různou tvrdostí podle hmotnosti jednotlivých částí těla (například ELARA má 7 zón).",
     "Správná tvrdost – podle hmotnosti a polohy spánku na stupnici 1–5.",
     "Hygiena – antimikrobiální úprava a pratelný potah pro alergiky."
    ]
   },
   {
    "t": "h",
    "text": "Pro koho"
   },
   {
    "t": "p",
    "text": "Pro lidi s bolestmi zad, pro seniory, pro alergiky a pro ležící, kteří potřebují antidekubitní matraci. Při bolestech zad doporučujeme matraci vyzkoušet na prodejně a poradit se s našimi prodejci; při dlouhodobých potížích i s lékařem nebo fyzioterapeutem."
   },
   {
    "t": "h",
    "text": "Rošt je stejně důležitý"
   },
   {
    "t": "p",
    "text": "I nejlepší matrace ztratí své vlastnosti na nevhodném roštu. Lamelový rošt s nastavitelnou tvrdostí v bederní části nebo polohovací rošt dokáže účinek zdravotní matrace výrazně podpořit."
   }
  ],
  "faq": [
   {
    "question": "Pomůže ortopedická matrace na bolest zad?",
    "answer": "Správně zvolená tvrdost a anatomické zóny drží páteř v rovině, což záda odlehčí. Při dlouhodobých potížích se poraďte i s lékařem nebo fyzioterapeutem."
   },
   {
    "question": "Co jsou anatomické zóny matrace?",
    "answer": "Anatomické zóny jsou části matrace s rozdílnou tvrdostí, které podepřou různé části těla podle jejich hmotnosti – například pevnější oblast pod bedry a měkčí pod rameny."
   },
   {
    "question": "Jaký rošt ke zdravotní matraci?",
    "answer": "Lamelový rošt s nastavitelnou tvrdostí v bederní části nebo polohovací rošt. Rošt matraci odvětrává a podporuje její zdravotní účinek."
   }
  ]
 },
 "/matrace/matrace-pro-seniory/": {
  "h1": "Matrace pro seniory",
  "short": "Matrace, které usnadní vstávání a uleví kloubům – vhodné i na polohovací rošty.",
  "long": [
   {
    "t": "p",
    "text": "Ve vyšším věku je důležitá nejen opora páteře, ale i snadné vstávání. Matrace pro seniory mají dostatečně pevné okraje, příjemný povrch, který uleví kloubům, a jsou ohebné, takže se hodí i na polohovací rošty. V kombinaci s vyšší postelí se z lůžka vstává mnohem snáz."
   }
  ],
  "faq": [
   {
    "question": "Jakou tvrdost matrace zvolit pro seniora?",
    "answer": "Pro seniory se obvykle hodí měkčí až středně tvrdá matrace, která uleví kloubům a zároveň podepře páteř. Důležité jsou i pevné okraje pro snadné vstávání."
   },
   {
    "question": "Hodí se matrace pro seniory na polohovací rošt?",
    "answer": "Ano. Doporučujeme ohebné pěnové nebo taštičkové matrace, které se polohovacímu roštu přizpůsobí."
   }
  ]
 },
 "/matrace/matrace-pro-alergiky/": {
  "h1": "Antimikrobiální matrace pro alergiky",
  "short": "Matrace s antimikrobiální ochranou ULTRAFRESH® – čistší a zdravější lůžko pro alergiky.",
  "long": [
   {
    "t": "p",
    "text": "Antibakteriální úprava brání jen růstu bakterií. Antimikrobiální úprava ULTRAFRESH® chrání matraci navíc před plísněmi, viry, řasami a roztoči. Pokud hledáte čistší, zdravější a dlouhodobě chráněné lůžko, vyberte si matraci s touto úpravou. Pro ještě lepší hygienu doporučujeme pratelný chránič matrace."
   }
  ],
  "faq": [
   {
    "question": "Jaký je rozdíl mezi antibakteriální a antimikrobiální úpravou matrace?",
    "answer": "Antibakteriální úprava brání jen růstu bakterií. Antimikrobiální úprava ULTRAFRESH® chrání matraci navíc před plísněmi, viry, řasami a roztoči."
   },
   {
    "question": "Pomůže alergikům i chránič matrace?",
    "answer": "Ano. Pratelný chránič matrace zvyšuje hygienu lůžka, snadno se pere a spolu s antimikrobiální matrací výrazně snižuje množství alergenů."
   }
  ]
 },
 "/matrace/antidekubitni-matrace/": {
  "h1": "Antidekubitní matrace",
  "short": "Matrace, které rozloží tlak těla a pomáhají předcházet proleženinám u ležících lidí.",
  "long": [
   {
    "t": "p",
    "text": "Kdo tráví v posteli většinu dne – po operaci, s omezenou hybností nebo ve vyšším věku – je ohrožený vznikem proleženin (dekubitů). Ty vznikají tam, kde tělo dlouho tlačí na podložku: na kostrči, patách, lopatkách nebo bocích. Antidekubitní matrace rozloží váhu těla na co největší plochu a sníží tlak na tato riziková místa."
   },
   {
    "t": "p",
    "text": "Při výběru rozhoduje hmotnost a hybnost člověka, který na matraci bude ležet, a také to, zda se bude používat na polohovacím roštu. Antidekubitní matrace vám rádi doporučíme na kterékoli naší prodejně. Péči o ležícího člověka vždy konzultujte i s lékařem nebo zdravotní sestrou – matrace je důležitou součástí prevence, ale nenahrazuje pravidelné polohování."
   }
  ],
  "faq": [
   {
    "question": "K čemu slouží antidekubitní matrace?",
    "answer": "Antidekubitní matrace rozloží tlak těla na větší plochu a pomáhá předcházet proleženinám u lidí, kteří tráví v posteli většinu dne."
   },
   {
    "question": "Pro koho je antidekubitní matrace vhodná?",
    "answer": "Pro ležící a málo pohyblivé lidi, seniory a pacienty po operacích, u kterých hrozí vznik proleženin na kostrči, patách nebo bocích."
   },
   {
    "question": "Nahradí antidekubitní matrace polohování?",
    "answer": "Ne. Antidekubitní matrace je důležitou součástí prevence proleženin, ale pravidelné polohování a péči doporučenou lékařem nenahrazuje."
   }
  ]
 },
 "/matrace/matrace-na-miru/": {
  "h1": "Matrace na míru",
  "short": "Každou matraci z naší nabídky vyrobíme v rozměru, který potřebujete – na centimetr přesně.",
  "long": [
   {
    "t": "p",
    "text": "Postel na míru, starožitný rám nebo vestavba? Každou matraci z naší nabídky vyrobíme v jakémkoli rozměru s přesností na jeden centimetr. Stačí si vybrat model a požadovaný rozměr napsat do dotazu u produktu – náš tým vám obratem zašle cenu i potvrzení možnosti výroby. Matrace vyrábíme sami, takže se přizpůsobíme vašemu prostoru i potřebám."
   }
  ],
  "faq": [
   {
    "question": "Jak objednat matraci na míru?",
    "answer": "Vyberte model, do dotazu u produktu napište požadovaný rozměr a Světspánku.cz vám obratem pošle cenu a potvrzení možnosti výroby."
   },
   {
    "question": "Lze na míru vyrobit každou matraci?",
    "answer": "Matrace z vlastní výroby Světspánku.cz vyrobíme na míru vždy. U dovážených řad, například Don Almohadon, možnost atypu ověříme individuálně."
   },
   {
    "question": "Kolik stojí matrace na míru?",
    "answer": "Cenu matrace na míru počítáme podle rozměru a modelu a pošleme vám ji obratem po dotazu."
   }
  ]
 },
 "/matrace/matrace-na-miru/atypicke-rozmery/": {
  "h1": "Matrace v atypických rozměrech",
  "short": "Matrace v nestandardním rozměru, vyrobené na centimetr přesně.",
  "long": [
   {
    "t": "p",
    "text": "Starší postele, postele na míru nebo vestavěná lůžka často mají rozměr, který v obchodě neseženete. U nás není problém – matraci vyrobíme na centimetr přesně podle vašich rozměrů. Zvolíte model, tvrdost i rozměr a my se postaráme o zbytek."
   }
  ],
  "faq": [
   {
    "question": "Jak přesně změřit rozměr matrace na míru?",
    "answer": "Změřte vnitřní rozměr rámu postele, tedy ložnou plochu, na délku i šířku. Matrace by měla do rámu zapadnout bez větší mezery."
   },
   {
    "question": "Jak dlouho trvá výroba atypické matrace?",
    "answer": "Termín výroby atypické matrace potvrdíme při objednávce podle modelu a aktuální vytíženosti výroby."
   }
  ]
 },
 "/matrace/topper-horni-matrace/": {
  "h1": "Toppery – vrchní matrace",
  "short": "Vrchní matrace, které změkčí nebo zpevní lůžko a prodlouží životnost základní matrace.",
  "long": [
   {
    "t": "p",
    "text": "Topper neboli vrchní matrace či přistýlka je tenčí matrace, kterou položíte na tu stávající. Je to nejlevnější způsob, jak změnit pocit z postele bez kupování nové matrace."
   },
   {
    "t": "h",
    "text": "K čemu topper slouží"
   },
   {
    "t": "ul",
    "items": [
     "Změní tvrdost lůžka – měkký topper zjemní příliš tvrdou matraci, pevnější ji naopak zpevní.",
     "Spojí dvě matrace – topper přes celou šíři dvojlůžka zakryje spáru mezi dvěma matracemi.",
     "Prodlouží životnost matrace – vrchní vrstva přebírá opotřebení a chrání matraci.",
     "Hygiena – topper se snáz čistí a mění než celá matrace."
    ]
   },
   {
    "t": "h",
    "text": "Jak vybrat rozměr"
   },
   {
    "t": "p",
    "text": "Topper volte ve stejném rozměru jako lůžko. U dvojlůžka se dvěma matracemi 2× 90×200 vyberte topper 180×200, který obě matrace spojí."
   },
   {
    "t": "h",
    "text": "Kde se ještě hodí"
   },
   {
    "t": "p",
    "text": "Na chalupu, jako příležitostné lůžko pro hosty, na cesty nebo do auta."
   }
  ],
  "faq": [
   {
    "question": "K čemu je topper dobrý?",
    "answer": "Topper změní pocit tvrdosti lůžka, zakryje spáru mezi dvěma matracemi v dvojlůžku a prodlouží životnost matrace, protože přebírá opotřebení."
   },
   {
    "question": "Jaký rozměr topperu zvolit?",
    "answer": "Topper volte ve stejném rozměru jako lůžko. U dvojlůžka přes obě matrace, například topper 180×200 cm na dvě matrace 90×200."
   },
   {
    "question": "Lze topper použít samostatně?",
    "answer": "Ano, jako příležitostné lůžko pro hosty, na chalupu nebo na cesty. Na každodenní spaní ale topper matraci nenahradí."
   },
   {
    "question": "Pomůže topper u příliš tvrdé matrace?",
    "answer": "Ano. Měkčí topper z paměťové nebo studené pěny matraci zjemní a uleví ramenům a bokům, aniž byste museli kupovat novou matraci."
   }
  ]
 },
 "/matrace/chranice-a-potahy/": {
  "h1": "Chrániče a potahy na matrace",
  "short": "Pratelné chrániče a náhradní potahy, které prodlouží život vaší matrace.",
  "long": [
   {
    "t": "p",
    "text": "Matracové potahy jsou rozměrné a jejich čištění může být náročné. Chránič matrace se snadno sundá a vypere doma, takže lůžko udržíte čisté bez práce. Pokud je potah na matraci opotřebovaný, ale matrace je stále pohodlná, nemusíte kupovat novou – stačí vyměnit potah."
   }
  ],
  "faq": [
   {
    "question": "Proč používat chránič matrace?",
    "answer": "Chránič matrace chrání matraci před potem a nečistotami, snadno se pere v pračce a zvyšuje hygienu lůžka – hlavně u dětí a alergiků."
   },
   {
    "question": "Lze koupit jen nový potah na matraci?",
    "answer": "Ano. Světspánku.cz dodá náhradní potah na matraci na míru podle rozměru a výšky jádra, takže nemusíte kupovat novou matraci."
   }
  ]
 },
 "/matrace/chranice-matraci/": {
  "h1": "Chrániče matrací",
  "short": "Pratelné chrániče matrací s membránou i bez – snadná cesta k čistému lůžku.",
  "long": [
   {
    "t": "p",
    "text": "Chránič matrace je tenká pratelná vrstva, kterou natáhnete na matraci jako napínací prostěradlo. Matracové potahy jsou rozměrné a jejich praní je náročné – chránič se naopak snadno sundá a vypere doma v pračce."
   },
   {
    "t": "h",
    "text": "Proč chránič matrace používat"
   },
   {
    "t": "ul",
    "items": [
     "Chrání matraci před potem, kožním mazem a nečistotami.",
     "Zvyšuje hygienu lůžka – oceníte ho hlavně u dětí a alergiků.",
     "Prodlužuje životnost matrace a udrží ji déle jako novou."
    ]
   },
   {
    "t": "h",
    "text": "S membránou, nebo bez?"
   },
   {
    "t": "p",
    "text": "Chránič Rojo nabízíme ve dvou variantách. S nepropustnou membránou chrání matraci i před tekutinami – ideální do dětských postelí a pro starší lidi. Bez membrány je maximálně prodyšný a hodí se pro každodenní použití u dospělých, kteří se v noci potí."
   },
   {
    "t": "h",
    "text": "Jak často prát"
   },
   {
    "t": "p",
    "text": "Doporučujeme zhruba jednou měsíčně, u alergiků a dětí častěji. Chránič vybírejte ve stejném rozměru jako matraci."
   }
  ],
  "faq": [
   {
    "question": "Chránič matrace s membránou, nebo bez?",
    "answer": "Chránič s membránou chrání matraci i před tekutinami, proto je ideální pro děti a starší lidi. Chránič bez membrány je prodyšnější a hodí se pro dospělé, kteří se v noci potí."
   },
   {
    "question": "Jak často chránič matrace prát?",
    "answer": "Chránič matrace doporučujeme prát zhruba jednou měsíčně, u alergiků a dětí častěji."
   },
   {
    "question": "Jaký rozměr chrániče matrace zvolit?",
    "answer": "Chránič vybírejte ve stejném rozměru jako matraci. U dvojlůžka se dvěma matracemi použijte dva chrániče, každý na jednu matraci."
   }
  ]
 },
 "/matrace/potahy/": {
  "h1": "Náhradní potahy na matrace",
  "short": "Náhradní potahy na matrace podle rozměru a výšky jádra – stačí převléknout.",
  "long": [
   {
    "t": "p",
    "text": "Máte opotřebovaný, žmolkovatý nebo jinak poškozený potah, ale matrace je stále pohodlná? Není třeba kupovat novou matraci, stačí vyměnit potah. Vyberte rozměr a výšku jádra matrace (např. 200×90×18 cm) a my vám dodáme nový potah, který jen převléknete."
   }
  ],
  "faq": [
   {
    "question": "Jak zjistím, jaký potah na matraci potřebuji?",
    "answer": "Náhradní potah se vybírá podle rozměru matrace a výšky jádra bez potahu, například 200×90×18 cm."
   },
   {
    "question": "Vyrobíte potah i na matraci jiného výrobce?",
    "answer": "Ano. Pokud znáte přesné rozměry jádra matrace, potah vyrobíme na míru i pro matraci jiného výrobce."
   }
  ]
 },
 "/matrace/podle-ceny/": {
  "h1": "Matrace podle ceny",
  "short": "Matrace v akci a levné matrace pro hosty, chalupy a přistýlky.",
  "long": [
   {
    "t": "p",
    "text": "Ne každá matrace musí být na každodenní spaní v hlavní ložnici. Pro chalupu, pokoj pro hosty nebo přistýlku najdete levnější modely, a v akcích pak zlevněné matrace z celého sortimentu. Pokud chcete to nejlepší, podívejte se na prémiové řady."
   }
  ],
  "faq": [
   {
    "question": "Vyplatí se levná matrace?",
    "answer": "Na občasné spaní – pro hosty, na chalupu nebo do přistýlky – ano. Na každodenní spaní doporučujeme kvalitnější model, který vydrží déle a lépe podepře páteř."
   },
   {
    "question": "Jak často jsou matrace v akci?",
    "answer": "Akce na matrace Světspánku.cz průběžně obměňujeme. Aktuální nabídku najdete v kategorii Matrace v akci."
   }
  ]
 },
 "/akce/akcni-matrace/": {
  "h1": "Matrace v akci",
  "short": "Nejlepší akční nabídky matrací – slevy na oblíbené modely, doprodeje i novinky.",
  "long": [
   {
    "t": "p",
    "text": "V této kategorii najdete matrace za akční ceny z celého sortimentu. Zaměřujeme se na výrazné slevy u oblíbených modelů, doprodeje skladových zásob i akční ceny na novinky. Nabídku pravidelně obměňujeme, a tak se vyplatí se sem vracet."
   }
  ],
  "faq": [
   {
    "question": "Jsou akční matrace stejně kvalitní jako ostatní?",
    "answer": "Ano. Jde o běžné modely z nabídky Světspánku.cz se slevou nebo o doprodej skladových zásob."
   },
   {
    "question": "Platí na akční matrace 30 nocí jistoty?",
    "answer": "U vybraných akčních matrací 90×200 cm ano. Informaci, zda služba platí, najdete vždy u konkrétního produktu."
   }
  ]
 },
 "/matrace/levne-matrace/": {
  "h1": "Levné matrace",
  "short": "Levné matrace na chalupu, pro hosty, do pronájmů i do přistýlek.",
  "long": [
   {
    "t": "p",
    "text": "Levné matrace se hodí na chalupu, chatu, pro hosty, do studentských lůžek, pronájmů či podnájmů. Díky nižší výšce je můžete pohodlně využít i do přistýlek. Výhodné jsou zejména v akčních setech 1+1."
   }
  ],
  "faq": [
   {
    "question": "Na co jsou levné matrace vhodné?",
    "answer": "Levné matrace jsou vhodné na občasné spaní – na chalupu, pro hosty, do pronájmů a do přistýlek, kde oceníte i nižší výšku."
   },
   {
    "question": "Jsou levné matrace zdravotně nezávadné?",
    "answer": "Ano. I v levných matracích používá Světspánku.cz odzkoušené, zdravotně nezávadné materiály."
   }
  ]
 },
 "/lamelove-rosty/": {
  "h1": "Lamelové a laťkové rošty",
  "short": "Lamelové a laťkové rošty do postele – pevné, polohovací i motorové, ve všech rozměrech.",
  "long": [
   {
    "t": "p",
    "text": "Rošt je pro kvalitní spánek stejně důležitý jako matrace. Dává matraci oporu po celé ploše, odvětrává ji zespodu a pohlcuje část zatížení, čímž výrazně prodlužuje její životnost. Na nevhodném roštu ztrácí své vlastnosti i dobrá matrace."
   },
   {
    "t": "h",
    "text": "Typy roštů"
   },
   {
    "t": "ul",
    "items": [
     "Pevné lamelové rošty – pružné prohnuté lamely, u většiny modelů s nastavitelnou tvrdostí v bederní části.",
     "Polohovací rošty – zvednutí hlavy nebo hlavy i nohou ručně.",
     "Elektricky polohovací (motorové) rošty – polohování na dálkové ovládání.",
     "Laťkové rošty – rovné dřevěné latě, jednoduché a pevné; vyrábíme je ve vlastní dílně.",
     "Výklopné rošty – pro postele s úložným prostorem."
    ]
   },
   {
    "t": "h",
    "text": "Jaký rozměr roštu"
   },
   {
    "t": "p",
    "text": "Rošt má stejný rozměr jako matrace. Do jednolůžka patří jeden rošt, do dvojlůžka obvykle dva vedle sebe – například 2× 90×200 do postele 180×200. Každý z partnerů tak může mít jiný typ roštu, třeba jeden polohovací."
   },
   {
    "t": "h",
    "text": "Rošt a matrace"
   },
   {
    "t": "p",
    "text": "Na polohovací rošt patří ohebná matrace (pěnová, latexová nebo taštičková). Pod pěnové matrace se hodí lamelový i laťkový rošt."
   }
  ],
  "faq": [
   {
    "question": "Proč je rošt pod matrací důležitý?",
    "answer": "Rošt dává matraci oporu po celé ploše, odvětrává ji zespodu a pohlcuje část zatížení. Tím prodlužuje životnost matrace a pomáhá jí udržet vlastnosti."
   },
   {
    "question": "Jaký rošt do postele 180×200?",
    "answer": "Do postele 180×200 cm patří dva rošty 90×200 cm vedle sebe, každý pod jednou matrací. Každá polovina může mít jiný typ roštu."
   },
   {
    "question": "Jaký je rozdíl mezi lamelovým a laťkovým roštem?",
    "answer": "Lamelový rošt má pružné prohnuté lamely uložené v pouzdrech a lépe pruží. Laťkový rošt tvoří rovné dřevěné latě – je jednodušší, pevný a cenově dostupnější."
   },
   {
    "question": "Jaká matrace na polohovací rošt?",
    "answer": "Na polohovací rošt patří ohebná matrace – pěnová, latexová nebo taštičková, která se při zvednutí hlavy nebo nohou přizpůsobí."
   }
  ]
 },
 "/lamelove-rosty/podle-rozmeru/": {
  "h1": "Rošty podle rozměru",
  "short": "Rošty ve všech běžných rozměrech – vyberte podle velikosti matrace.",
  "long": [
   {
    "t": "p",
    "text": "Rošt má mít stejný rozměr jako matrace. Do jednolůžka patří jeden rošt, do dvojlůžka se obvykle dávají dva rošty vedle sebe – například 2× 80×200 cm do postele 160×200. Každý z partnerů tak může mít jiný typ roštu, třeba jeden polohovací. Atypické rozměry vyrobíme na míru."
   }
  ],
  "faq": [
   {
    "question": "Jaký rošt do postele 160×200?",
    "answer": "Do postele 160×200 cm patří dva rošty 80×200 cm vedle sebe, každý pod jednou matrací."
   },
   {
    "question": "Mohu mít v dvojlůžku každý jiný rošt?",
    "answer": "Ano. Každý z partnerů může mít jiný typ roštu, například jeden pevný a druhý polohovací."
   }
  ]
 },
 "/lamelove-rosty/rost-80x200/": {
  "h1": "Rošty 80×200 cm",
  "short": "Rošty 80×200 cm do užších jednolůžek a v páru do postelí 160×200.",
  "long": [
   {
    "t": "p",
    "text": "Rošt 80×200 cm patří pod matraci stejného rozměru – do užších jednolůžek, dětských a studentských postelí. Do manželské postele 160×200 cm se dávají dva rošty 80×200 vedle sebe."
   },
   {
    "t": "p",
    "text": "Vybírat můžete pevné lamelové rošty, polohovací rošty i laťkové rošty z naší dílny. Pod dětskou matraci se hodí jednoduchý laťkový rošt, pro dospělé doporučujeme lamelový rošt s nastavitelnou tvrdostí v bederní části."
   }
  ],
  "faq": [
   {
    "question": "Kolik roštů 80×200 do postele 160×200?",
    "answer": "Do postele 160×200 cm patří dva rošty 80×200 cm vedle sebe, každý pod jednou matrací 80×200."
   },
   {
    "question": "Jaký rošt 80×200 do dětské postele?",
    "answer": "Do dětské postele se hodí jednoduchý a pevný laťkový rošt, který Světspánku.cz vyrábí ve vlastní dílně."
   }
  ]
 },
 "/lamelove-rosty/rost-90x200/": {
  "h1": "Rošty 90×200 cm",
  "short": "Nejprodávanější rozměr roštu – 90×200 cm do jednolůžek i dvojlůžek 180×200.",
  "long": [
   {
    "t": "p",
    "text": "Rošt 90×200 cm je nejhledanější rozměr roštu. Jeden patří do jednolůžka, dva vedle sebe do nejoblíbenější manželské postele 180×200 cm."
   },
   {
    "t": "p",
    "text": "V rozměru 90×200 najdete všechny typy: pevné lamelové, ručně polohovací, elektricky polohovací i laťkové rošty. Protože v dvojlůžku má každý svůj rošt, můžete kombinovat – například pevný rošt pro jednoho a polohovací pro druhého, který rád čte v posteli."
   }
  ],
  "faq": [
   {
    "question": "Kolik roštů do postele 180×200?",
    "answer": "Do postele 180×200 cm patří dva rošty 90×200 cm vedle sebe."
   },
   {
    "question": "Mohu kombinovat polohovací a pevný rošt 90×200?",
    "answer": "Ano. Každá polovina postele může mít jiný rošt, třeba jednu stranu pevnou a druhou elektricky polohovací."
   }
  ]
 },
 "/lamelove-rosty/rost-100x200/": {
  "h1": "Rošty 100×200 cm",
  "short": "Rošty 100×200 cm do širších jednolůžek a dvojlůžek 200×200.",
  "long": [
   {
    "t": "p",
    "text": "Rošt 100×200 cm patří do širších jednolůžek a v páru do dvojlůžka 200×200 cm."
   },
   {
    "t": "p",
    "text": "Vybírat můžete pevné lamelové rošty s nastavitelnou tvrdostí v bederní části i polohovací varianty. Pro postel 200×200 cm zvolte dva rošty 100×200, které umožní každému z partnerů jiné nastavení."
   }
  ],
  "faq": [
   {
    "question": "Do jaké postele patří rošt 100×200?",
    "answer": "Rošt 100×200 cm patří do jednolůžka 100×200 nebo v páru do dvojlůžka 200×200 cm."
   },
   {
    "question": "Je rošt 100×200 i v polohovací variantě?",
    "answer": "Ano, u vybraných modelů nabízíme rošt 100×200 cm i jako polohovací."
   }
  ]
 },
 "/lamelove-rosty/rost-120x200/": {
  "h1": "Rošty 120×200 cm",
  "short": "Rošty 120×200 cm do širokých jednolůžek.",
  "long": [
   {
    "t": "p",
    "text": "Rošt 120×200 cm je určený pro široká jednolůžka. Podle konstrukce postele jde obvykle o jeden rošt v celé šíři."
   },
   {
    "t": "p",
    "text": "Vybírat můžete pevné i polohovací modely. Pokud má vaše postel atypický rozměr, laťkový rošt vám vyrobíme na míru ve vlastní dílně."
   }
  ],
  "faq": [
   {
    "question": "Je rošt 120×200 jeden kus?",
    "answer": "Ano. Do postele 120×200 cm se obvykle dává jeden rošt v celé šíři."
   },
   {
    "question": "Lze rošt 120×200 vyrobit na míru?",
    "answer": "Ano. Laťkové rošty vyrábí Světspánku.cz ve vlastní dílně, takže je připraví i v atypickém rozměru; u lamelových roštů připravíme nabídku na dotaz."
   }
  ]
 },
 "/lamelove-rosty/rost-140x200/": {
  "h1": "Rošty 140×200 cm",
  "short": "Rošty pro postel 140×200 cm – jeden velký, nebo dva 70×200.",
  "long": [
   {
    "t": "p",
    "text": "Do postele 140×200 cm se podle konstrukce dává buď jeden rošt v celé šíři, nebo dva rošty 70×200 cm."
   },
   {
    "t": "p",
    "text": "Dva rošty umožní každé polovině vlastní nastavení – jeden z partnerů může mít polohovací rošt a druhý pevný. Jeden rošt v celé šíři je zase jednodušší řešení pod jednu matraci 140×200."
   }
  ],
  "faq": [
   {
    "question": "Jeden rošt 140×200, nebo dva 70×200?",
    "answer": "Obojí je možné. Dva rošty 70×200 cm umožní rozdílné nastavení pro každou polovinu, jeden rošt v celé šíři je jednodušší pod jednu matraci."
   },
   {
    "question": "Jaký rošt pod postel 140×200 je nejoblíbenější?",
    "answer": "Nejčastěji pevný lamelový rošt s nastavitelnou tvrdostí v bederní části."
   }
  ]
 },
 "/lamelove-rosty/rost-160x200/": {
  "h1": "Rošty 160×200 cm",
  "short": "Rošty pro postel 160×200 cm – obvykle dva rošty 80×200.",
  "long": [
   {
    "t": "p",
    "text": "Do manželské postele 160×200 cm se obvykle dávají dva rošty 80×200 cm vedle sebe. Každý z partnerů tak může mít jiný rošt i jinou matraci."
   },
   {
    "t": "p",
    "text": "Kombinovat můžete pevné, ručně polohovací i elektricky polohovací rošty. Pokud má postel úložný prostor, zvolte výklopné rošty."
   }
  ],
  "faq": [
   {
    "question": "Kolik roštů do postele 160×200?",
    "answer": "Do postele 160×200 cm patří dva rošty 80×200 cm vedle sebe."
   },
   {
    "question": "Musí být oba rošty v posteli 160×200 stejné?",
    "answer": "Ne. Každý z partnerů může mít jiný typ roštu, například jeden polohovací."
   }
  ]
 },
 "/lamelove-rosty/rost-180x200/": {
  "h1": "Rošty 180×200 cm",
  "short": "Rošty pro postel 180×200 cm – dva rošty 90×200.",
  "long": [
   {
    "t": "p",
    "text": "Do nejoblíbenější manželské postele 180×200 cm patří dva rošty 90×200 cm."
   },
   {
    "t": "p",
    "text": "Kombinovat můžete pevné, ručně i elektricky polohovací rošty – každá polovina se nastaví podle potřeb jednoho z partnerů. U postele s úložným prostorem patří do rámu dva výklopné rošty, přes které se dostanete k úložnému prostoru až zhruba 1000 litrů."
   }
  ],
  "faq": [
   {
    "question": "Kolik roštů do postele 180×200?",
    "answer": "Do postele 180×200 cm patří dva rošty 90×200 cm vedle sebe."
   },
   {
    "question": "Lze mít jednu polovinu postele 180×200 elektricky polohovací?",
    "answer": "Ano. Rošty se dají kombinovat, takže jedna polovina může být elektricky polohovací a druhá pevná."
   }
  ]
 },
 "/lamelove-rosty/rosty-na-miru/": {
  "h1": "Rošty na míru",
  "short": "Rošty vyrobené na míru do postelí v nestandardních rozměrech.",
  "long": [
   {
    "t": "p",
    "text": "Postel v atypickém rozměru potřebuje i atypický rošt. Laťkové rošty vyrábíme sami, takže je dokážeme přizpůsobit přesně vaší posteli. Pro lamelové rošty v atypických rozměrech vám připravíme nabídku na dotaz."
   }
  ],
  "faq": [
   {
    "question": "Vyrobíte rošt na míru?",
    "answer": "Laťkové rošty vyrábí Světspánku.cz ve vlastní dílně, takže je připraví v atypickém rozměru. U lamelových roštů vám na dotaz připravíme nabídku."
   },
   {
    "question": "Jak změřit rozměr roštu?",
    "answer": "Změřte vnitřní rozměr rámu postele, tedy ložnou plochu, na délku i šířku."
   }
  ]
 },
 "/lamelove-rosty/lamelove-rosty-pevne/": {
  "h1": "Lamelové rošty pevné",
  "short": "Pevné lamelové rošty bez polohování – spolehlivý základ pro každou matraci.",
  "long": [
   {
    "t": "p",
    "text": "Pevné lamelové rošty zajišťují matraci správnou oporu po celé ploše. Pružné lamely pohlcují část zatížení, matraci odvětrávají a výrazně prodlužují její životnost. Většina modelů má v bederní části nastavitelnou tvrdost lamel, takže rošt přizpůsobíte své postavě."
   }
  ],
  "faq": [
   {
    "question": "Proč lamelový rošt prodlužuje životnost matrace?",
    "answer": "Pružné lamely pohlcují část zatížení a matrace je zespodu odvětraná, takže se méně opotřebovává a déle drží tvar."
   },
   {
    "question": "Lze u lamelového roštu nastavit tvrdost?",
    "answer": "U většiny pevných lamelových roštů ano – v bederní části pomocí posuvných jezdců, kterými rošt přizpůsobíte své postavě."
   }
  ]
 },
 "/lamelove-rosty/lamelove-rosty-polohovaci/": {
  "h1": "Polohovací lamelové rošty",
  "short": "Rošty s polohováním hlavy, hlavy a nohou, ručně nebo elektricky.",
  "long": [
   {
    "t": "p",
    "text": "Polohovací rošty umožňují zvednout hlavovou nebo nožní část lůžka. Oceníte je při čtení či sledování televize v posteli, při odpočinku nohou a u některých zdravotních potíží."
   },
   {
    "t": "h",
    "text": "Ruční, nebo elektrické polohování?"
   },
   {
    "t": "ul",
    "items": [
     "Ručně polohovací rošt – část roštu zvednete rukou a zajistí se v požadované poloze. Nepotřebuje elektřinu, je spolehlivý a cenově dostupnější.",
     "Elektricky polohovací (motorový) rošt – polohu hlavy i nohou nastavíte tlačítkem na dálkovém ovladači, bez námahy. Ocení ho hlavně senioři a lidé po operacích. Potřebuje zásuvku u postele."
    ]
   },
   {
    "t": "h",
    "text": "Jaká matrace na polohovací rošt"
   },
   {
    "t": "p",
    "text": "Ohebná matrace – pěnová, latexová nebo taštičková. V dvojlůžku může mít polohovací rošt jen jedna polovina."
   },
   {
    "t": "h",
    "text": "Polohovací rošt a úložný prostor"
   },
   {
    "t": "p",
    "text": "U postelí s úložným prostorem je potřeba výklopný rošt. Kombinaci polohování a úložného prostoru s vámi rádi probereme na prodejně."
   }
  ],
  "faq": [
   {
    "question": "Jaká matrace na polohovací rošt?",
    "answer": "Na polohovací rošt patří ohebná matrace – pěnová, latexová nebo taštičková, která se při zvednutí hlavy nebo nohou přizpůsobí."
   },
   {
    "question": "Jaký je rozdíl mezi ručně a elektricky polohovacím roštem?",
    "answer": "Ručně polohovací rošt nastavíte zvednutím části roštu rukou, elektrický (motorový) rošt tlačítkem na dálkovém ovladači bez námahy. Elektrický rošt potřebuje zásuvku."
   },
   {
    "question": "Lze polohovací rošt dát do postele s úložným prostorem?",
    "answer": "U postelí s úložným prostorem je potřeba výklopný rošt. Možnou kombinaci s polohováním vám poradíme na prodejně."
   }
  ]
 },
 "/lamelove-rosty/lamelove-rosty-polohovaci/manualne-polohovaci/": {
  "h1": "Manuálně polohovací rošty",
  "short": "Rošty s ručním polohováním hlavy nebo hlavy i nohou.",
  "long": [
   {
    "t": "p",
    "text": "Manuálně polohovací rošty nastavíte jednoduše rukou – stačí zvednout hlavovou nebo nožní část do požadované polohy. Nepotřebují elektřinu, jsou spolehlivé a cenově dostupnější než motorové varianty."
   }
  ],
  "faq": [
   {
    "question": "Jak se ručně polohovací rošt nastavuje?",
    "answer": "Hlavovou nebo nožní část roštu zvednete rukou do požadované polohy, ve které se zajistí. Nepotřebujete elektřinu ani ovladač."
   },
   {
    "question": "Polohuje se u ručního roštu i nožní část?",
    "answer": "U vybraných modelů ano – polohovat lze hlavu i nohy."
   }
  ]
 },
 "/lamelove-rosty/lamelove-rosty-motorove/": {
  "h1": "Elektricky polohovací (motorové) rošty",
  "short": "Motorové rošty s polohováním na dálkové ovládání – nejvyšší komfort.",
  "long": [
   {
    "t": "p",
    "text": "Elektricky polohovací rošty nabízejí nejvyšší komfort. Polohu hlavy i nohou nastavíte jedním tlačítkem na dálkovém ovládání, bez námahy. Ocení je senioři, lidé po operacích i všichni, kdo v posteli rádi čtou nebo sledují televizi."
   }
  ],
  "faq": [
   {
    "question": "Jak se motorový rošt ovládá?",
    "answer": "Elektricky polohovací rošt se ovládá dálkovým ovladačem – polohu hlavy i nohou nastavíte jedním tlačítkem."
   },
   {
    "question": "Potřebuje elektrický rošt zásuvku u postele?",
    "answer": "Ano. Motor elektricky polohovacího roštu se napájí ze sítě, proto počítejte se zásuvkou poblíž postele."
   }
  ]
 },
 "/lamelove-rosty/latkove-rosty/": {
  "h1": "Laťkové rošty z masivu",
  "short": "Pevné laťkové rošty z masivu, které vyrábíme ve vlastní dílně.",
  "long": [
   {
    "t": "p",
    "text": "Laťkový rošt tvoří rovné dřevěné latě. Je jednoduchý, pevný a cenově dostupný a dobře se hodí pod pěnové matrace i do dětských postelí. Laťkové rošty vyrábíme sami, takže je dokážeme připravit i v atypickém rozměru."
   }
  ],
  "faq": [
   {
    "question": "Pro jakou matraci je laťkový rošt vhodný?",
    "answer": "Laťkový rošt je vhodný hlavně pod pěnové matrace a do dětských postelí, kde stačí pevná a rovná podložka."
   },
   {
    "question": "Vyrobíte laťkový rošt na míru?",
    "answer": "Ano. Laťkové rošty vyrábí Světspánku.cz ve vlastní dílně, takže je připraví i v atypickém rozměru."
   }
  ]
 },
 "/lamelove-rosty/vyklopne-rosty/": {
  "h1": "Výklopné rošty pro úložný prostor",
  "short": "Rošty, které se vyklápějí a otevírají přístup k úložnému prostoru pod postelí.",
  "long": [
   {
    "t": "p",
    "text": "Výklopný rošt je nezbytnou součástí postele s úložným prostorem. Zvedá se lehce a drží v otevřené poloze, takže se k věcem pod postelí dostanete pohodlně. V kombinaci s naším úložným prostorem získáte u postele 180×200 cm až zhruba 1000 litrů místa. Rošt i úložný prostor lze koupit jako set."
   }
  ],
  "faq": [
   {
    "question": "Potřebuji k úložnému prostoru výklopný rošt?",
    "answer": "Ano. Výklopný rošt je součástí postele s úložným prostorem – právě přes něj se k věcem pod postelí dostanete."
   },
   {
    "question": "Drží výklopný rošt sám otevřený?",
    "answer": "Ano. Výklopné rošty se zvedají lehce a drží v otevřené poloze, takže máte obě ruce volné."
   }
  ]
 },
 "/komplety-akce/": {
  "h1": "Postele s matrací a roštem – výhodné komplety",
  "short": "Postel z masivu, rošt a matrace v jednom sladěném setu – výhodněji než při nákupu zvlášť.",
  "long": [
   {
    "t": "p",
    "text": "Hledáte jednoduché a kvalitní řešení pro celou postel? Komplety Světspánku.cz spojují to nejdůležitější – postel z masivu, rošt a matraci – v jednom sladěném setu za zvýhodněnou cenu. Rošt i matrace k posteli přesně sedí rozměrem i typem, takže nemusíte nic dalšího řešit."
   },
   {
    "t": "h",
    "text": "Co komplet obsahuje"
   },
   {
    "t": "p",
    "text": "Postel z masivního buku, jasanu nebo dubu z naší dílny, rošt a matraci. U dvojlůžek jsou v kompletu obvykle dva rošty a dvě matrace, aby si každý z partnerů mohl zvolit vlastní tvrdost."
   },
   {
    "t": "h",
    "text": "Jak komplet vybrat"
   },
   {
    "t": "ul",
    "items": [
     "Podle rozpočtu – komplety do 22 000 Kč, 22–33 tisíc, 33–44 tisíc a luxusní sestavy nad 44 000 Kč.",
     "Podle výbavy – komplety s úložným prostorem a výklopným roštem.",
     "Pro děti – dětské a patrové komplety s dětskými matracemi bez lepidel."
    ]
   },
   {
    "t": "h",
    "text": "Dovoz a montáž"
   },
   {
    "t": "p",
    "text": "Komplet vám dovezeme a smontujeme. Celou sestavu si můžete předem vyzkoušet na některé z pěti prodejen v Brně, Praze, Olomouci a Ostravě."
   }
  ],
  "faq": [
   {
    "question": "Co obsahuje komplet postele s matrací a roštem?",
    "answer": "Komplet obsahuje postel z masivu, rošt a matraci – u dvojlůžek obvykle dva rošty a dvě matrace, takže si každý z partnerů zvolí vlastní tvrdost."
   },
   {
    "question": "O kolik je komplet výhodnější než nákup zvlášť?",
    "answer": "Komplet vychází levněji než stejné položky koupené zvlášť. Konkrétní úsporu najdete u každého setu."
   },
   {
    "question": "Mohu v kompletu změnit matraci?",
    "answer": "Ano. U většiny kompletů Světspánku.cz si můžete zvolit jinou tvrdost nebo typ matrace."
   },
   {
    "question": "Dovezete a smontujete komplet?",
    "answer": "Ano, komplet postele s roštem a matrací vám dovezeme a smontujeme."
   }
  ]
 },
 "/komplety-akce/podle-ceny/": {
  "h1": "Komplety podle ceny",
  "short": "Vyberte komplet podle rozpočtu – od cenově dostupných sestav po luxusní.",
  "long": [
   {
    "t": "p",
    "text": "Když kupujete celou postel najednou, rozpočet je obvykle první otázka. Komplety proto řadíme do čtyř cenových pásem. V každém najdete sestavy z masivního dřeva s roštem a matrací – liší se provedením postele a třídou matrací."
   }
  ],
  "faq": [
   {
    "question": "Čím se liší levnější a dražší komplety?",
    "answer": "Levnější komplety mají jednodušší provedení postele a základní třídu matrací, dražší propracovanější postele a pokročilejší matrace. Masivní dřevo je ve všech."
   },
   {
    "question": "Lze komplet doplnit úložným prostorem?",
    "answer": "Ano. Úložný prostor lze ke kompletu doplnit, nebo rovnou vyberte komplet s úložným prostorem a výklopným roštem."
   }
  ]
 },
 "/komplety-akce/do-22000/": {
  "h1": "Komplety postelí s matracemi do 22 000 Kč",
  "short": "Poctivý masiv a kvalitní matrace nemusí stát jmění – komplety do 22 000 Kč.",
  "long": [
   {
    "t": "p",
    "text": "Hledáte kompletní postel s matracemi za rozumnou cenu, ale nechcete dělat kompromisy v kvalitě? Komplety do 22 000 Kč spojují masivní dřevo, kvalitní rošty a zdravotně nezávadné matrace do jednoho výhodného balíčku."
   }
  ],
  "faq": [
   {
    "question": "Co obsahuje komplet v cenovém pásmu do 22 000 Kč?",
    "answer": "Komplet v pásmu do 22 000 Kč obsahuje postel z masivu, rošt a matraci – u dvojlůžek dva rošty a dvě matrace – za zvýhodněnou cenu oproti nákupu zvlášť."
   },
   {
    "question": "Platí cenové pásmo do 22 000 Kč pro všechny rozměry?",
    "answer": "Cena kompletu se liší podle rozměru postele. Pásmo do 22 000 Kč se vztahuje k ceně celé sestavy v nabízeném rozměru."
   }
  ]
 },
 "/komplety-akce/do-33000/": {
  "h1": "Komplety postelí s matracemi 22 000 – 33 000 Kč",
  "short": "Nejlepší poměr ceny, designu a pohodlí – dlouhodobě nejoblíbenější komplety.",
  "long": [
   {
    "t": "p",
    "text": "Komplety v tomto pásmu patří dlouhodobě mezi nejoblíbenější volby našich zákazníků. Nabízejí ideální kombinaci kvalitního masivního dřeva, atraktivního designu a komfortních matrací, které společně vytvářejí spolehlivý základ pro zdravý spánek."
   }
  ],
  "faq": [
   {
    "question": "Co obsahuje komplet v cenovém pásmu 22 000 – 33 000 Kč?",
    "answer": "Komplet v pásmu 22 000 – 33 000 Kč obsahuje postel z masivu, rošt a matraci – u dvojlůžek dva rošty a dvě matrace – za zvýhodněnou cenu oproti nákupu zvlášť."
   },
   {
    "question": "Platí cenové pásmo 22 000 – 33 000 Kč pro všechny rozměry?",
    "answer": "Cena kompletu se liší podle rozměru postele. Pásmo 22 000 – 33 000 Kč se vztahuje k ceně celé sestavy v nabízeném rozměru."
   }
  ]
 },
 "/komplety-akce/do-44000/": {
  "h1": "Komplety postelí s matracemi 33 000 – 44 000 Kč",
  "short": "Nadstandardní ložnice pro náročné spáče.",
  "long": [
   {
    "t": "p",
    "text": "Komplety pro všechny, kdo od své ložnice očekávají víc než jen místo ke spánku. Spojují precizně zpracované postele z masivního dřeva s pokročilými matracemi vyšší třídy a vytvářejí prostor pro skutečně komfortní odpočinek."
   }
  ],
  "faq": [
   {
    "question": "Co obsahuje komplet v cenovém pásmu 33 000 – 44 000 Kč?",
    "answer": "Komplet v pásmu 33 000 – 44 000 Kč obsahuje postel z masivu, rošt a matraci – u dvojlůžek dva rošty a dvě matrace – za zvýhodněnou cenu oproti nákupu zvlášť."
   },
   {
    "question": "Platí cenové pásmo 33 000 – 44 000 Kč pro všechny rozměry?",
    "answer": "Cena kompletu se liší podle rozměru postele. Pásmo 33 000 – 44 000 Kč se vztahuje k ceně celé sestavy v nabízeném rozměru."
   }
  ]
 },
 "/komplety-akce/nad-44000/": {
  "h1": "Luxusní komplety postelí s matracemi",
  "short": "Vrchol naší nabídky – špičkové postele z masivu s nejpokročilejšími matracemi.",
  "long": [
   {
    "t": "p",
    "text": "Prvotřídní luxus a nekompromisní péče o spánek. Komplety nad 44 000 Kč spojují špičkové postele z masivního dřeva s nejpokročilejšími matracemi a vytvářejí prostředí, ve kterém se kvalitní spánek stává každodenní samozřejmostí."
   }
  ],
  "faq": [
   {
    "question": "Co obsahuje komplet v cenovém pásmu nad 44 000 Kč?",
    "answer": "Komplet v pásmu nad 44 000 Kč obsahuje postel z masivu, rošt a matraci – u dvojlůžek dva rošty a dvě matrace – za zvýhodněnou cenu oproti nákupu zvlášť."
   },
   {
    "question": "Platí cenové pásmo nad 44 000 Kč pro všechny rozměry?",
    "answer": "Cena kompletu se liší podle rozměru postele. Pásmo nad 44 000 Kč se vztahuje k ceně celé sestavy v nabízeném rozměru."
   }
  ]
 },
 "/komplety-akce/komplet-postel-s-matracemi/": {
  "h1": "Postel s matrací a roštem – komplety z masivu",
  "short": "Postel z masivu, rošt a matrace v jednom sladěném setu se slevou.",
  "long": [
   {
    "t": "p",
    "text": "Postel s matrací a roštem v jednom kompletu je nejjednodušší cesta k nové posteli. Nemusíte řešit, jestli rošt sedí na rám, jestli matrace odpovídá roštu a jestli bude vše stejně vysoké – komplety Světspánku.cz jsou sladěné do posledního detailu."
   },
   {
    "t": "h",
    "text": "Proč koupit postel s matrací a roštem najednou"
   },
   {
    "t": "ul",
    "items": [
     "Výhodnější cena než při nákupu jednotlivých kusů.",
     "Jistota, že rošt i matrace k posteli rozměrově i typově sedí.",
     "Jedna dodávka a jedna montáž."
    ]
   },
   {
    "t": "h",
    "text": "Jak komplet vybrat"
   },
   {
    "t": "p",
    "text": "Nejprve zvolte rozměr – nejčastěji 160×200 nebo 180×200 cm pro dva, 90×200 cm pro jednoho. Pak tvrdost matrace podle hmotnosti a polohy spánku; u dvojlůžek si každý z partnerů vybere vlastní. Nakonec dřevinu a odstín postele."
   },
   {
    "t": "h",
    "text": "Kvalita"
   },
   {
    "t": "p",
    "text": "Postele z masivního buku, jasanu nebo dubu vyrábíme ve vlastní dílně bez dřevotřísky, matrace z odzkoušených zdravotně nezávadných materiálů."
   }
  ],
  "faq": [
   {
    "question": "Jaké rozměry kompletů postele s matrací nabízíte?",
    "answer": "Nejčastěji 140×200, 160×200 a 180×200 cm pro dva a 90×200 cm pro jednoho. Další rozměry na dotaz."
   },
   {
    "question": "Mohu v kompletu zvolit jinou tvrdost matrace?",
    "answer": "Ano. U většiny kompletů Světspánku.cz si tvrdost matrace vyberete, u dvojlůžek každý z partnerů zvlášť."
   },
   {
    "question": "Proč koupit postel, rošt a matraci jako komplet?",
    "answer": "Komplet vyjde levněji než nákup zvlášť a máte jistotu, že rošt i matrace k posteli rozměrově i typově sedí."
   }
  ]
 },
 "/komplety-akce/komplet-s-uloznym-prostorem/": {
  "h1": "Postele s úložným prostorem, matrací a roštem",
  "short": "Komplet postele z masivu s úložným prostorem, výklopným roštem a matracemi.",
  "long": [
   {
    "t": "p",
    "text": "Komplety s úložným prostorem jsou ideální volbou pro každého, kdo chce spojit kvalitní spánek s praktickým využitím ložnice. V každém setu najdete postel z masivu, výklopný rošt a matraci – a navíc prostorný úložný prostor, který u rozměru 180×200 cm pojme až zhruba 1000 litrů."
   }
  ],
  "faq": [
   {
    "question": "Kolik místa nabízí komplet s úložným prostorem?",
    "answer": "U postele 180×200 cm až zhruba 1000 litrů úložného prostoru pod ložnou plochou."
   },
   {
    "question": "Je v kompletu s úložným prostorem výklopný rošt?",
    "answer": "Ano. Výklopný rošt je součástí kompletu, aby se k úložnému prostoru dalo snadno dostat."
   }
  ]
 },
 "/komplety-akce/detske-a-patrove-komplety/": {
  "h1": "Dětské a patrové komplety",
  "short": "Dětské a patrové postele z masivu rovnou s rošty a dětskými matracemi.",
  "long": [
   {
    "t": "p",
    "text": "Zařizujete dětský pokoj? Dětské a patrové komplety obsahují postel z masivu, rošty a dětské matrace bez lepidel – vše sladěné a za výhodnější cenu než při nákupu zvlášť. Masivní konstrukce vydrží skákání i několik dětí po sobě."
   }
  ],
  "faq": [
   {
    "question": "Jsou matrace v dětském kompletu bez lepidel?",
    "answer": "Ano. Dětské matrace v kompletech Světspánku.cz jsou vyrobené bez lepidel z bezpečných materiálů."
   },
   {
    "question": "Obsahuje patrový komplet matrace pro obě lůžka?",
    "answer": "Ano. Patrový komplet obsahuje rošty i matrace pro obě lůžka."
   }
  ]
 },
 "/komplety-akce/set-loznice/": {
  "h1": "Ložnice z masivu jako set",
  "short": "Postel, noční stolky, komoda i skříň v jednom sladěném setu ze stejného masivu.",
  "long": [
   {
    "t": "p",
    "text": "Chcete ložnici, kde vše ladí? Sety ložnice spojují postel, noční stolky, komodu a skříň ze stejného masivního dřeva a ve stejném odstínu. Vše vyrábíme v naší dílně, takže ložnici přizpůsobíme i rozměrům vašeho pokoje."
   }
  ],
  "faq": [
   {
    "question": "Lze set ložnice z masivu upravit na míru?",
    "answer": "Ano. Rozměry jednotlivých kusů – postele, komody i skříně – lze přizpůsobit vašemu pokoji."
   },
   {
    "question": "Budou všechny kusy setu ve stejném odstínu?",
    "answer": "Ano. Celý set ložnice vyrábíme ze stejné dřeviny a ve stejném odstínu."
   }
  ]
 },
 "/nabytek/": {
  "h1": "Nábytek z masivu do ložnice",
  "short": "Komody, noční stolky, skříně a police z masivu – ve stejných dřevinách a odstínech jako naše postele.",
  "long": [
   {
    "t": "p",
    "text": "Dokonalá ložnice potřebuje víc než postel. Nábytek z naší dílny vyrábíme ze stejného masivního buku, jasanu a dubu jako postele, takže vše ladí odstínem i stylem. Dřevotřísku nepoužíváme ani tam, kde není vidět – skříně mají celodřevěný korpus, dveře i police."
   },
   {
    "t": "p",
    "text": "Vybírat můžete komody s celovýsuvy a dojezdem, které dodáváme už smontované, noční stolky se zásuvkou i bez, závěsné stolky a police na zeď, samostatně stojící šatní skříně i s posuvnými dveřmi a dětský nábytek, který roste s dítětem. Ložnici doplní zrcadla v masivním rámu a dřevěné hodiny."
   }
  ],
  "faq": [
   {
    "question": "Je nábytek Světspánku.cz ve stejném odstínu jako postele?",
    "answer": "Ano. Komody, noční stolky, skříně a police vyrábíme ze stejných dřevin – buku, jasanu a dubu – a ve stejných odstínech jako postele, takže ložnice ladí."
   },
   {
    "question": "Používáte v nábytku dřevotřísku?",
    "answer": "Ne. Dřevotřísku Světspánku.cz nepoužívá ani v částech, které nejsou vidět – skříně mají celodřevěný korpus, dveře i police."
   },
   {
    "question": "Dodáváte komody smontované?",
    "answer": "Ano. Komody dodáváme kompletně smontované, takže odpadne skládání."
   },
   {
    "question": "Lze nábytek z masivu vyrobit na míru?",
    "answer": "Ano. Nejčastěji upravujeme rozměry komod; možnosti úprav posoudíme podle konstrukce."
   }
  ]
 },
 "/nabytek/komody/": {
  "h1": "Komody z masivu",
  "short": "Komody z masivu se skrytými celovýsuvy s dojezdem – dodáváme už smontované.",
  "long": [
   {
    "t": "p",
    "text": "Komoda z masivu je úložný nábytek, který vydrží generace. Komody Světspánku.cz vyrábíme ve vlastní dílně z masivního buku, jasanu a dubu, bez dřevotřísky – a to ani v částech, které nejsou vidět."
   },
   {
    "t": "h",
    "text": "Zásuvky, které vydrží"
   },
   {
    "t": "p",
    "text": "Zásuvky jezdí na skrytých celovýsuvech s tichým dojezdem. Otevřou se celé, takže vidíte až na dno, a zavřou se samy bez bouchnutí."
   },
   {
    "t": "h",
    "text": "Smontované a na míru"
   },
   {
    "t": "p",
    "text": "Komody dodáváme kompletně smontované, takže odpadnou hodiny skládání. Rozměry komody umíme upravit na míru – je to vůbec nejčastější zakázková úprava, kterou děláme."
   },
   {
    "t": "h",
    "text": "Jakou komodu vybrat"
   },
   {
    "t": "ul",
    "items": [
     "Komody se zásuvkami – nejpraktičtější na prádlo a drobnosti.",
     "Komody s dveřmi – police za dvířky na objemnější věci, kombinované modely i se zásuvkami.",
     "Závěsné komody a skříňky – volná podlaha a vzdušný vzhled."
    ]
   },
   {
    "t": "p",
    "text": "Komody se hodí do ložnice, obýváku, předsíně i dětského pokoje a ladí s postelemi, nočními stolky a skříněmi ve stejném odstínu."
   },
   {
    "t": "h",
    "text": "Jak vybrat velikost komody"
   },
   {
    "t": "p",
    "text": "Před nákupem si změřte místo – šířku, ale i hloubku, aby šlo zásuvky vysunout celé a kolem komody se dalo projít. Nízká a široká komoda se hodí pod televizi nebo pod okno, vyšší a užší ušetří místo v předsíni či menší ložnici. Pokud žádná velikost nesedí, upravíme rozměr na míru."
   },
   {
    "t": "h",
    "text": "Péče o nábytek z masivu"
   },
   {
    "t": "p",
    "text": "Masivní dřevo je živý materiál. Stačí ho otírat suchým nebo mírně navlhčeným hadříkem, nepoužívat agresivní čisticí prostředky a nestavět nábytek přímo k topení. Drobné rozdíly v kresbě a odstínu mezi kusy jsou přirozenou vlastností masivu, ne vadou."
   }
  ],
  "faq": [
   {
    "question": "Jsou komody z masivu dodávané smontované?",
    "answer": "Ano. Komody Světspánku.cz dodáváme kompletně smontované, takže je jen postavíte na místo."
   },
   {
    "question": "Lze komodu vyrobit v jiném rozměru?",
    "answer": "Ano. Úprava rozměrů komod je nejčastější zakázková úprava, kterou ve vlastní dílně děláme."
   },
   {
    "question": "Mají zásuvky komod dojezd?",
    "answer": "Ano. Zásuvky jezdí na skrytých celovýsuvech s tichým dojezdem, otevřou se celé a zavřou se bez bouchnutí."
   },
   {
    "question": "Je komoda celá z masivu?",
    "answer": "Ano. Komody vyrábíme z masivního buku, jasanu nebo dubu bez dřevotřísky, a to ani v částech, které nejsou vidět."
   }
  ]
 },
 "/nabytek/komody/komody-se-zasuvkami/": {
  "h1": "Komody se zásuvkami z masivu",
  "short": "Komody se zásuvkami na celovýsuvech – prostor na prádlo i drobnosti.",
  "long": [
   {
    "t": "p",
    "text": "Klasická komoda se zásuvkami je nejpraktičtější úložný nábytek do ložnice. Zásuvky na skrytých celovýsuvech s dojezdem se otevírají celé, takže vidíte až na dno. Vybírat můžete z různých šířek a počtu zásuvek."
   }
  ],
  "faq": [
   {
    "question": "Otevírají se zásuvky komody celé?",
    "answer": "Ano. Díky celovýsuvům se zásuvky komody otevřou celé a vidíte až na dno."
   },
   {
    "question": "Kolik zásuvek komody mají?",
    "answer": "Počet zásuvek závisí na modelu – přehled najdete v detailu každé komody."
   }
  ]
 },
 "/nabytek/komody/komody-s-dvermi/": {
  "h1": "Komody s dveřmi z masivu",
  "short": "Komody s dvířky a policemi – i v kombinaci se zásuvkami.",
  "long": [
   {
    "t": "p",
    "text": "Komody s dveřmi skryjí za dvířky police na větší věci. Kombinované modely spojují dvířka a zásuvky v jednom kusu nábytku, takže máte místo na prádlo i na objemnější předměty."
   }
  ],
  "faq": [
   {
    "question": "Mají komody s dveřmi i zásuvky?",
    "answer": "Kombinované modely ano – spojují police za dvířky se zásuvkami v jednom kusu nábytku."
   },
   {
    "question": "Lze police uvnitř komody přestavit?",
    "answer": "Záleží na modelu. Informaci o polohování polic najdete v detailu konkrétní komody."
   }
  ]
 },
 "/nabytek/komody/zavesne-komody-a-skrinky/": {
  "h1": "Závěsné komody a skříňky z masivu",
  "short": "Závěsné komody a skříňky na zeď – lehký vzhled a volná podlaha.",
  "long": [
   {
    "t": "p",
    "text": "Závěsné komody a skříňky šetří místo a ložnice působí vzdušně. Pod nimi zůstane volná podlaha, takže se snadno uklízí. Vyrábíme je ze stejného masivu jako ostatní nábytek."
   }
  ],
  "faq": [
   {
    "question": "Jak se závěsná komoda připevňuje?",
    "answer": "Závěsná komoda se připevňuje na zeď pomocí kotev. Doporučujeme pevnou, ideálně nosnou zeď."
   },
   {
    "question": "Unese závěsná komoda těžší věci?",
    "answer": "Ano, při správném ukotvení do pevné zdi unese i těžší věci."
   }
  ]
 },
 "/nabytek/nocni-stolky-a-police/": {
  "h1": "Noční stolky z masivu",
  "short": "Noční stolky z masivu se zásuvkou, bez zásuvky i závěsné – ve stejném odstínu jako postel.",
  "long": [
   {
    "t": "p",
    "text": "Noční stolek patří k posteli stejně jako matrace. Noční stolky Světspánku.cz jsou z masivního dřeva, takže se nebudete bát položit na ně víc než knihu, a vyrábíme je ve stejných dřevinách a odstínech jako postele."
   },
   {
    "t": "h",
    "text": "Jaký noční stolek vybrat"
   },
   {
    "t": "ul",
    "items": [
     "Se zásuvkou – knihy, brýle, nabíječka i léky po ruce, ale ne na očích.",
     "Bez zásuvky – jednoduchý vzdušný tvar s otevřenou policí, hodí se do minimalistických ložnic.",
     "Závěsný na zeď – pod stolkem zůstane volná podlaha a snadno se uklízí; výšku umístění zvolíte podle postele."
    ]
   },
   {
    "t": "h",
    "text": "Jak vysoký má noční stolek být"
   },
   {
    "t": "p",
    "text": "Ideálně v úrovni horní hrany matrace nebo mírně nad ní, aby se na něj dalo pohodlně sáhnout vleže. U závěsných stolků výšku nastavíte přesně."
   },
   {
    "t": "h",
    "text": "Alternativy"
   },
   {
    "t": "p",
    "text": "Funkci nočního stolku skvěle plní i masivní police na zeď. A pokud chcete stolky rovnou v posteli, vyberte postel s nočními stolky zabudovanými v rozšířeném čele."
   },
   {
    "t": "h",
    "text": "Kolik místa nechat vedle postele"
   },
   {
    "t": "p",
    "text": "Mezi postelí a stěnou počítejte alespoň s 50–60 cm, aby se pohodlně vstávalo. Do užší mezery se vejde závěsný stolek nebo police; pod nimi zůstane podlaha volná a stolek nepřekáží nohám."
   },
   {
    "t": "h",
    "text": "Noční stolky k posteli, kterou už máte"
   },
   {
    "t": "p",
    "text": "Noční stolky z masivu vyrábíme ve stejných dřevinách a odstínech jako postele Světspánku.cz. Pokud máte postel od nás, stolky k ní budou ladit; k posteli od jiného výrobce vyberte odstín na prodejně podle vzorků."
   }
  ],
  "faq": [
   {
    "question": "Budou noční stolky ladit s postelí?",
    "answer": "Ano. Noční stolky vyrábí Světspánku.cz ze stejných dřevin a ve stejných odstínech jako postele."
   },
   {
    "question": "Jak vysoký má noční stolek být?",
    "answer": "Noční stolek by měl být zhruba v úrovni horní hrany matrace nebo mírně nad ní, aby se na něj dalo pohodlně sáhnout vleže."
   },
   {
    "question": "Mohu místo nočního stolku použít polici?",
    "answer": "Ano. Masivní police na zeď poslouží jako úsporný noční stolek, hlavně v menších ložnicích."
   },
   {
    "question": "Existuje postel s nočními stolky v čele?",
    "answer": "Ano. Postele s integrovanými nočními stolky najdete v kategorii postelí z masivu."
   }
  ]
 },
 "/nabytek/nocni-stolky-a-police/se-zasuvkami/": {
  "h1": "Noční stolky se zásuvkami",
  "short": "Noční stolky se zásuvkou – místo na knihy, brýle i nabíječku.",
  "long": [
   {
    "t": "p",
    "text": "Zásuvka v nočním stolku schová všechno, co chcete mít u postele po ruce, ale ne na očích. Stolky se zásuvkami vyrábíme z masivu se stejnou kvalitou kování jako komody."
   }
  ],
  "faq": [
   {
    "question": "Má zásuvka nočního stolku dojezd?",
    "answer": "Záleží na modelu – informaci o kování najdete v detailu konkrétního nočního stolku."
   },
   {
    "question": "Dodáváte noční stolky smontované?",
    "answer": "Ano, noční stolky dodáváme smontované."
   }
  ]
 },
 "/nabytek/nocni-stolky-a-police/bez-zasuvek/": {
  "h1": "Noční stolky bez zásuvek",
  "short": "Noční stolky bez zásuvek – jednoduchý tvar a otevřená police.",
  "long": [
   {
    "t": "p",
    "text": "Noční stolky bez zásuvek mají jednoduchý, vzdušný tvar s otevřenou policí. Hodí se do minimalistických ložnic a ke každému typu postele."
   }
  ],
  "faq": [
   {
    "question": "Mají noční stolky bez zásuvek polici?",
    "answer": "Ano. Noční stolky bez zásuvek mají obvykle otevřenou polici pod horní deskou."
   },
   {
    "question": "Pasují noční stolky bez zásuvek k čalouněným postelím?",
    "answer": "Ano. Jednoduchý tvar ladí s většinou postelí, včetně čalouněných."
   }
  ]
 },
 "/nabytek/nocni-stolky-a-police/zavesne-nocni-stolky/": {
  "h1": "Noční stolky závěsné noční stolky (na zeď)",
  "short": "Závěsné noční stolky na zeď – volná podlaha a snadný úklid.",
  "long": [
   {
    "t": "p",
    "text": "Závěsný noční stolek visí na zdi vedle postele, takže pod ním zůstane volná podlaha a snadno se uklízí. Ložnice tak působí lehce a moderně. Výšku umístění si zvolíte podle výšky své postele."
   }
  ],
  "faq": [
   {
    "question": "V jaké výšce závěsný noční stolek umístit?",
    "answer": "Ideálně v úrovni horní hrany matrace nebo mírně nad ní, aby se na něj dalo pohodlně sáhnout vleže."
   },
   {
    "question": "Unese závěsný noční stolek lampičku?",
    "answer": "Ano. Při správném ukotvení do zdi unese závěsný stolek lampičku, knihu i telefon."
   }
  ]
 },
 "/nabytek/skrine/": {
  "h1": "Šatní skříně z masivu",
  "short": "Skutečně dřevěné šatní skříně – korpus, dveře i police z masivu, bez dřevotřísky.",
  "long": [
   {
    "t": "p",
    "text": "Vadí vám viklající se skříně z dřevotřísky, které nejde ani přestěhovat? Šatní skříně Světspánku.cz jsou skutečně dřevěné – korpus, dveře i police jsou z masivu."
   },
   {
    "t": "h",
    "text": "Samostatně stojící"
   },
   {
    "t": "p",
    "text": "Všechny naše skříně jsou konstruované jako samostatně stojící. Ani verze s posuvnými dveřmi nepotřebují výklenek, který by nahrazoval stěny skříně. Skříň proto můžete kdykoli přesunout nebo vzít s sebou do nového bytu."
   },
   {
    "t": "h",
    "text": "Posuvné, nebo otevíravé dveře?"
   },
   {
    "t": "ul",
    "items": [
     "Posuvné dveře nepotřebují místo na otevření – skříň se vejde i do užší ložnice nebo chodby.",
     "Otevíravé dveře nabízejí nejlepší přehled o obsahu skříně najednou."
    ]
   },
   {
    "t": "h",
    "text": "Vnitřní uspořádání"
   },
   {
    "t": "p",
    "text": "Skříně mají police a tyč na ramínka, přesné uspořádání najdete u každého modelu. Skříň vyrábíme ve stejných dřevinách a odstínech jako postele, komody a noční stolky."
   },
   {
    "t": "h",
    "text": "Jak naplánovat šatní skříň"
   },
   {
    "t": "p",
    "text": "Pro ukládání oblečení na ramínka počítejte s vnitřní hloubkou kolem 55–60 cm. Před skříní s otevíravými dveřmi nechte volné místo alespoň na šířku křídla dveří; pokud ho nemáte, zvolte posuvné dveře. Zkontrolujte i výšku místnosti a cestu, kudy se skříň do bytu dostane."
   },
   {
    "t": "h",
    "text": "Péče o masivní skříň"
   },
   {
    "t": "p",
    "text": "Masiv stačí otírat suchým nebo mírně navlhčeným hadříkem. Skříň nestavte přímo k topení a v místnosti udržujte běžnou vlhkost – masivní dřevo pak zůstane rovné a dveře budou dobře dosedat."
   }
  ],
  "faq": [
   {
    "question": "Potřebuje skříň s posuvnými dveřmi výklenek?",
    "answer": "Ne. Všechny šatní skříně Světspánku.cz jsou samostatně stojící, včetně verzí s posuvnými dveřmi."
   },
   {
    "question": "Je šatní skříň celá z masivu?",
    "answer": "Ano – korpus, dveře i police jsou z masivního dřeva, bez dřevotřísky."
   },
   {
    "question": "Lze šatní skříň přestěhovat?",
    "answer": "Ano. Skříň je samostatně stojící a pevná, takže ji můžete přesunout nebo vzít s sebou do nového bytu."
   }
  ]
 },
 "/nabytek/skrine/s-posuvnymi-dvermi/": {
  "h1": "Skříně s posuvnými dveřmi z masivu",
  "short": "Šatní skříně z masivu s posuvnými dveřmi – šetří místo před skříní.",
  "long": [
   {
    "t": "p",
    "text": "Posuvné dveře nepotřebují místo na otevření, takže se skříň vejde i do užší ložnice nebo chodby. Naše skříně s posuvnými dveřmi jsou celé z masivu a samostatně stojící – žádný výklenek ani montáž do zdi."
   }
  ],
  "faq": [
   {
    "question": "Kolik místa potřebuje skříň s posuvnými dveřmi?",
    "answer": "Skříň s posuvnými dveřmi potřebuje jen svou hloubku – dveře se neotevírají do prostoru, takže se vejde i do užší místnosti."
   },
   {
    "question": "Je skříň s posuvnými dveřmi vestavná?",
    "answer": "Ne. Skříně s posuvnými dveřmi od Světspánku.cz jsou samostatně stojící a nepotřebují výklenek."
   }
  ]
 },
 "/nabytek/skrine/samostatne-skrine/": {
  "h1": "Samostatné skříně z masivu",
  "short": "Samostatně stojící šatní skříně z masivu s otevíravými dveřmi.",
  "long": [
   {
    "t": "p",
    "text": "Klasické šatní skříně s otevíravými dveřmi nabízejí nejlepší přehled o obsahu. Jsou celé z masivu, pevné a samostatně stojící, takže je lze kdykoli přestěhovat."
   }
  ],
  "faq": [
   {
    "question": "Jaké vnitřní uspořádání šatní skříně mají?",
    "answer": "Skříně mají police a tyč na ramínka. Přesné uspořádání najdete u každého modelu."
   },
   {
    "question": "Lze šatní skříň upravit na míru?",
    "answer": "Úpravy rozměrů skříně s vámi rádi zkonzultujeme – možnosti posoudíme podle konstrukce."
   }
  ]
 },
 "/nabytek/police-na-zed/": {
  "h1": "Police na zeď z masivu",
  "short": "Masivní police na zeď – na knihy, dekorace i jako úsporný noční stolek u postele.",
  "long": [
   {
    "t": "p",
    "text": "Masivní police na zeď unese mnohem víc než police z dřevotřísky a vydrží roky bez prohnutí. Police Světspánku.cz vyrábíme ze stejných dřevin a v odstínech jako ostatní nábytek."
   },
   {
    "t": "h",
    "text": "Kam se police hodí"
   },
   {
    "t": "p",
    "text": "Do ložnice, obýváku, pracovny, předsíně i dětského pokoje – na knihy, dekorace, rostliny nebo sbírky."
   },
   {
    "t": "h",
    "text": "Police jako noční stolek"
   },
   {
    "t": "p",
    "text": "Vedle postele může police nahradit noční stolek. Nezabírá podlahu, pod ní se snadno uklízí a na lampičku, telefon a knihu stačí. Umístěte ji zhruba v úrovni horní hrany matrace."
   },
   {
    "t": "h",
    "text": "Montáž"
   },
   {
    "t": "p",
    "text": "Polici ukotvěte do pevné zdi. Masivní dřevo se neprohýbá, takže při správném ukotvení unese i těžší knihy."
   }
  ],
  "faq": [
   {
    "question": "Mohu polici na zeď použít jako noční stolek?",
    "answer": "Ano. Masivní police vedle postele je úsporné řešení do menších ložnic – nezabírá podlahu a na lampičku, telefon i knihu stačí."
   },
   {
    "question": "Jak velkou zátěž police z masivu unese?",
    "answer": "Při správném ukotvení do pevné zdi unese masivní police i těžší knihy, protože se masivní dřevo neprohýbá."
   },
   {
    "question": "Jsou police ve stejném odstínu jako nábytek?",
    "answer": "Ano. Police vyrábí Světspánku.cz ze stejných dřevin a v odstínech jako postele a ostatní nábytek."
   }
  ]
 },
 "/nabytek/detsky-nabytek/": {
  "h1": "Dětský nábytek z masivu",
  "short": "Dětský nábytek z masivu, který roste spolu s dětmi – od prvních krůčků po studentská léta.",
  "long": [
   {
    "t": "p",
    "text": "Vytvořte dětem prostor, kde se budou cítit skvěle každý den. Dětský nábytek z naší nabídky spojuje kvalitu, funkčnost a nadčasový design, který neomrzí ani školáka. Najdete u nás dětské komody a skříně, závěsné police a masivní truhlu na hračky, která poslouží i jako lavice u postele nebo v předsíni. Masivní dřevo bez dřevotřísky je odolné i zdravé, a k dětskému pokoji vám doporučíme i postel a matraci."
   }
  ],
  "faq": [
   {
    "question": "Je dětský nábytek z masivu bezpečný?",
    "answer": "Ano. Dětský nábytek Světspánku.cz je z masivního dřeva, má pevné spoje a zaoblené hrany."
   },
   {
    "question": "Pasuje dětský nábytek k dětským postelím?",
    "answer": "Ano. Dětský nábytek vyrábíme ve stejných dřevinách a odstínech jako dětské postele."
   },
   {
    "question": "Máte truhlu na hračky?",
    "answer": "Ano. Masivní truhlu najdete v dětském nábytku. Hodí se i do ložnice dospělých jako lavice nebo úložný prostor na deky."
   }
  ]
 },
 "/nabytek/detsky-nabytek/detske-komody-a-skrine/": {
  "h1": "Dětské komody a skříně z masivu",
  "short": "Komody a skříně do dětského pokoje z masivu.",
  "long": [
   {
    "t": "p",
    "text": "Dětské komody a skříně pojmou oblečení, hračky i školní věci. Jsou z masivu, takže vydrží i divočejší zacházení, a jejich jednoduchý design dítě nepřeroste."
   }
  ],
  "faq": [
   {
    "question": "Jsou dětské komody dodávané smontované?",
    "answer": "Ano. Dětské komody dodáváme smontované."
   },
   {
    "question": "Mají zásuvky dětských komod pojistku?",
    "answer": "Informaci o zajištění zásuvek najdete u konkrétního modelu dětské komody."
   }
  ]
 },
 "/nabytek/detsky-nabytek/zavesne-police-a-skrinky/": {
  "h1": "Závěsné police a skříňky z masivu",
  "short": "Závěsné police a skříňky do dětského pokoje.",
  "long": [
   {
    "t": "p",
    "text": "Závěsné police a skříňky uvolní podlahu pro hraní. Poslouží na knihy, hračky i školní pomůcky a jsou ze stejného masivu jako ostatní dětský nábytek."
   }
  ],
  "faq": [
   {
    "question": "V jaké výšce dětské police umístit?",
    "answer": "Tak, aby na ně dítě bezpečně dosáhlo – nebo výš na věci, ke kterým se dostat nemá."
   },
   {
    "question": "Jak se dětské závěsné police kotví?",
    "answer": "Do pevné zdi pomocí kotev, aby unesly knihy i hračky."
   }
  ]
 },
 "/nabytek/doplnky-do-loznice/": {
  "h1": "Doplňky do ložnice z masivu",
  "short": "Zrcadla a hodiny z masivu, které ložnici dotvoří ve stejném odstínu jako nábytek.",
  "long": [
   {
    "t": "p",
    "text": "Ložnici dotvářejí detaily. Zrcadla v masivním rámu a dřevěné hodiny vyrábíme ve stejných dřevinách a odstínech jako postele a nábytek, takže vše ladí. Jsou to i originální dárky. K posteli se hodí také masivní truhla z dětského nábytku – jako lavice nebo úložný prostor na deky a přikrývky."
   }
  ],
  "faq": [
   {
    "question": "Budou doplňky do ložnice ve stejném odstínu jako nábytek?",
    "answer": "Ano. Zrcadla a hodiny vyrábí Světspánku.cz ve stejných dřevinách a odstínech jako postele a nábytek."
   },
   {
    "question": "Hodí se dřevěné doplňky jako dárek?",
    "answer": "Ano. Zejména dřevěné hodiny z masivu jsou oblíbeným originálním dárkem."
   }
  ]
 },
 "/nabytek/zrcadla/": {
  "h1": "Zrcadla v masivním rámu",
  "short": "Zrcadla v masivním rámu do ložnice i šatny.",
  "long": [
   {
    "t": "p",
    "text": "Zrcadlo v masivním rámu se hodí do šatny, předsíně i ložnice. Můžete ho pověsit na ležato i na svislo, nebo jen opřít o zeď. Rám vyrábíme ve stejných dřevinách a odstínech jako náš nábytek."
   }
  ],
  "faq": [
   {
    "question": "Lze zrcadlo pověsit na výšku i na šířku?",
    "answer": "Ano. Zrcadlo v masivním rámu můžete pověsit na výšku, na šířku nebo jen opřít o zeď."
   },
   {
    "question": "Je rám zrcadla z masivu?",
    "answer": "Ano. Rám zrcadla vyrábíme ve vlastní dílně z masivního dřeva."
   }
  ]
 },
 "/nabytek/hodiny/": {
  "h1": "Dřevěné hodiny z masivu",
  "short": "Skutečně masivní hodiny v odstínech shodných s naším nábytkem.",
  "long": [
   {
    "t": "p",
    "text": "Naše hodiny jsou skutečně z masivu – v několika odstínech dřeva s olejovou povrchovou úpravou, shodných s barvami nábytku, který vyrábíme. Struktura dřeva zůstává zachovaná se všemi svými plusy i mínusy, takže každé hodiny jsou originál. Ručičky jsou vždy v kontrastu k barvě dřeva, abyste čas přečetli na první pohled."
   }
  ],
  "faq": [
   {
    "question": "Jsou dřevěné hodiny opravdu z masivu?",
    "answer": "Ano. Hodiny vyrábí Světspánku.cz z masivního dřeva s olejovou povrchovou úpravou, takže každé mají vlastní kresbu."
   },
   {
    "question": "Hodí se dřevěné hodiny k nábytku?",
    "answer": "Ano. Hodiny vyrábíme ve stejných odstínech jako náš nábytek a ručičky jsou v kontrastu k barvě dřeva, aby se čas dobře četl."
   }
  ]
 },
 "/polstare-a-prikryvky/": {
  "h1": "Polštáře a přikrývky",
  "short": "Polštáře a přikrývky – od anatomických Visco polštářů po kolekce pro alergiky a pro ty, kdo se potí.",
  "long": [
   {
    "t": "p",
    "text": "Polštář patří pod hlavu, ne pod ramena. Velký polštář 70×90 cm zasahuje při spánku pod ramena, zvedá je, krk se ohýbá a ráno bolí. Proto Světspánku.cz doporučuje menší polštář 40×70 cm, který podepře jen hlavu a krk a páteř nechá v rovině."
   },
   {
    "t": "h",
    "text": "Jak vybrat polštář"
   },
   {
    "t": "ol",
    "items": [
     "Rozměr – doporučujeme 40×70 cm, klasický 70×90 cm najdete také.",
     "Poloha spánku – spáči na boku potřebují vyšší a pevnější polštář, který vyplní prostor mezi ramenem a hlavou; spáči na zádech nižší.",
     "Typ – anatomické a ortopedické polštáře z paměťové pěny podepřou krční páteř, klasické s dutým vláknem jsou měkké a pratelné."
    ]
   },
   {
    "t": "p",
    "text": "Podrobně to vysvětlujeme v článku Jak vybrat polštář na našem blogu."
   },
   {
    "t": "h",
    "text": "Kolekce polštářů a přikrývek"
   },
   {
    "t": "p",
    "text": "Polštáře a přikrývky jsou sladěné do kolekcí podle toho, co potřebujete: Bamboo s výbornou termoregulací, Antimikrobial Washable pro alergiky, Carbon Antistress pro klidnější spánek, Aloe Vera, Cirrus pro ty, kdo se v noci potí, a konopná HEMPhoria. Polštář i přikrývku z jedné kolekce koupíte výhodně jako set."
   },
   {
    "t": "h",
    "text": "Povlaky 40×70"
   },
   {
    "t": "p",
    "text": "K polštářům 40×70 nabízíme i povlaky ve stejném rozměru v sekci Povlečení a prostěradla, takže přechod na menší polštář nic nebrzdí."
   },
   {
    "t": "h",
    "text": "Jak často polštář měnit"
   },
   {
    "t": "p",
    "text": "Klasický polštář s dutým vláknem doporučujeme měnit zhruba po dvou až třech letech, polštář z paměťové pěny vydrží déle. Pokud se polštář slehl, nevrací se do původního tvaru nebo se ráno budíte s bolestí krku, je čas na nový."
   }
  ],
  "faq": [
   {
    "question": "Jakou velikost polštáře zvolit?",
    "answer": "Světspánku.cz doporučuje polštář 40×70 cm. Menší polštář podepře hlavu a krk, ale nezasahuje pod ramena, takže páteř zůstane v rovině."
   },
   {
    "question": "Jaký polštář na bolest krční páteře?",
    "answer": "Anatomický nebo ortopedický polštář z paměťové pěny, který se přizpůsobí tvaru hlavy a krku a podepře krční páteř. Doporučujeme velikost kolem 40×70 cm."
   },
   {
    "question": "Co jsou kolekce polštářů a přikrývek?",
    "answer": "Kolekce jsou sladěné řady polštářů a přikrývek se stejným materiálem a vlastnostmi – například Antimikrobial Washable pro alergiky nebo Cirrus pro ty, kdo se v noci potí."
   },
   {
    "question": "Prodáváte i povlaky na polštáře 40×70?",
    "answer": "Ano. Povlaky na polštář 40×70 cm najdete v sekci Povlečení a prostěradla v kategorii Povlaky na polštáře a přikrývky."
   }
  ]
 },
 "/polstare-a-prikryvky/podle-rozmeru/": {
  "h1": "Polštáře podle rozměru",
  "short": "Polštáře 40×70 a 70×90 cm – a proč doporučujeme ten menší.",
  "long": [
   {
    "t": "p",
    "text": "Klasický polštář 70×90 cm je v Česku zvykem, ale pro spánek není ideální. Při spaní na zádech i na boku zasahuje pod ramena, zvedá je a krk se ohýbá. Menší polštář 40×70 cm podepře jen hlavu a krk, ramena zůstanou na matraci a páteř je v rovině. Pokud jste zvyklí na velký polštář, vyzkoušejte rozdíl na prodejně."
   }
  ],
  "faq": [
   {
    "question": "Proč je lepší polštář 40×70 než 70×90?",
    "answer": "Menší polštář 40×70 cm nezasahuje pod ramena, takže se krk neohýbá a páteř zůstane v rovině. Velký polštář 70×90 cm ramena zvedá."
   },
   {
    "question": "Seženu povlak na polštář 40×70?",
    "answer": "Ano. Povlaky 40×70 cm najdete v sekci Povlečení a prostěradla."
   }
  ]
 },
 "/polstare-a-prikryvky/polstare-40x70/": {
  "h1": "Polštáře 40×70 cm",
  "short": "Polštáře 40×70 cm, které podepřou hlavu a krk, ale ne ramena.",
  "long": [
   {
    "t": "p",
    "text": "Polštář 40×70 cm je velikost, kterou Světspánku.cz doporučuje pro zdravý spánek. Podepře hlavu a krk, ale ramena nechá ležet na matraci – páteř tak zůstává v přirozené rovině při spaní na zádech i na boku."
   },
   {
    "t": "h",
    "text": "Proč ne velký polštář 70×90"
   },
   {
    "t": "p",
    "text": "Klasický polštář 70×90 cm je v Česku zvykem, ale při spánku zasahuje pod ramena. Ramena se zvednou, hlava se předkloní a krk zůstane celou noc ohnutý. Výsledkem bývá ztuhlá šíje, ranní bolest krku nebo hlavy."
   },
   {
    "t": "h",
    "text": "Jak polštář 40×70 vybrat"
   },
   {
    "t": "ul",
    "items": [
     "Spáči na zádech – nižší polštář, který vyplní prohlubeň za krkem.",
     "Spáči na boku – vyšší a pevnější polštář, který vyplní prostor mezi ramenem a hlavou.",
     "Při bolesti krční páteře – anatomický polštář z paměťové pěny podobného rozměru."
    ]
   },
   {
    "t": "h",
    "text": "Povlaky ve stejném rozměru"
   },
   {
    "t": "p",
    "text": "K polštářům 40×70 nabízíme povlaky 40×70 cm z bavlny i saténu, které ladí s povlečením. Na přechod si obvykle zvyknete za několik nocí až dva týdny."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je polštář 40×70 vhodný?",
    "answer": "Polštář 40×70 cm je vhodný pro dospělé spáče na zádech i na boku. Podepře hlavu a krk, ale ramena nechá na matraci, takže páteř zůstane v rovině."
   },
   {
    "question": "Kde koupím povlak na polštář 40×70?",
    "answer": "Povlaky na polštář 40×70 cm najdete na Světspánku.cz v sekci Povlečení a prostěradla – Povlaky na polštáře a přikrývky."
   },
   {
    "question": "Jak dlouho trvá zvyknout si na menší polštář?",
    "answer": "Většině lidí stačí několik nocí až dva týdny. Pak už se obvykle k velkému polštáři nechtějí vracet."
   }
  ]
 },
 "/polstare-a-prikryvky/polstare-70x90/": {
  "h1": "Polštáře 70×90 cm",
  "short": "Klasické polštáře 70×90 cm – a proč stojí za to zkusit menší.",
  "long": [
   {
    "t": "p",
    "text": "Polštář 70×90 cm je v Česku nejběžnější a lidé ho hledají nejčastěji. Pokud jste na něj zvyklí, najdete ho u nás. Než ho ale koupíte, zvažte menší polštář 40×70 cm."
   },
   {
    "t": "h",
    "text": "Proč zvážit menší polštář"
   },
   {
    "t": "p",
    "text": "Velký polštář 70×90 cm při spánku často zasahuje pod ramena. Ramena se zvednou, krk se ohne a ráno může bolet šíje nebo hlava. Polštář 40×70 cm podepře jen hlavu a krk a páteř nechá v rovině."
   },
   {
    "t": "h",
    "text": "Když zůstanete u 70×90"
   },
   {
    "t": "p",
    "text": "Vybírejte polštář, který není příliš vysoký, a při spaní ho mějte jen pod hlavou, ne pod rameny. Rozdíl mezi oběma velikostmi si můžete vyzkoušet na prodejně."
   }
  ],
  "faq": [
   {
    "question": "Je polštář 70×90 špatný?",
    "answer": "Polštář 70×90 cm není špatný, ale často zasahuje pod ramena a krk se pak ohýbá. Pro rovnou páteř Světspánku.cz doporučuje menší polštář 40×70 cm."
   },
   {
    "question": "Co s povlaky 70×90, když přejdu na polštář 40×70?",
    "answer": "Povlaky ve správném rozměru 40×70 cm najdete v sekci Povlečení a prostěradla, takže přechod na menší polštář nic nebrzdí."
   }
  ]
 },
 "/polstare-a-prikryvky/podle-potreby/": {
  "h1": "Polštáře podle potřeby",
  "short": "Vyberte polštář podle toho, co vás trápí – krční páteř, spaní na boku.",
  "long": [
   {
    "t": "p",
    "text": "Správný polštář umí ulevit ztuhlému krku, ranní bolesti hlavy i neklidnému spánku. Polštáře proto řadíme i podle potřeby: na krční páteř, na spaní na boku. Pokud vás trápí chrápání, přečtěte si náš článek o chrápání a spánkové apnoe – správně zvolený polštář, který drží hlavu a krk v ose, může pomoci."
   }
  ],
  "faq": [
   {
    "question": "Jaký polštář, když mě ráno bolí za krkem?",
    "answer": "Anatomický polštář z paměťové pěny ve velikosti kolem 40×70 cm, který podepře krk a nezasahuje pod ramena."
   },
   {
    "question": "Pomůže polštář proti chrápání?",
    "answer": "U běžného chrápání může pomoci polštář, který drží hlavu a krk v ose, a spaní na boku. Při silném chrápání nebo zástavách dechu se poraďte s lékařem."
   }
  ]
 },
 "/polstare-a-prikryvky/polstare-na-krcni-pater/": {
  "h1": "Polštáře na krční páteř",
  "short": "Anatomické polštáře, které podepřou krční páteř a uleví ranní bolesti.",
  "long": [
   {
    "t": "p",
    "text": "Bolest krku po probuzení je často znamením, že polštář nedrží krční páteř ve správné poloze. Buď je příliš vysoký a krk se ohýbá dopředu, nebo příliš nízký a měkký a hlava padá dozadu či do strany."
   },
   {
    "t": "h",
    "text": "Jak vypadá správný polštář na krční páteř"
   },
   {
    "t": "ul",
    "items": [
     "Podepře prohlubeň za krkem, takže krční páteř navazuje na zbytek páteře v rovině.",
     "Nezasahuje pod ramena – proto doporučujeme velikost kolem 40×70 cm.",
     "Má výšku odpovídající poloze spánku: na boku vyšší, na zádech nižší."
    ]
   },
   {
    "t": "h",
    "text": "Anatomické a ortopedické polštáře z paměťové pěny"
   },
   {
    "t": "p",
    "text": "Paměťová pěna reaguje na teplo a tlak těla, přizpůsobí se tvaru hlavy a krku a rovnoměrně rozloží váhu. Na nový polštář si obvykle zvyknete během několika nocí až dvou týdnů."
   },
   {
    "t": "h",
    "text": "Kdy k lékaři"
   },
   {
    "t": "p",
    "text": "Pokud bolest krku trvá déle, vystřeluje do rukou nebo ji provází brnění, poraďte se s lékařem nebo fyzioterapeutem. Polštář je důležitou součástí, ale ne jediným řešením."
   }
  ],
  "faq": [
   {
    "question": "Jak poznám, že mám špatný polštář?",
    "answer": "Varováním bývá ranní bolest nebo ztuhlost krku, ztuhlá ramena či bolest hlavy po probuzení. Polštář pak obvykle nedrží krční páteř v rovině."
   },
   {
    "question": "Jak dlouho trvá zvyknout si na anatomický polštář?",
    "answer": "Na anatomický polštář z paměťové pěny si většina lidí zvykne během několika nocí až dvou týdnů."
   },
   {
    "question": "Jaký polštář na krční páteř při spaní na boku?",
    "answer": "Při spaní na boku volte vyšší a pevnější anatomický polštář, který vyplní prostor mezi ramenem a hlavou a udrží krk v rovině s páteří."
   }
  ]
 },
 "/polstare-a-prikryvky/polstare-na-spani-na-boku/": {
  "h1": "Polštáře na spaní na boku",
  "short": "Polštáře, které vyplní prostor mezi ramenem a hlavou a udrží krk v rovině.",
  "long": [
   {
    "t": "p",
    "text": "Při spaní na boku je mezi ramenem a hlavou větší prostor než při spaní na zádech. Polštář ho musí vyplnit tak, aby krk zůstal v rovině s páteří – ne příliš nízko, ani příliš vysoko. Anatomické polštáře s vyšší stranou nebo pevnější výplní jsou proto pro spáče na boku ideální."
   }
  ],
  "faq": [
   {
    "question": "Jak vysoký polštář na spaní na boku?",
    "answer": "Polštář na spaní na boku má být tak vysoký, aby krk zůstal v rovině s páteří. Výška závisí hlavně na šířce ramen."
   },
   {
    "question": "Hodí se polštář 40×70 i na spaní na boku?",
    "answer": "Ano. U spaní na boku je důležitější výška a pevnost polštáře než jeho plocha."
   }
  ]
 },
 "/polstare-a-prikryvky/podle-typu/": {
  "h1": "Polštáře podle typu",
  "short": "Anatomické, ortopedické, klasické i dětské polštáře.",
  "long": [
   {
    "t": "p",
    "text": "Typ polštáře rozhoduje o tom, jak bude podpírat hlavu a krk. Anatomické polštáře z paměťové pěny se přizpůsobí tvaru těla, ortopedické mají tvarovaný profil pro oporu krční páteře, klasické polštáře s dutým vláknem jsou měkké a nadýchané. Pro děti a alergiky máme speciální varianty."
   }
  ],
  "faq": [
   {
    "question": "Jaký je rozdíl mezi anatomickým a klasickým polštářem?",
    "answer": "Anatomický polštář z paměťové pěny se přizpůsobí tvaru hlavy a krku a podepře krční páteř. Klasický polštář s dutým vláknem je měkký, nadýchaný a pratelný."
   },
   {
    "question": "Který typ polštáře je nejlepší?",
    "answer": "Pro zdravou krční páteř Světspánku.cz doporučuje anatomický polštář z paměťové pěny ve velikosti kolem 40×70 cm."
   }
  ]
 },
 "/polstare-a-prikryvky/anatomicke-a-ortopedicke-polstare/": {
  "h1": "Anatomické a ortopedické polštáře z paměťové pěny",
  "short": "Anatomické a ortopedické polštáře z paměťové pěny – opora krční páteře a ulevení ranní bolesti krku.",
  "long": [
   {
    "t": "p",
    "text": "Anatomické neboli ortopedické polštáře podepřou krční páteř tak, aby zůstala v rovině se zbytkem páteře. Naše VISCO polštáře jsou z viskoelastické (paměťové) pěny, která reaguje na teplotu a tlak těla: přizpůsobí se tvaru hlavy a krku, rovnoměrně rozloží váhu a uleví tlakovým bodům. Pomáhají při ztuhlé šíji, ranní bolesti krku i hlavy a hodí se pro spaní na zádech i na boku."
   },
   {
    "t": "p",
    "text": "Doporučujeme menší rozměr kolem 40×70 cm, protože polštář patří pod hlavu, ne pod ramena. Vybírat můžete z různých potahů – bambusového, antimikrobiálního pratelného Washable, Carbon Antistress nebo prodyšného AirVisco – a k polštářům nabízíme i náhradní potahy na zip. Rozdíl mezi zdravotním polštářem a klasickým si můžete vyzkoušet na kterékoli naší prodejně."
   }
  ],
  "faq": [
   {
    "question": "Jaký je rozdíl mezi anatomickým a ortopedickým polštářem?",
    "answer": "V běžné řeči jde o totéž – polštář, který tvarem a materiálem podepře krční páteř. Naše anatomické polštáře z paměťové pěny plní obě role."
   },
   {
    "question": "Pomůže ortopedický polštář na bolest krční páteře?",
    "answer": "Správně zvolený polštář drží krk v rovině s páteří, a tím šíji odlehčí. Při dlouhodobých potížích se poraďte i s lékařem."
   },
   {
    "question": "Jsou anatomické polštáře pratelné?",
    "answer": "Potah ano, modely Washable jsou pratelné celé."
   },
   {
    "question": "Je paměťová pěna vhodná pro alergiky?",
    "answer": "Ano, zejména s antimikrobiálním potahem."
   },
   {
    "question": "Jak dlouho trvá si na polštář z paměťové pěny zvyknout?",
    "answer": "Obvykle několik nocí až dva týdny."
   }
  ]
 },
 "/polstare-a-prikryvky/klasicke-polstare/": {
  "h1": "Klasické polštáře",
  "short": "Měkké a nadýchané klasické polštáře – malé, velké, vyšší i nižší.",
  "long": [
   {
    "t": "p",
    "text": "Klasické polštáře s dutým vláknem jsou měkké, nadýchané a snadno se perou. Vybírat můžete malé i velké, tenčí i vyšší. Najdete je i v kolekcích sladěných s přikrývkami."
   }
  ],
  "faq": [
   {
    "question": "Lze klasický polštář prát?",
    "answer": "Ano. Většinu klasických polštářů s dutým vláknem lze prát v pračce."
   },
   {
    "question": "Jakou velikost klasického polštáře zvolit?",
    "answer": "Doporučujeme 40×70 cm, který nezasahuje pod ramena. Klasický rozměr 70×90 cm v nabídce také najdete."
   }
  ]
 },
 "/polstare-a-prikryvky/detske-polstare/": {
  "h1": "Dětské polštáře",
  "short": "Nízké dětské polštáře s měkkou výplní a pratelným potahem.",
  "long": [
   {
    "t": "p",
    "text": "Děti potřebují nižší polštář než dospělí, aby krk zůstal v rovině. Dětské polštáře jsou nízké, měkké a pratelné."
   }
  ],
  "faq": [
   {
    "question": "Od kolika let polštář pro dítě?",
    "answer": "Polštář se dětem obvykle dává od 1–2 let. Miminkům doporučujeme spát bez polštáře."
   },
   {
    "question": "Je dětský polštář pratelný?",
    "answer": "Ano, dětské polštáře jsou pratelné."
   }
  ]
 },
 "/polstare-a-prikryvky/antialergicke-polstare/": {
  "h1": "Antialergické polštáře",
  "short": "Polštáře s antimikrobiální a protiroztočovou úpravou pro alergiky.",
  "long": [
   {
    "t": "p",
    "text": "Antialergické polštáře mají antimikrobiální a protiroztočovou úpravu, která výrazně snižuje množství alergenů. Hodí se pro alergiky a astmatiky. Celou řadu najdete v kolekci Antimikrobial Washable."
   }
  ],
  "faq": [
   {
    "question": "Pomůže antialergický polštář alergikům?",
    "answer": "Ano. Antimikrobiální a protiroztočová úprava výrazně snižuje množství alergenů v polštáři."
   },
   {
    "question": "Lze antialergický polštář prát celý?",
    "answer": "Ano. Polštáře z kolekce Antimikrobial Washable jsou pratelné celé."
   }
  ]
 },
 "/polstare-a-prikryvky/dekoracni-polstare/": {
  "h1": "Dekorační polštáře",
  "short": "Dekorační polštáře, které dotvoří postel i pohovku.",
  "long": [
   {
    "t": "p",
    "text": "Dekorační polštáře dodají posteli a pohovce barvu a útulnost. Vybírejte ve stejných odstínech jako povlečení nebo čalounění."
   }
  ],
  "faq": [
   {
    "question": "Jsou dekorační polštáře na spaní?",
    "answer": "Ne. Dekorační polštáře slouží hlavně k ozdobě postele či pohovky a k opření při čtení."
   },
   {
    "question": "Lze potah dekoračního polštáře prát?",
    "answer": "Záleží na modelu – informaci najdete u konkrétního polštáře."
   }
  ]
 },
 "/polstare-a-prikryvky/prikryvky/": {
  "h1": "Přikrývky",
  "short": "Přikrývky sladěné do kolekcí s polštáři – i výhodně v setu.",
  "long": [
   {
    "t": "p",
    "text": "Přikrývka rozhoduje o tom, zda se v noci nepotíte, nebo naopak nemrznete. Přikrývky Světspánku.cz jsou součástí kolekcí, takže si vyberete podle toho, co při spánku řešíte."
   },
   {
    "t": "h",
    "text": "Jakou přikrývku vybrat"
   },
   {
    "t": "ul",
    "items": [
     "Potíte se v noci – kolekce Cirrus s hydrofilními vlákny nebo Bamboo s výbornou termoregulací.",
     "Jste alergik – kolekce Antimikrobial Washable s protiroztočovou úpravou, pratelná celá.",
     "Budíte se z lehkého spánku – kolekce Carbon Antistress se zatkanými karbonovými vlákny.",
     "Máte rádi přírodní materiály – konopná kolekce HEMPhoria."
    ]
   },
   {
    "t": "h",
    "text": "Rozměr přikrývky"
   },
   {
    "t": "p",
    "text": "Standardní přikrývka má 140×200 cm, pro vyšší postavy doporučujeme prodlouženou 140×220 cm. K ní najdete i prodloužené povlečení."
   },
   {
    "t": "h",
    "text": "Set s polštářem"
   },
   {
    "t": "p",
    "text": "Přikrývku s polštářem z jedné kolekce koupíte výhodněji jako set – vlastnosti obou se doplňují."
   }
  ],
  "faq": [
   {
    "question": "Jakou přikrývku, když se v noci potím?",
    "answer": "Kolekci Cirrus s hydrofilními vlákny nebo Bamboo s bambusovým vláknem – obě výborně odvádějí vlhkost a regulují teplotu."
   },
   {
    "question": "Jakou přikrývku pro alergika?",
    "answer": "Kolekci Antimikrobial Washable s antimikrobiální a protiroztočovou úpravou, kterou lze celou prát."
   },
   {
    "question": "Jaký rozměr přikrývky zvolit?",
    "answer": "Standardní rozměr přikrývky je 140×200 cm. Vyšším postavám doporučujeme prodlouženou přikrývku 140×220 cm a k ní prodloužené povlečení."
   }
  ]
 },
 "/polstare-a-prikryvky/sety-prikryvka-polstar/": {
  "h1": "Sety přikrývka a polštář",
  "short": "Přikrývka a polštář z jedné kolekce za výhodnou cenu.",
  "long": [
   {
    "t": "p",
    "text": "Sety přikrývky a polštáře z jedné kolekce mají stejné vlastnosti a vzájemně se doplňují. Koupíte je výhodněji než zvlášť – k dispozici jsou sety s anatomickým polštářem i sety 1+1."
   }
  ],
  "faq": [
   {
    "question": "Proč koupit přikrývku a polštář jako set?",
    "answer": "Přikrývka a polštář z jedné kolekce se doplňují vlastnostmi a jako set vyjdou výhodněji než při nákupu zvlášť."
   },
   {
    "question": "Jaký polštář je v setu s přikrývkou?",
    "answer": "Podle setu anatomický polštář z paměťové pěny nebo klasický polštář – informaci najdete u každého setu."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce/": {
  "h1": "Kolekce polštářů a přikrývek",
  "short": "Sladěné kolekce polštářů a přikrývek podle toho, co potřebujete.",
  "long": [
   {
    "t": "p",
    "text": "Polštáře a přikrývky jsou sladěné do kolekcí se stejným materiálem a vlastnostmi. Vyberte podle toho, co vás při spánku trápí: Bamboo s výbornou termoregulací, Antimikrobial Washable pro alergiky, Carbon Antistress pro klidnější spánek, Aloe Vera, Cirrus s maximálním odvodem vlhkosti nebo konopnou HEMPhoria."
   }
  ],
  "faq": [
   {
    "question": "Jak vybrat kolekci polštářů a přikrývek?",
    "answer": "Podle toho, co při spánku řešíte: alergie (Antimikrobial Washable), pocení (Cirrus, Bamboo), neklidný spánek (Carbon Antistress) nebo přírodní materiály (HEMPhoria)."
   },
   {
    "question": "Lze kombinovat polštář a přikrývku z různých kolekcí?",
    "answer": "Ano, ale v jedné kolekci se vlastnosti polštáře a přikrývky vzájemně doplňují."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce-bamboo/": {
  "h1": "Kolekce Bamboo",
  "short": "Polštáře a přikrývky s bambusovým vláknem – výborná termoregulace a přirozeně antibakteriální.",
  "long": [
   {
    "t": "p",
    "text": "Bambusové vlákno má lepší vlastnosti než běžné materiály. Obsahuje přírodní složku bamboo kun s antibakteriálními účinky, výborně odvádí vlhkost a reguluje teplotu. Kolekce Bamboo zahrnuje přikrývky i anatomický polštář s bambusovým potahem."
   }
  ],
  "faq": [
   {
    "question": "Proč polštáře a přikrývky z bambusu?",
    "answer": "Bambusové vlákno výborně reguluje teplotu, odvádí vlhkost a díky přírodní složce bamboo kun je přirozeně antibakteriální."
   },
   {
    "question": "Je kolekce Bamboo vhodná na léto?",
    "answer": "Ano. Díky termoregulaci se pod přikrývkou Bamboo tolik nepotíte ani v teplých nocích."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce-antimikrobial-washable/": {
  "h1": "Kolekce Antimikrobial Washable",
  "short": "Pratelné polštáře a přikrývky s antimikrobiální a protiroztočovou úpravou pro alergiky.",
  "long": [
   {
    "t": "p",
    "text": "Kolekce Antimikrobial Washable výrazně redukuje alergeny, zajišťuje dokonalou hygienu, snižuje nepříjemné pachy a má protiroztočovou úpravu. Polštáře i přikrývky lze celé prát, proto jsou ideální pro alergiky."
   }
  ],
  "faq": [
   {
    "question": "Jsou výrobky Antimikrobial Washable celé pratelné?",
    "answer": "Ano. Polštáře i přikrývky kolekce Antimikrobial Washable lze prát celé, což ocení hlavně alergici."
   },
   {
    "question": "Pomůže kolekce Antimikrobial Washable alergikům?",
    "answer": "Ano. Antimikrobiální a protiroztočová úprava výrazně redukuje alergeny a nepříjemné pachy."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce-carbon-antistress/": {
  "h1": "Kolekce Carbon Antistress",
  "short": "Polštáře a přikrývky se zatkanými karbonovými vlákny pro klidnější spánek.",
  "long": [
   {
    "t": "p",
    "text": "Antistresová tkanina se zatkanými karbonovými vlákny vstřebává statickou elektřinu z těla a uvolňuje ji do okolí. Kolekce je určena lidem, kteří se často budí z lehkého spánku."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je kolekce Carbon Antistress?",
    "answer": "Pro ty, kdo se v noci často budí z lehkého spánku. Zatkaná karbonová vlákna odvádějí statickou elektřinu z těla."
   },
   {
    "question": "Je v kolekci Carbon Antistress i anatomický polštář?",
    "answer": "Ano. Kolekce obsahuje i anatomický polštář z paměťové pěny s potahem Carbon Antistress."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce-aloe-vera/": {
  "h1": "Kolekce Aloe Vera",
  "short": "Polštáře a přikrývky s úpravou aloe vera pro příjemný a regenerační spánek.",
  "long": [
   {
    "t": "p",
    "text": "Úprava aloe vera dodává polštářům a přikrývkám příjemný pocit na dotek. Kolekce je oblíbená pro svou jemnost a zklidňující účinek při spánku."
   }
  ],
  "faq": [
   {
    "question": "Co přináší úprava aloe vera?",
    "answer": "Úprava aloe vera dodává polštářům a přikrývkám příjemný, jemný pocit na pokožce."
   },
   {
    "question": "Lze výrobky Aloe Vera prát?",
    "answer": "Ano, podle pokynů na etiketě konkrétního výrobku."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce-cirrus/": {
  "h1": "Kolekce Cirrus",
  "short": "Polštáře a přikrývky s hydrofilními vlákny pro maximální odvod vlhkosti.",
  "long": [
   {
    "t": "p",
    "text": "Speciální hydrofilní vlákna přenášejí vlhkost až na povrch přikrývky či polštáře. Díky vysokému prostupu vodních par zajistí kolekce Cirrus ideální mikroklima bez nepříjemných pocitů z pocení."
   }
  ],
  "faq": [
   {
    "question": "Pro koho je kolekce Cirrus?",
    "answer": "Kolekce Cirrus je pro ty, kdo se v noci potí. Hydrofilní vlákna odvádějí vlhkost od těla na povrch přikrývky."
   },
   {
    "question": "Je v kolekci Cirrus i anatomický polštář?",
    "answer": "Ano. Kolekce obsahuje anatomický polštář Cirrus AirVisco s prodyšnou paměťovou pěnou."
   }
  ]
 },
 "/polstare-a-prikryvky/kolekce-hemphoria/": {
  "h1": "Kolekce HEMPhoria",
  "short": "Konopné polštáře a přikrývky HEMPhoria z přírodního vlákna.",
  "long": [
   {
    "t": "p",
    "text": "Konopné vlákno je přírodní, pevné a prodyšné. Kolekce HEMPhoria přináší polštáře a přikrývky s konopím pro všechny, kdo dávají přednost přírodním materiálům."
   }
  ],
  "faq": [
   {
    "question": "Jaké vlastnosti má konopné vlákno?",
    "answer": "Konopné vlákno je přírodní, pevné a prodyšné, proto se hodí do polštářů i přikrývek."
   },
   {
    "question": "Je kolekce HEMPhoria vhodná pro alergiky?",
    "answer": "Vhodnost pro alergiky najdete u konkrétního výrobku kolekce HEMPhoria."
   }
  ]
 },
 "/povleceni-a-prosteradla/": {
  "h1": "Povlečení a prostěradla",
  "short": "Povlečení, napínací prostěradla a povlaky na polštáře z kvalitních materiálů.",
  "long": [
   {
    "t": "p",
    "text": "Kvalitní ložní prádlo dotváří pohodlí postele. V nabídce najdete povlečení ze 100% bavlny a bavlněného saténu, flanelové povlečení na zimu i dětské povlečení. Napínací prostěradla Jersey sedí i na vysoké matrace a povlaky na polštáře nabízíme i v rozměru 40×70 cm, který doporučujeme pro zdravý spánek. Lůžkoviny pečlivě vybíráme – mimo jiné od renomovaného slovenského výrobce Adela Filipp."
   }
  ],
  "faq": [
   {
    "question": "Jaké povlečení je nejpříjemnější?",
    "answer": "Bavlněný satén je hladký a jemný na dotek, perkál chladivý a matný, flanel v zimě příjemně hřeje. Všechny jsou z bavlny, která odvádí vlhkost."
   },
   {
    "question": "Máte prostěradla i na vysoké matrace?",
    "answer": "Ano. Napínací prostěradla Super Stretch Jersey sedí na matrace až do výšky 30 cm."
   },
   {
    "question": "Prodáváte povlaky na polštář 40×70?",
    "answer": "Ano. Povlaky 40×70 cm najdete v kategorii Povlaky na polštáře a přikrývky."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/": {
  "h1": "Povlečení",
  "short": "Povlečení ze 100% bavlny a bavlněného saténu – jednobarevné, se vzorem i dětské.",
  "long": [
   {
    "t": "p",
    "text": "Kvalitní povlečení dotváří pohodlí postele stejně jako matrace. Povlečení na Světspánku.cz pochází od prověřených výrobců, mimo jiné ze značkové kolekce renomovaného slovenského výrobce Adela Filipp."
   },
   {
    "t": "h",
    "text": "Z jakého materiálu"
   },
   {
    "t": "ul",
    "items": [
     "Bavlna renforcé – hustě tkaná, pevná a prodyšná, univerzální na celý rok.",
     "Perkál – jemná hustě tkaná bavlna, matná a chladivá, oblíbená v hotelích.",
     "Bavlněný satén – hladký a hebký povrch, příjemně chladí, méně se mačká.",
     "Flanel – počesaný povrch, který v zimě hřeje."
    ]
   },
   {
    "t": "h",
    "text": "Jaký vzor"
   },
   {
    "t": "p",
    "text": "Jednobarevné povlečení je nadčasové a ladí s každou ložnicí, vzorované dodá ložnici charakter. Pro děti máme povlečení s veselými motivy do postýlky i do dětské postele."
   },
   {
    "t": "h",
    "text": "Rozměry"
   },
   {
    "t": "p",
    "text": "Standardní povlečení je na přikrývku 140×200 cm a polštář 70×90 cm. Pro vyšší postavy nabízíme prodloužené povlečení 140×220 cm. Pokud spíte na polštáři 40×70, dokupte samostatné povlaky v tomto rozměru."
   },
   {
    "t": "h",
    "text": "Péče"
   },
   {
    "t": "p",
    "text": "Potisky neztrácejí barvu ani po mnoha vypráních. Konkrétní pokyny k praní najdete na etiketě."
   },
   {
    "t": "h",
    "text": "Kolik sad povlečení mít"
   },
   {
    "t": "p",
    "text": "Doporučujeme alespoň dvě až tři sady na každou postel – jedna je na posteli, druhá v prádle a třetí v záloze pro hosty nebo pro nečekané situace. Povlečení měňte zhruba jednou za týden až dva, v létě a u alergiků častěji."
   },
   {
    "t": "h",
    "text": "Jak povlečení prát, aby vydrželo"
   },
   {
    "t": "p",
    "text": "Povlečení perte naruby a se zapnutým zipem nebo knoflíky, ať se netahá a nežmolkuje. Nepřeplňujte pračku, používejte šetrný prací prostředek a sušte spíš volně než v horké sušičce. Saténové povlečení stačí vyžehlit na nižší teplotu, perkál a renforcé snesou i vyšší."
   }
  ],
  "faq": [
   {
    "question": "Z čeho je povlečení na Světspánku.cz?",
    "answer": "Povlečení je ze 100% bavlny – renforcé, perkál, bavlněný satén – nebo z bavlněného flanelu na zimu."
   },
   {
    "question": "Nabízíte prodloužené povlečení?",
    "answer": "Ano. Prodloužené povlečení v rozměru 140×220 cm je určené pro delší přikrývky a vyšší postavy."
   },
   {
    "question": "Jaký rozměr má standardní povlečení?",
    "answer": "Standardní povlečení je na přikrývku 140×200 cm a polštář 70×90 cm. K polštáři 40×70 dokoupíte samostatné povlaky."
   },
   {
    "question": "Vybledne potisk povlečení praním?",
    "answer": "Ne. Povlečení z kolekce Adela Filipp má stálé barvy, které nevyblednou ani po mnoha vypráních."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/jednobarevne-povleceni/": {
  "h1": "Jednobarevné povlečení",
  "short": "Jednobarevné povlečení one COLOR – čistý vzhled, který ladí s každou ložnicí.",
  "long": [
   {
    "t": "p",
    "text": "Jednobarevné povlečení je nadčasové a snadno se kombinuje s dekoracemi i nábytkem. Řada one COLOR nabízí povlečení na polštáře i přikrývky v jednotných barvách, ke kterým ladí i prostěradla."
   }
  ],
  "faq": [
   {
    "question": "Lze kombinovat jednobarevné povlečení s prostěradlem?",
    "answer": "Ano. Barvy jednobarevného povlečení one COLOR jsou sladěné s prostěradly."
   },
   {
    "question": "Prodáváte povlaky i samostatně?",
    "answer": "Ano. Povlaky na polštáře i přikrývky koupíte i samostatně."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/povleceni-se-vzorem/": {
  "h1": "Povlečení se vzorem",
  "short": "Vzorované povlečení ze 100% bavlny – originální design, stálé barvy.",
  "long": [
   {
    "t": "p",
    "text": "Vzorované povlečení dodá ložnici charakter. Kolekce Different se vyznačuje kvalitním materiálem ze 100% bavlny a stálostí barev – originální potisk neztratí barevnost ani po mnoha vypráních."
   }
  ],
  "faq": [
   {
    "question": "Vybledne potisk vzorovaného povlečení?",
    "answer": "Ne. Kolekce Different má stálé barvy, které vydrží i mnoho praní."
   },
   {
    "question": "Z čeho je vzorované povlečení?",
    "answer": "Vzorované povlečení kolekce Different je ze 100% bavlny."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/detske-povleceni/": {
  "h1": "Dětské povlečení",
  "short": "Dětské povlečení s veselými motivy do postýlky i dětské postele.",
  "long": [
   {
    "t": "p",
    "text": "Dětské povlečení s veselými motivy udělá z postele oblíbené místo. Nabízíme rozměry do postýlky i do dětské postele, z příjemných a snadno pratelných materiálů."
   }
  ],
  "faq": [
   {
    "question": "Jaké rozměry dětského povlečení nabízíte?",
    "answer": "Dětské povlečení nabízíme do postýlky i do dětské postele – přesné rozměry najdete u produktu."
   },
   {
    "question": "Na kolik stupňů lze dětské povlečení prát?",
    "answer": "Teplotu praní najdete na etiketě konkrétního povlečení."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/darkove-sety-povleceni/": {
  "h1": "Dárkové sety povlečení",
  "short": "Dárkové sety povlečení – krásný a praktický dárek.",
  "long": [
   {
    "t": "p",
    "text": "Hledáte dárek, který je krásný, praktický a potěší na první dotek? Dárkové sety povlečení jsou baleny tak, aby byly připravené k darování."
   }
  ],
  "faq": [
   {
    "question": "Jsou sety povlečení dárkově balené?",
    "answer": "Ano. Dárkové sety povlečení jsou baleny tak, aby byly připravené k darování."
   },
   {
    "question": "Lze k dárku přidat dárkový poukaz?",
    "answer": "Ano. Dárkový poukaz Světspánku.cz najdete v sekci Akce."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/prodlouzene-povleceni/": {
  "h1": "Prodloužené povlečení 140×220",
  "short": "Prodloužené povlečení 140×220 cm pro delší přikrývky a vyšší postavy.",
  "long": [
   {
    "t": "p",
    "text": "Prodloužené povlečení 140×220 cm je určené pro delší přikrývky, které ocení hlavně vyšší postavy. Nohy už nebudou vykukovat zpod peřiny."
   }
  ],
  "faq": [
   {
    "question": "Na jakou přikrývku je povlečení 140×220?",
    "answer": "Prodloužené povlečení 140×220 cm je na prodlouženou přikrývku 140×220 cm, kterou ocení hlavně vyšší postavy."
   },
   {
    "question": "Jaký povlak na polštář je v prodlouženém povlečení?",
    "answer": "Rozměr povlaku na polštář se liší podle setu – najdete ho u produktu."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni-podle-materialu/": {
  "h1": "Povlečení podle materiálu",
  "short": "Bavlněné, saténové a flanelové povlečení – vyberte podle materiálu.",
  "long": [
   {
    "t": "p",
    "text": "Materiál povlečení rozhoduje o tom, jak se v posteli cítíte. Bavlna je prodyšná a odvádí vlhkost, bavlněný satén je hladký a jemný na dotek a flanel příjemně hřeje v zimě."
   }
  ],
  "faq": [
   {
    "question": "Které povlečení je nejlepší na léto?",
    "answer": "Na léto se hodí prodyšná bavlna, chladivý perkál nebo bavlněný satén."
   },
   {
    "question": "Jaké povlečení zvolit na zimu?",
    "answer": "Na zimu je ideální flanelové povlečení, které díky počesanému povrchu příjemně hřeje."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/bavlnene-povleceni-renforce/": {
  "h1": "Bavlněné povlečení renforcé",
  "short": "Bavlněné povlečení renforcé – pevné, prodyšné a odolné častému praní.",
  "long": [
   {
    "t": "p",
    "text": "Renforcé je hustě tkaná bavlna, která je pevná, prodyšná a snese časté praní. Je to univerzální povlečení na celý rok."
   }
  ],
  "faq": [
   {
    "question": "Co je bavlna renforcé?",
    "answer": "Renforcé je hustě tkaná bavlněná látka – pevná, prodyšná a odolná častému praní."
   },
   {
    "question": "Je povlečení renforcé vhodné na celý rok?",
    "answer": "Ano. Renforcé je univerzální povlečení na léto i zimu."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/bavlnene-povleceni-perkal/": {
  "h1": "Bavlněné povlečení perkál",
  "short": "Perkálové povlečení z jemné bavlny – hladké, chladivé a luxusní na dotek.",
  "long": [
   {
    "t": "p",
    "text": "Perkál je velmi hustě tkaná jemná bavlna s matným povrchem. Je chladivý, hladký a oblíbený v hotelích."
   }
  ],
  "faq": [
   {
    "question": "Jaký je rozdíl mezi perkálem a saténem?",
    "answer": "Perkál je matný a chladivý na dotek, bavlněný satén lesklejší a hebký. Oba jsou z jemné bavlny."
   },
   {
    "question": "Žmolkuje perkálové povlečení?",
    "answer": "Kvalitní perkál nežmolkuje, protože je velmi hustě tkaný."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/satenove-povleceni/": {
  "h1": "Saténové povlečení",
  "short": "Povlečení z bavlněného saténu – hladké, hebké a příjemné na dotek.",
  "long": [
   {
    "t": "p",
    "text": "Bavlněný satén je látka utkaná z jemně česané 100% bavlny, která vytváří hladký, saténový povrch velmi příjemný na dotek. Kolekce SATIN De Luxe a SATIN Prémium odvádějí vlhkost a přispívají ke klidnému spánku."
   }
  ],
  "faq": [
   {
    "question": "Je saténové povlečení z bavlny?",
    "answer": "Ano. Bavlněný satén je ze 100% jemně česané bavlny, která vytváří hladký saténový povrch."
   },
   {
    "question": "Mačká se saténové povlečení?",
    "answer": "Bavlněný satén se mačká méně než klasická bavlna."
   }
  ]
 },
 "/povleceni-a-prosteradla/povleceni/flanelove-povleceni/": {
  "h1": "Flanelové povlečení",
  "short": "Hřejivé flanelové povlečení na chladné noci.",
  "long": [
   {
    "t": "p",
    "text": "Flanel je bavlněná látka s počesaným povrchem, který příjemně hřeje. Flanelové povlečení je ideální na zimu a pro všechny, komu bývá v noci zima."
   }
  ],
  "faq": [
   {
    "question": "Je flanelové povlečení vhodné na léto?",
    "answer": "Spíše ne. Flanel s počesaným povrchem hřeje, proto je určený hlavně na chladnější období."
   },
   {
    "question": "Žmolkuje flanelové povlečení?",
    "answer": "Kvalitní flanel žmolkuje jen minimálně."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/": {
  "h1": "Napínací prostěradla",
  "short": "Napínací prostěradla na klasické i vysoké matrace – bavlněná a pružná.",
  "long": [
   {
    "t": "p",
    "text": "Napínací prostěradlo drží na matraci pevně, neshrnuje se a nemusí se žehlit. Vybírejte podle rozměru a hlavně podle výšky matrace."
   },
   {
    "t": "h",
    "text": "Jersey, nebo Super Stretch?"
   },
   {
    "t": "ul",
    "items": [
     "Jersey Delux – hladká pletenina ze 100% bavlny, prodyšná a příjemná na dotek, pro matrace do výšky 25 cm.",
     "Super Stretch Jersey – 97 % bavlny a 3 % elastanu, velmi pružné, se zesílenou gumou, pro vysoké matrace až do 30 cm, například prémiové řady."
    ]
   },
   {
    "t": "h",
    "text": "Jak zvolit rozměr"
   },
   {
    "t": "p",
    "text": "Prostěradlo má stejný rozměr jako matrace. Máte-li v dvojlůžku dvě matrace 90×200, použijte dvě prostěradla 90×200. Jedno velké prostěradlo 180×200 se hodí na jednu velkou matraci nebo na dvě matrace spojené topperem."
   },
   {
    "t": "h",
    "text": "Péče"
   },
   {
    "t": "p",
    "text": "Jersey prostěradla se nežehlí, jsou odolná proti žmolkování a snadno se perou."
   },
   {
    "t": "h",
    "text": "Jak napínací prostěradla prát"
   },
   {
    "t": "p",
    "text": "Prostěradla perte podle pokynů na etiketě, ideálně s ostatním bavlněným prádlem. Nepřesušujte je v horké sušičce – guma po obvodu tak vydrží déle pružná. Po vyprání je stačí natáhnout na matraci, žehlit je nemusíte."
   },
   {
    "t": "h",
    "text": "Prostěradlo a chránič matrace"
   },
   {
    "t": "p",
    "text": "Pod prostěradlo doporučujeme pratelný chránič matrace. Chrání matraci před potem a nečistotami a prodlužuje její životnost."
   }
  ],
  "faq": [
   {
    "question": "Jaké prostěradlo na vysokou matraci?",
    "answer": "Napínací prostěradlo Super Stretch Jersey, které díky elastanu sedí na matrace až do výšky 30 cm."
   },
   {
    "question": "Je potřeba napínací prostěradlo žehlit?",
    "answer": "Ne. Jersey prostěradla se nežehlí a po vyprání stačí je natáhnout na matraci."
   },
   {
    "question": "Jaké prostěradlo na dvě matrace 90×200?",
    "answer": "Dvě prostěradla 90×200 cm, na každou matraci jedno. Jedno prostěradlo 180×200 použijte, jen pokud matrace spojuje topper."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/jersey-prosteradla/": {
  "h1": "Jersey prostěradla",
  "short": "Napínací prostěradla Jersey ze 100% bavlny pro matrace do 25 cm.",
  "long": [
   {
    "t": "p",
    "text": "Napínací prostěradlo Jersey je vyrobené z hladké pleteniny z prvotřídní 100% bavlny, která je prodyšná a příjemná na dotek. Snadno se udržuje, nemusí se žehlit a perfektně sedí na matrace s výškou až 25 cm."
   }
  ],
  "faq": [
   {
    "question": "Na jak vysokou matraci je prostěradlo Jersey?",
    "answer": "Prostěradlo Jersey Delux sedí na matrace do výšky 25 cm. Na vyšší matrace zvolte Super Stretch Jersey."
   },
   {
    "question": "Musí se prostěradlo Jersey žehlit?",
    "answer": "Ne. Jersey prostěradlo ze 100% bavlny se nežehlí."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/prosteradla-na-vysoke-matrace/": {
  "h1": "Prostěradla na vysoké matrace",
  "short": "Napínací prostěradla Super Stretch Jersey na vysoké matrace až 30 cm.",
  "long": [
   {
    "t": "p",
    "text": "Prostěradlo Jersey Super Stretch je z 97 % bavlny a 3 % elastanu, díky čemuž je velmi pružné a perfektně se přizpůsobí matracím až do výšky 30 cm. Trvalá elasticita a zesílená okrajová guma drží tvar, prostěradlo je prodyšné a odolné proti žmolkování."
   }
  ],
  "faq": [
   {
    "question": "Pro jak vysokou matraci je prostěradlo Super Stretch?",
    "answer": "Prostěradlo Super Stretch Jersey sedí na matrace až do výšky 30 cm, takže se hodí i na prémiové matrace."
   },
   {
    "question": "Žmolkuje prostěradlo Super Stretch?",
    "answer": "Ne. Prostěradlo Super Stretch Jersey je odolné proti žmolkování a drží tvar díky zesílené okrajové gumě."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/prosteradla-90x200/": {
  "h1": "Prostěradla 90×200 cm",
  "short": "Napínací prostěradla 90×200 cm pro jednolůžka a dvojlůžka 180×200 (2 ks).",
  "long": [
   {
    "t": "p",
    "text": "Napínací prostěradlo 90×200 cm je nejprodávanější rozměr. Hodí se na jednolůžko a v páru na dvojlůžko 180×200 cm se dvěma matracemi 90×200 – každá matrace má pak vlastní prostěradlo, které se nikam neshrnuje. Na matrace do 25 cm volte Jersey Delux ze 100% bavlny, na vyšší matrace až do 30 cm pružné Super Stretch Jersey."
   }
  ],
  "faq": [
   {
    "question": "Jaké prostěradlo 90×200 na matraci vysokou 28 cm?",
    "answer": "Na matraci vysokou 28 cm zvolte prostěradlo 90×200 Super Stretch Jersey, které sedí na matrace až do výšky 30 cm."
   },
   {
    "question": "Musí se prostěradlo 90×200 žehlit?",
    "answer": "Ne. Napínací prostěradla Jersey v rozměru 90×200 cm se nežehlí a po vyprání je stačí natáhnout na matraci."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/prosteradla-140x200/": {
  "h1": "Prostěradla 140×200 cm",
  "short": "Napínací prostěradla 140×200 cm pro menší dvojlůžka.",
  "long": [
   {
    "t": "p",
    "text": "Napínací prostěradlo 140×200 cm je určené pro menší dvojlůžka s jednou matrací přes celou šíři. Na běžné matrace do výšky 25 cm sáhněte po bavlněném Jersey Delux, na vyšší matrace nebo matraci s topperem až do 30 cm po pružném Super Stretch Jersey s elastanem."
   }
  ],
  "faq": [
   {
    "question": "Jaké prostěradlo 140×200 na matraci vysokou 28 cm?",
    "answer": "Na matraci vysokou 28 cm zvolte prostěradlo 140×200 Super Stretch Jersey, které sedí na matrace až do výšky 30 cm."
   },
   {
    "question": "Musí se prostěradlo 140×200 žehlit?",
    "answer": "Ne. Napínací prostěradla Jersey v rozměru 140×200 cm se nežehlí a po vyprání je stačí natáhnout na matraci."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/prosteradla-160x200/": {
  "h1": "Prostěradla 160×200 cm",
  "short": "Napínací prostěradla 160×200 cm pro manželské postele s jednou matrací 160×200.",
  "long": [
   {
    "t": "p",
    "text": "Napínací prostěradlo 160×200 cm je pro manželské postele s jednou matrací 160×200 cm nebo se dvěma matracemi 80×200 spojenými topperem. Pokud máte dvě samostatné matrace bez topperu, zvolte raději dvě prostěradla 80×200. Jersey Delux sedí na matrace do 25 cm, Super Stretch do 30 cm."
   }
  ],
  "faq": [
   {
    "question": "Jaké prostěradlo 160×200 na matraci vysokou 28 cm?",
    "answer": "Na matraci vysokou 28 cm zvolte prostěradlo 160×200 Super Stretch Jersey, které sedí na matrace až do výšky 30 cm."
   },
   {
    "question": "Musí se prostěradlo 160×200 žehlit?",
    "answer": "Ne. Napínací prostěradla Jersey v rozměru 160×200 cm se nežehlí a po vyprání je stačí natáhnout na matraci."
   }
  ]
 },
 "/povleceni-a-prosteradla/prosteradla/prosteradla-180x200/": {
  "h1": "Prostěradla 180×200 cm",
  "short": "Napínací prostěradla 180×200 cm pro manželské postele s jednou matrací 180×200.",
  "long": [
   {
    "t": "p",
    "text": "Napínací prostěradlo 180×200 cm patří na jednu velkou matraci 180×200 cm nebo na dvě matrace 90×200 spojené topperem do jedné plochy. Bez topperu doporučujeme dvě prostěradla 90×200 – každé drží na své matraci a nic se neposouvá do spáry. Pro vysoké matrace a toppery až do 30 cm volte Super Stretch Jersey."
   }
  ],
  "faq": [
   {
    "question": "Jaké prostěradlo 180×200 na matraci vysokou 28 cm?",
    "answer": "Na matraci vysokou 28 cm zvolte prostěradlo 180×200 Super Stretch Jersey, které sedí na matrace až do výšky 30 cm."
   },
   {
    "question": "Musí se prostěradlo 180×200 žehlit?",
    "answer": "Ne. Napínací prostěradla Jersey v rozměru 180×200 cm se nežehlí a po vyprání je stačí natáhnout na matraci."
   },
   {
    "question": "Jedno prostěradlo 180×200, nebo dvě 90×200?",
    "answer": "Na jednu matraci 180×200 nebo na dvě matrace spojené topperem patří jedno prostěradlo 180×200. Na dvě samostatné matrace 90×200 bez topperu doporučujeme dvě prostěradla 90×200."
   }
  ]
 },
 "/povleceni-a-prosteradla/povlaky/": {
  "h1": "Povlaky na polštáře a přikrývky",
  "short": "Povlaky na polštáře 40×70 a 70×90 cm i povlaky na přikrývky.",
  "long": [
   {
    "t": "p",
    "text": "Samostatné povlaky se hodí, když chcete obměnit jen polštář nebo přikrývku, potřebujete povlak na druhou sadu, nebo přecházíte na zdravější polštář 40×70 cm."
   },
   {
    "t": "h",
    "text": "Povlaky na polštáře 40×70 a 70×90"
   },
   {
    "t": "p",
    "text": "Povlaky 40×70 cm k polštáři, který Světspánku.cz doporučuje pro zdravý spánek, nabízíme z bavlny i bavlněného saténu v barvách sladěných s povlečením. Klasické povlaky 70×90 cm najdete také."
   },
   {
    "t": "h",
    "text": "Potahy na anatomické polštáře"
   },
   {
    "t": "p",
    "text": "Anatomické polštáře z paměťové pěny mají vlastní tvar, proto pro ně nabízíme náhradní potahy na zip."
   },
   {
    "t": "h",
    "text": "Povlaky na přikrývky"
   },
   {
    "t": "p",
    "text": "Samostatné povlaky na přikrývky 140×200 i prodloužené 140×220 cm."
   }
  ],
  "faq": [
   {
    "question": "Máte povlaky na polštář 40×70?",
    "answer": "Ano. Povlaky 40×70 cm nabízíme z bavlny i bavlněného saténu – je to rozměr, který doporučujeme pro zdravý spánek."
   },
   {
    "question": "Mají potahy na anatomické polštáře zip?",
    "answer": "Ano. Náhradní potahy na anatomické polštáře z paměťové pěny se zapínají na zip."
   },
   {
    "question": "Jaké rozměry povlaků na přikrývky nabízíte?",
    "answer": "Standardní 140×200 cm a prodloužené 140×220 cm."
   }
  ]
 },
 "/povleceni-a-prosteradla/povlaky/povlaky-40x70/": {
  "h1": "Povlaky na polštář 40×70",
  "short": "Povlaky na polštáře 40×70 cm – k polštáři, který doporučujeme pro zdravý spánek.",
  "long": [
   {
    "t": "p",
    "text": "Přecházíte na menší polštář 40×70 cm? Povlaky v tomto rozměru u nás seženete z bavlny i bavlněného saténu, v barvách, které ladí s povlečením. Rozměr 40×70 cm doporučujeme, protože polštář podepře hlavu a krk, ale ne ramena."
   }
  ],
  "faq": [
   {
    "question": "Pasuje povlak 40×70 na anatomický polštář?",
    "answer": "Povlak 40×70 cm pasuje na klasický polštář 40×70. Na anatomické polštáře z paměťové pěny doporučujeme jejich vlastní potahy na zip."
   },
   {
    "question": "Z jakého materiálu jsou povlaky 40×70?",
    "answer": "Povlaky na polštář 40×70 cm nabízíme z bavlny i bavlněného saténu v barvách sladěných s povlečením."
   }
  ]
 },
 "/povleceni-a-prosteradla/povlaky/povlaky-70x90/": {
  "h1": "Povlaky na polštář 70×90",
  "short": "Povlaky na polštáře 70×90 cm z bavlny a bavlněného saténu.",
  "long": [
   {
    "t": "p",
    "text": "Povlaky na klasické polštáře 70×90 cm – damaškové i saténové ze 100% bavlny."
   }
  ],
  "faq": [
   {
    "question": "Z čeho jsou povlaky na polštář 70×90?",
    "answer": "Povlaky 70×90 cm jsou ze 100% bavlny – damaškové i saténové."
   },
   {
    "question": "Lze povlaky 70×90 prát na vysokou teplotu?",
    "answer": "Teplotu praní najdete na etiketě konkrétního povlaku."
   }
  ]
 },
 "/povleceni-a-prosteradla/povlaky/povlaky-na-prikryvky/": {
  "h1": "Povlaky na přikrývky",
  "short": "Samostatné povlaky na přikrývky.",
  "long": [
   {
    "t": "p",
    "text": "Samostatné povlaky na přikrývky se hodí, když chcete obměnit jen přikrývku nebo máte prodlouženou přikrývku."
   }
  ],
  "faq": [
   {
    "question": "Jaké rozměry povlaků na přikrývky nabízíte?",
    "answer": "Povlaky na přikrývky nabízíme ve standardním rozměru 140×200 cm i prodloužené 140×220 cm."
   },
   {
    "question": "Mají povlaky na přikrývky zapínání na zip?",
    "answer": "Typ zapínání najdete u konkrétního povlaku."
   }
  ]
 },
 "/akce/": {
  "h1": "Akce na postele, matrace a nábytek",
  "short": "Akční nabídky postelí, matrací, roštů, lůžkovin a nábytku na jednom místě.",
  "long": [
   {
    "t": "p",
    "text": "Tady najdete nejlepší slevy na postele, matrace, rošty, lůžkoviny i dřevěný ložnicový nábytek. Pravidelně vybíráme kvalitní produkty z naší nabídky a zlevňujeme je, abyste mohli dopřát sobě i své ložnici to nejlepší za výhodnou cenu. Ve výprodeji pak najdete poslední kusy a vystavené modely z prodejen."
   }
  ],
  "faq": [
   {
    "question": "Jak často se akce na Světspánku.cz mění?",
    "answer": "Akce průběžně obměňujeme, proto se vyplatí sem pravidelně vracet."
   },
   {
    "question": "Jsou akční produkty nové?",
    "answer": "Ano, kromě výprodeje, kde mohou být i vystavené kusy z prodejen. Stav je vždy uveden u produktu."
   },
   {
    "question": "Platí na akční zboží záruka?",
    "answer": "Ano. Na akční zboží platí stejná záruka jako na ostatní zboží."
   }
  ]
 },
 "/akce/aktualni-akce/": {
  "h1": "Aktuální akce",
  "short": "Právě probíhající akce na postele, matrace a doplňky.",
  "long": [
   {
    "t": "p",
    "text": "Aktuální akce sdružují všechny produkty, které jsou právě za zvýhodněnou cenu – postele z masivu, matrace, rošty i lůžkoviny. Akční ceny platí po omezenou dobu nebo do vyprodání zásob."
   }
  ],
  "faq": [
   {
    "question": "Do kdy akce platí?",
    "answer": "Termín platnosti najdete u každé akce nebo produktu – akční ceny platí po omezenou dobu nebo do vyprodání zásob."
   },
   {
    "question": "Lze akce kombinovat?",
    "answer": "Možnost kombinace najdete v podmínkách konkrétní akce."
   }
  ]
 },
 "/akce/vyprodej/": {
  "h1": "Výprodej – poslední kusy za skvělé ceny",
  "short": "Poslední kusy a vystavené modely postelí, matrací a nábytku se slevou.",
  "long": [
   {
    "t": "p",
    "text": "Uvolňujeme místo pro nové kolekce, a to znamená výprodej skladu i expozic. Ideální příležitost pořídit si kvalitní postel, matraci nebo nábytek za výrazně nižší cenu. Pozor – jde o poslední kusy, takže kdo dřív přijde, ten dřív spí."
   }
  ],
  "faq": [
   {
    "question": "Jsou ve výprodeji i vystavené kusy?",
    "answer": "Ano. Ve výprodeji najdete poslední kusy ze skladu i vystavené modely z prodejen; stav je vždy uveden u produktu."
   },
   {
    "question": "Platí na zboží z výprodeje záruka?",
    "answer": "Ano. Na zboží z výprodeje platí záruka stejně jako na ostatní zboží."
   }
  ]
 },
 "/akce/darkovy-poukaz/": {
  "h1": "Dárkový poukaz Světspánku.cz",
  "short": "Darujte kvalitní spánek – dárkový poukaz na celý sortiment Světspánku.cz.",
  "long": [
   {
    "t": "p",
    "text": "Nevíte, jakou matraci nebo polštář vybrat? Darujte dárkový poukaz a obdarovaný si zvolí sám – postel z masivu, matraci, polštář, přikrývku, povlečení nebo nábytek do ložnice. Poukaz se hodí k Vánocům, k narozeninám, ke svatbě i k nastěhování do nového bytu. Uplatnit ho lze v e-shopu i na našich prodejnách v Brně, Praze, Olomouci a Ostravě."
   }
  ],
  "faq": [
   {
    "question": "Na co lze dárkový poukaz Světspánku.cz použít?",
    "answer": "Dárkový poukaz lze použít na celý sortiment – postele, matrace, rošty, polštáře, lůžkoviny i nábytek."
   },
   {
    "question": "Lze dárkový poukaz uplatnit na prodejně?",
    "answer": "Ano. Dárkový poukaz můžete uplatnit v e-shopu i na prodejnách Světspánku.cz."
   },
   {
    "question": "Jak dlouho je dárkový poukaz platný?",
    "answer": "Platnost je uvedena přímo na dárkovém poukazu."
   }
  ]
 },
 "/akce/darky-k-nakupu/": {
  "h1": "Dárky k nákupu",
  "short": "K vybraným postelím a matracím získáte dárek nebo doplněk za zvýhodněnou cenu.",
  "long": [
   {
    "t": "p",
    "text": "Při nákupu postele nebo matrace se vyplatí myslet i na to, co k nim patří. V této kategorii najdete dárky a doplňky, které k nákupu získáte zdarma nebo výrazně levněji – například anatomický polštář k matraci za polovinu ceny. Nabídku průběžně obměňujeme podle aktuálních akcí, podmínky najdete vždy u konkrétního produktu."
   }
  ],
  "faq": [
   {
    "question": "Jak dárek k nákupu získám?",
    "answer": "Podmínky jsou uvedené u každé nabídky – obvykle stačí vložit dárek do košíku spolu s postelí nebo matrací."
   },
   {
    "question": "Platí dárky k nákupu i na prodejně?",
    "answer": "Podmínky konkrétní akce najdete u produktu, případně se zeptejte prodejců na prodejně."
   }
  ]
 },
 "/novinky/": {
  "h1": "Novinky",
  "short": "Nejnovější přírůstky v naší nabídce.",
  "long": [
   {
    "t": "p",
    "text": "Na této stránce najdete všechno, co jsme nově zařadili do nabídky – nové modely postelí z masivu, matrace, polštáře i doplňky. Novinky si můžete prohlédnout i na našich prodejnách."
   }
  ],
  "faq": [
   {
    "question": "Jak často přidáváte novinky?",
    "answer": "Novinky do nabídky Světspánku.cz přidáváme průběžně během celého roku."
   },
   {
    "question": "Jsou novinky vystavené na prodejnách?",
    "answer": "Většinou ano. Dostupnost konkrétního produktu na prodejně ověříte u produktu."
   }
  ]
 }
};
if (typeof window !== 'undefined') { window.TEXTY = TEXTY; }
