// Sdílená data hlavní navigace. Používá Hlavicka, MegaMenu, MobilniMenuObsah a Kategorie.
// Struktura kategorií podle Muralu klienta „NÁVRH 10/2026 – v2 (konverze)“ a Excelu kategorií (30. 10. 2026). Generuje gen_menu.py, neupravovat ručně.
// Odkazy: každá L2/L3 kategorie má vlastní vzorovou plochu Kategorie_<Sekce>_<slug>.dc.html (plátno nepředává hash). Pole url = navržená URL na ostrém webu, h1 = nadpis z Excelu.
// Sekce: label, slug, href, image, all {label, href}, top [{kind: promo|guide|article, …}] (šedá řada nad sloupci), groups (sloupce).
// Sloupec: title, href, image, chips (sizes|prices|hardness = řada tlačítek, v mobilu bez další úrovně), best (★ Nejprodávanější), link (šedý odkaz do jiné sekce), items.
// Položka: label, href, note (tvrdost: váha), tip (příznak TIP), link (odkaz do jiné sekce).
export const MENU = [
  {
    "label": "Postele z masivu",
    "slug": "postele",
    "href": "Kategorie_Postele.dc.html",
    "url": "/postele-z-masivu/",
    "image": "/_blob/cead5c69b22e38051d5480ee3e14c348",
    "all": {
      "label": "Zobrazit všechny postele",
      "href": "Kategorie_Postele.dc.html"
    },
    "top": [
      {
        "kind": "promo",
        "label": "Postel na míru",
        "sub": "Vyrobíme na cm přesně",
        "href": "#vyroba-na-miru",
        "image": "/_blob/9459bc77080c613fe49b26658905c0d9"
      },
      {
        "kind": "promo",
        "label": "Postel s matrací a roštem",
        "sub": "Ušetříte až 30 %",
        "href": "Kategorie_Komplety_komplet-postel-s-matracemi.dc.html",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd"
      },
      {
        "kind": "article",
        "title": "Jak vybrat postel",
        "href": "https://blog.svetspanku.cz/jak-vybrat-postel",
        "image": "/_blob/50fbc8ecc5ccb479e539edd24a0148e8"
      },
      {
        "kind": "article",
        "title": "Postel s úložným prostorem – vyplatí se?",
        "href": "https://blog.svetspanku.cz/postel-s-uloznym-prostorem",
        "image": "/_blob/3c98d27c417e1d9ccb47b84ffe13df76"
      }
    ],
    "groups": [
      {
        "title": "Postele podle rozměru",
        "href": "Kategorie_Postele_podle-rozmeru.dc.html",
        "url": "/postele-z-masivu/podle-rozmeru/",
        "h1": "Postele z masivu podle rozměru",
        "image": "/_blob/9459bc77080c613fe49b26658905c0d9",
        "chips": "sizes",
        "items": [
          {
            "label": "80 × 200",
            "href": "Kategorie_Postele_postele-80x200.dc.html",
            "url": "/postele-z-masivu/postele-80x200/",
            "h1": "Postele 80×200 cm z masivu"
          },
          {
            "label": "90 × 200",
            "href": "Kategorie_Postele_postele-90x200.dc.html",
            "url": "/postele-z-masivu/postele-90x200/",
            "h1": "Postele 90×200 cm z masivu"
          },
          {
            "label": "100 × 200",
            "href": "Kategorie_Postele_postele-100x200.dc.html",
            "url": "/postele-z-masivu/postele-100x200/",
            "h1": "Postele 100×200 cm z masivu"
          },
          {
            "label": "120 × 200",
            "href": "Kategorie_Postele_postele-120x200.dc.html",
            "url": "/postele-z-masivu/postele-120x200/",
            "h1": "Postele 120×200 cm z masivu"
          },
          {
            "label": "140 × 200",
            "href": "Kategorie_Postele_postele-140x200.dc.html",
            "url": "/postele-z-masivu/postele-140x200/",
            "h1": "Postele 140×200 cm z masivu"
          },
          {
            "label": "160 × 200",
            "href": "Kategorie_Postele_postele-160x200.dc.html",
            "url": "/postele-z-masivu/postele-160x200/",
            "h1": "Postele 160×200 cm z masivu"
          },
          {
            "label": "180 × 200",
            "href": "Kategorie_Postele_postele-180x200.dc.html",
            "url": "/postele-z-masivu/postele-180x200/",
            "h1": "Postele 180×200 cm z masivu"
          },
          {
            "label": "200 × 200",
            "href": "Kategorie_Postele_postele-200x200.dc.html",
            "url": "/postele-z-masivu/postele-200x200/",
            "h1": "Postele 200×200 cm z masivu"
          },
          {
            "label": "Prodloužené postele",
            "href": "Kategorie_Postele_prodlouzene-postele.dc.html",
            "url": "/postele-z-masivu/prodlouzene-postele/",
            "h1": "Prodloužené postele z masivu"
          },
          {
            "label": "Postele pro 3 osoby",
            "href": "Kategorie_Postele_postele-pro-3-osoby.dc.html",
            "url": "/postele-z-masivu/postele-pro-3-osoby/",
            "h1": "Rozšířené postele pro tři"
          },
          {
            "label": "Postele na míru",
            "href": "#vyroba-na-miru",
            "link": true
          }
        ]
      },
      {
        "title": "Manželské postele",
        "href": "Kategorie_Postele_manzelske-postele-z-masivu.dc.html",
        "url": "/postele-z-masivu/manzelske-postele-z-masivu/",
        "h1": "Manželské postele z masivu",
        "image": "/_blob/cead5c69b22e38051d5480ee3e14c348",
        "items": [
          {
            "label": "S nočními stolky",
            "href": "Kategorie_Postele_postele-s-nocnimi-stolky.dc.html",
            "url": "/postele-z-masivu/postele-s-nocnimi-stolky/",
            "h1": "Masivní postele s integrovanými nočními stolky"
          },
          {
            "label": "S LED osvětlením",
            "href": "Kategorie_Postele_postele-s-led-osvetlenim.dc.html",
            "url": "/postele-z-masivu/postele-s-led-osvetlenim/",
            "h1": "Postele z masivu s LED osvětlením"
          },
          {
            "label": "Vysoké postele (pro seniory)",
            "href": "Kategorie_Postele_zvysena-postel.dc.html",
            "url": "/postele-z-masivu/manzelske-postele-z-masivu/zvysena-postel/",
            "h1": "Vysoké postele z masivu"
          }
        ]
      },
      {
        "title": "Postele s úložným prostorem",
        "href": "Kategorie_Postele_postele-s-uloznym-prostorem.dc.html",
        "url": "/postele-z-masivu/postele-s-uloznym-prostorem/",
        "h1": "Postele s úložným prostorem z masivu",
        "image": "/_blob/3c98d27c417e1d9ccb47b84ffe13df76",
        "items": [
          {
            "label": "Manželské postele s úložným prostorem",
            "href": "Kategorie_Postele_manzelske-postele-s-uloznym-prostorem.dc.html",
            "url": "/postele-z-masivu/manzelske-postele-s-uloznym-prostorem/",
            "h1": "Manželské postele s úložným prostorem z masivu"
          },
          {
            "label": "Jednolůžkové postele s úložným prostorem",
            "href": "Kategorie_Postele_jednoluzkove-postele-s-uloznym-prostorem.dc.html",
            "url": "/postele-z-masivu/jednoluzkove-postele-s-uloznym-prostorem/",
            "h1": "Jednolůžkové postele s úložným prostorem z masivu"
          },
          {
            "label": "Čalouněné postele s úložným prostorem",
            "href": "Kategorie_Postele_calounene-postele-s-uloznym-prostorem.dc.html",
            "url": "/postele-z-masivu/calounene-postele-s-uloznym-prostorem/",
            "h1": "Čalouněné postele s úložným prostorem z masivu"
          }
        ]
      },
      {
        "title": "Jednolůžkové postele",
        "href": "Kategorie_Postele_jednoluzkove-postele-z-masivu.dc.html",
        "url": "/postele-z-masivu/jednoluzkove-postele-z-masivu/",
        "h1": "Jednolůžkové postele z masivu",
        "image": "/_blob/cbd39695e60222550587109c72c8c52b",
        "items": [
          {
            "label": "Čalouněné jednolůžka",
            "href": "Kategorie_Postele_calounene-jednoluzka.dc.html",
            "url": "/postele-z-masivu/calounene-jednoluzka/",
            "h1": "Čalouněné jednolůžkové postele"
          },
          {
            "label": "Nízké postele",
            "href": "Kategorie_Postele_nizke-postele.dc.html",
            "url": "/postele-z-masivu/nizke-postele/",
            "h1": "Nižší postele z masivu"
          }
        ]
      },
      {
        "title": "Dětské a patrové postele",
        "href": "Kategorie_Postele_detske-postele-z-masivu.dc.html",
        "url": "/postele-z-masivu/detske-postele-z-masivu/",
        "h1": "Dětské a patrové postele z masivu",
        "image": "/_blob/372550141951862e0591a3e1d5baab98",
        "items": [
          {
            "label": "Patrové postele",
            "href": "Kategorie_Postele_patrove-postele.dc.html",
            "url": "/postele-z-masivu/patrove-postele/",
            "h1": "Patrové postele z masivu"
          },
          {
            "label": "Dětské postele",
            "href": "Kategorie_Postele_detske-postele.dc.html",
            "url": "/postele-z-masivu/detske-postele/",
            "h1": "Dětské postele z masivu"
          },
          {
            "label": "Dětské komplety",
            "href": "Kategorie_Komplety_komplet-s-uloznym-prostorem.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Čalouněné postele",
        "href": "Kategorie_Postele_calounene-masivni-postele.dc.html",
        "url": "/postele-z-masivu/calounene-masivni-postele/",
        "h1": "Čalouněné postele s konstrukcí z masivu",
        "image": "/_blob/83b97877b4eeaa401d7d46a9fa01dd17",
        "items": [
          {
            "label": "Kombinované dřevo + čalounění",
            "href": "Kategorie_Postele_postele-drevo-a-calouneni.dc.html",
            "url": "/postele-z-masivu/postele-drevo-a-calouneni/",
            "h1": "Postele z masivu s čalouněním"
          },
          {
            "label": "Boční panely s LED a USB",
            "href": "Kategorie_Postele_postele-s-led-a-usb.dc.html",
            "url": "/postele-z-masivu/postele-s-led-a-usb/",
            "h1": "Čalouněné postele s LED a USB"
          }
        ]
      },
      {
        "title": "Kontinentální a boxspring postele",
        "href": "Kategorie_Postele_kontinentalni-a-boxspring-postele.dc.html",
        "url": "/postele-z-masivu/kontinentalni-a-boxspring-postele/",
        "h1": "Kontinentální a boxspring postele",
        "image": "/_blob/c2272a0e9ca10090147050821599f427",
        "items": [
          {
            "label": "Boxspring postele",
            "href": "Kategorie_Postele_boxspring-postele.dc.html",
            "url": "/postele-z-masivu/boxspring-postele/",
            "h1": "Boxspring postele"
          },
          {
            "label": "S úložným prostorem",
            "href": "Kategorie_Postele_boxspring-s-uloznym-prostorem.dc.html",
            "url": "/postele-z-masivu/boxspring-s-uloznym-prostorem/",
            "h1": "Boxspring postele s úložným prostorem"
          }
        ]
      },
      {
        "title": "Rozkládací postele / pohovky",
        "href": "Kategorie_Postele_rozkladaci-postele-pohovky.dc.html",
        "url": "/postele-z-masivu/rozkladaci-postele-pohovky/",
        "h1": "Rozkládací postele a pohovky z masivu",
        "image": "/_blob/7248cf07bd3a1e7a83b38dfc5d15d179",
        "items": []
      },
      {
        "title": "MULTI – modulární postele",
        "href": "Kategorie_Postele_multi-modularni-postele.dc.html",
        "url": "/postele-z-masivu/multi-modularni-postele/",
        "h1": "MULTI – modulární postele z masivu",
        "image": "/_blob/0e8664e98d4e03179bcd7446fb1b686c",
        "items": [
          {
            "label": "Rám bez úložného prostoru",
            "href": "Kategorie_Postele_ram-bez-ulozneho-prostoru.dc.html",
            "url": "/postele-z-masivu/multi-modularni-postele/ram-bez-ulozneho-prostoru/",
            "h1": "MULTI – rám bez úložného prostoru"
          },
          {
            "label": "Rám s úložným prostorem",
            "href": "Kategorie_Postele_ram-s-uloznym-prostorem.dc.html",
            "url": "/postele-z-masivu/multi-modularni-postele/ram-s-uloznym-prostorem/",
            "h1": "MULTI – rám s úložným prostorem"
          },
          {
            "label": "Čelo postele",
            "href": "Kategorie_Postele_cela-postele.dc.html",
            "url": "/postele-z-masivu/multi-modularni-postele/cela-postele/",
            "h1": "MULTI – čelo postele"
          }
        ]
      },
      {
        "title": "Doplňky k posteli",
        "href": "Kategorie_Postele_doplnky-k-posteli.dc.html",
        "url": "/postele-z-masivu/doplnky-k-posteli/",
        "h1": "Doplňky k posteli",
        "image": "/_blob/8e840d302ff9d7f742f55c829e285d66",
        "items": [
          {
            "label": "Noční stolky a police",
            "href": "Kategorie_Nabytek_nocni-stolky-a-police.dc.html",
            "link": true
          },
          {
            "label": "LED osvětlení k posteli",
            "href": "Kategorie_Postele_led-osvetleni-postele.dc.html",
            "url": "/postele-z-masivu/led-osvetleni-postele/",
            "h1": "LED osvětlení postelí"
          },
          {
            "label": "Úložné prostory",
            "href": "Kategorie_Postele_ulozne-prostory-z-masivu.dc.html",
            "url": "/postele-z-masivu/ulozne-prostory-z-masivu/",
            "h1": "Úložné prostory pod postel z masivu"
          },
          {
            "label": "Rošty",
            "href": "Kategorie_Rosty.dc.html",
            "link": true
          },
          {
            "label": "Postele s matrací a roštem",
            "href": "Kategorie_Komplety_komplet-postel-s-matracemi.dc.html",
            "link": true
          }
        ]
      }
    ]
  },
  {
    "label": "Matrace",
    "slug": "matrace",
    "href": "Kategorie_Matrace.dc.html",
    "url": "/matrace/",
    "image": "/_blob/c5a374fbd36fa4495aacd11898012a93",
    "all": {
      "label": "Zobrazit všechny matrace",
      "href": "Kategorie_Matrace.dc.html"
    },
    "top": [
      {
        "kind": "guide",
        "label": "Průvodce výběrem matrace",
        "sub": "Osm otázek a doporučíme model",
        "href": "PruvodceMatrace.dc.html"
      },
      {
        "kind": "promo",
        "label": "30 nocí jistoty",
        "sub": "Nesedí tvrdost? Jádro vyměníme zdarma",
        "href": "Clanek.dc.html",
        "image": "/_blob/9d9a5cf74921be762c6f2e626a5ee752",
        "imageFit": "contain"
      },
      {
        "kind": "article",
        "title": "Jak si vybrat matraci",
        "href": "https://blog.svetspanku.cz/jak-vybrat-matraci",
        "image": "/_blob/a4bdfc3ddeb575fee8768a3cf2019524"
      },
      {
        "kind": "article",
        "title": "Tvrdost matrace – jak vybrat tu správnou",
        "href": "https://blog.svetspanku.cz/tuhost-matrace-jak-vybrat-tu-spravnou",
        "image": "/_blob/dc5fa8667ca1a270c407277d68672f80"
      }
    ],
    "groups": [
      {
        "title": "Nejprodávanější matrace",
        "href": "Kategorie_Matrace_nejprodavanejsi-matrace.dc.html",
        "url": "/matrace/",
        "h1": "Nejprodávanější matrace",
        "image": "/_blob/66ef2119f31d8262ba38ce4bea618a8e",
        "best": true,
        "items": []
      },
      {
        "title": "Matrace podle rozměru",
        "href": "Kategorie_Matrace_podle-rozmeru.dc.html",
        "url": "/matrace/podle-rozmeru/",
        "h1": "Matrace podle rozměru",
        "image": "/_blob/9459bc77080c613fe49b26658905c0d9",
        "chips": "sizes",
        "items": [
          {
            "label": "80 × 200",
            "href": "Kategorie_Matrace_matrace-80x200.dc.html",
            "url": "/matrace/matrace-80x200/",
            "h1": "Matrace 80×200 cm"
          },
          {
            "label": "90 × 200",
            "href": "Kategorie_Matrace_matrace-90x200.dc.html",
            "url": "/matrace/matrace-90x200/",
            "h1": "Matrace 90×200 cm"
          },
          {
            "label": "100 × 200",
            "href": "Kategorie_Matrace_matrace-100x200.dc.html",
            "url": "/matrace/matrace-100x200/",
            "h1": "Matrace 100×200 cm"
          },
          {
            "label": "120 × 200",
            "href": "Kategorie_Matrace_matrace-120x200.dc.html",
            "url": "/matrace/matrace-120x200/",
            "h1": "Matrace 120×200 cm"
          },
          {
            "label": "140 × 200",
            "href": "Kategorie_Matrace_matrace-140x200.dc.html",
            "url": "/matrace/matrace-140x200/",
            "h1": "Matrace 140×200 cm"
          },
          {
            "label": "160 × 200",
            "href": "Kategorie_Matrace_matrace-160x200.dc.html",
            "url": "/matrace/matrace-160x200/",
            "h1": "Matrace 160×200 cm"
          },
          {
            "label": "180 × 200",
            "href": "Kategorie_Matrace_matrace-180x200.dc.html",
            "url": "/matrace/matrace-180x200/",
            "h1": "Matrace 180×200 cm"
          },
          {
            "label": "200 × 200",
            "href": "Kategorie_Matrace_matrace-200x200.dc.html",
            "url": "/matrace/matrace-200x200/",
            "h1": "Matrace 200×200 cm"
          },
          {
            "label": "Matrace na míru",
            "href": "Kategorie_Matrace_matrace-na-miru.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Matrace podle tvrdosti",
        "href": "Kategorie_Matrace_Tuhost.dc.html",
        "url": "/matrace/matrace-podle-tvrdosti/",
        "h1": "Matrace podle tvrdosti",
        "image": "/_blob/45ceef241f2bd0f41d022267c01370de",
        "chips": "hardness",
        "items": [
          {
            "label": "Velmi měkké (1/5)",
            "href": "Kategorie_Matrace_velmi-mekke-matrace.dc.html",
            "url": "/matrace/matrace-podle-tvrdosti/velmi-mekke-matrace/",
            "h1": "Velmi měkké matrace",
            "note": "do 60 kg"
          },
          {
            "label": "Měkké (2/5)",
            "href": "Kategorie_Matrace_mekke-matrace.dc.html",
            "url": "/matrace/matrace-podle-tvrdosti/mekke-matrace/",
            "h1": "Měkké matrace",
            "note": "60–80 kg"
          },
          {
            "label": "Středně tvrdé (3/5)",
            "href": "Kategorie_Matrace_stredne-tvrde-matrace.dc.html",
            "url": "/matrace/matrace-podle-tvrdosti/stredne-tvrde-matrace/",
            "h1": "Středně tvrdé matrace",
            "note": "75–100 kg"
          },
          {
            "label": "Tvrdé (4/5)",
            "href": "Kategorie_Matrace_tvrde-matrace.dc.html",
            "url": "/matrace/matrace-podle-tvrdosti/tvrde-matrace/",
            "h1": "Tvrdé matrace",
            "note": "90–120 kg"
          },
          {
            "label": "Velmi tvrdé (5/5)",
            "href": "Kategorie_Matrace_velmi-tvrde-matrace.dc.html",
            "url": "/matrace/matrace-podle-tvrdosti/velmi-tvrde-matrace/",
            "h1": "Velmi tvrdé matrace",
            "note": "nad 120 kg"
          },
          {
            "label": "Matrace pro páry",
            "href": "Kategorie_Matrace_matrace-pro-pary.dc.html",
            "url": "/matrace/matrace-pro-pary/",
            "h1": "Matrace pro páry – Spring Variant"
          },
          {
            "label": "30 nocí jistoty",
            "href": "Kategorie_Matrace_30-noci-jistoty-vymena-tvrdosti.dc.html",
            "url": "/matrace/30-noci-jistoty-vymena-tvrdosti/",
            "h1": "Matrace s výměnou tvrdosti – 30 nocí jistoty",
            "tip": true
          }
        ]
      },
      {
        "title": "Matrace podle typu",
        "href": "Kategorie_Matrace_matrace-podle-typu-materialu.dc.html",
        "url": "/matrace/matrace-podle-typu-materialu/",
        "h1": "Matrace podle typu a materiálu",
        "image": "/_blob/4d39f39f3e59f9479b2f3fa0c249def9",
        "items": [
          {
            "label": "Pěnové matrace",
            "href": "Kategorie_Matrace_penove.dc.html",
            "url": "/matrace/matrace-podle-typu-materialu/penove/",
            "h1": "Matrace z klasických i studených pěn"
          },
          {
            "label": "Z paměťové (líné) pěny",
            "href": "Kategorie_Matrace_s-pametovou-penou.dc.html",
            "url": "/matrace/matrace-podle-typu-materialu/s-pametovou-penou/",
            "h1": "Matrace s paměťovou pěnou"
          },
          {
            "label": "Latexové matrace",
            "href": "Kategorie_Matrace_latexove.dc.html",
            "url": "/matrace/matrace-podle-typu-materialu/latexove/",
            "h1": "Latexové matrace"
          },
          {
            "label": "Pružinové a taštičkové matrace",
            "href": "Kategorie_Matrace_pruzinove-a-tastickove.dc.html",
            "url": "/matrace/matrace-podle-typu-materialu/pruzinove-a-tastickove/",
            "h1": "Pružinové a taštičkové matrace"
          },
          {
            "label": "Hybridní matrace",
            "href": "Kategorie_Matrace_hybridni.dc.html",
            "url": "/matrace/matrace-podle-typu-materialu/hybridni/",
            "h1": "Hybridní matrace"
          }
        ]
      },
      {
        "title": "Prémiové řady matrací",
        "href": "Kategorie_Matrace_premiove-matrace.dc.html",
        "url": "/matrace/premiove-matrace/",
        "h1": "Prémiové matrace",
        "image": "/_blob/4a0a7adf8f13ddf960536da06df0e197",
        "items": [
          {
            "label": "ELARA",
            "href": "Kategorie_Matrace_premiove-matrace-elara.dc.html",
            "url": "/matrace/premiove-matrace-elara/",
            "h1": "Prémiové matrace ELARA"
          },
          {
            "label": "X AIR",
            "href": "Kategorie_Matrace_premiove-matrace-x-air.dc.html",
            "url": "/matrace/premiove-matrace-x-air/",
            "h1": "Prémiové matrace X AIR"
          },
          {
            "label": "Don Almohadon",
            "href": "Kategorie_Matrace_matrace-donalmohadon.dc.html",
            "url": "/matrace/matrace-donalmohadon/",
            "h1": "Matrace Don Almohadon"
          }
        ]
      },
      {
        "title": "Dětské matrace",
        "href": "Kategorie_Matrace_detske-matrace.dc.html",
        "url": "/matrace/detske-matrace/",
        "h1": "Dětské matrace – bezpečný a zdravý spánek",
        "image": "/_blob/07bc55f2015dcf39ce949009661b22e5",
        "items": [
          {
            "label": "Matrace do postýlky (120×60, 140×70)",
            "href": "Kategorie_Matrace_matrace-do-postylky.dc.html",
            "url": "/matrace/matrace-do-postylky/",
            "h1": "Matrace do dětské postýlky"
          },
          {
            "label": "Dětské matrace 90×200",
            "href": "Kategorie_Matrace_detske-matrace-90x200.dc.html",
            "url": "/matrace/detske-matrace-90x200/",
            "h1": "Dětské matrace 90×200"
          }
        ]
      },
      {
        "title": "Zdravotní a ortopedické matrace",
        "href": "Kategorie_Matrace_zdravotni-a-ortopedicke-matrace.dc.html",
        "url": "/matrace/zdravotni-a-ortopedicke-matrace/",
        "h1": "Zdravotní a ortopedické matrace",
        "image": "/_blob/c2606f1b288878aa84129b4a0e05ba7e",
        "items": [
          {
            "label": "Matrace pro seniory",
            "href": "Kategorie_Matrace_matrace-pro-seniory.dc.html",
            "url": "/matrace/matrace-pro-seniory/",
            "h1": "Matrace pro seniory"
          },
          {
            "label": "Matrace pro alergiky",
            "href": "Kategorie_Matrace_matrace-pro-alergiky.dc.html",
            "url": "/matrace/matrace-pro-alergiky/",
            "h1": "Antimikrobiální matrace pro alergiky"
          },
          {
            "label": "Antidekubitní matrace",
            "href": "Kategorie_Matrace_antidekubitni-matrace.dc.html",
            "url": "/matrace/antidekubitni-matrace/",
            "h1": "Antidekubitní matrace"
          }
        ]
      },
      {
        "title": "Matrace na míru",
        "href": "Kategorie_Matrace_matrace-na-miru.dc.html",
        "url": "/matrace/matrace-na-miru/",
        "h1": "Matrace na míru",
        "image": "/_blob/8860acf4350f39ab0ea34f48a9d72851",
        "items": [
          {
            "label": "Atypické rozměry na cm přesně",
            "href": "Kategorie_Matrace_atypicke-rozmery.dc.html",
            "url": "/matrace/matrace-na-miru/atypicke-rozmery/",
            "h1": "Matrace v atypických rozměrech"
          }
        ]
      },
      {
        "title": "Vrchní matrace – toppery",
        "href": "Kategorie_Matrace_topper-horni-matrace.dc.html",
        "url": "/matrace/topper-horni-matrace/",
        "h1": "Toppery – vrchní matrace",
        "image": "/_blob/fa5dc64795adbb3562001198ab8cbb6c",
        "items": []
      },
      {
        "title": "Chrániče a potahy na matrace",
        "href": "Kategorie_Matrace_chranice-a-potahy.dc.html",
        "url": "/matrace/chranice-a-potahy/",
        "h1": "Chrániče a potahy na matrace",
        "image": "/_blob/f76e3488c27e0ec87274eb26193c8c4f",
        "items": [
          {
            "label": "Chrániče matrací",
            "href": "Kategorie_Matrace_chranice-matraci.dc.html",
            "url": "/matrace/chranice-matraci/",
            "h1": "Chrániče matrací"
          },
          {
            "label": "Potahy na matrace",
            "href": "Kategorie_Matrace_potahy.dc.html",
            "url": "/matrace/potahy/",
            "h1": "Náhradní potahy na matrace"
          },
          {
            "label": "Prostěradla",
            "href": "Kategorie_Luzkoviny_prosteradla.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Matrace podle ceny",
        "href": "Kategorie_Matrace_podle-ceny.dc.html",
        "url": "/matrace/podle-ceny/",
        "h1": "Matrace podle ceny",
        "image": "/_blob/07f8c5b5e2a4828165f983ac25f0e1d8",
        "items": [
          {
            "label": "Matrace v akci",
            "href": "Kategorie_Matrace_akcni-matrace.dc.html",
            "url": "/akce/akcni-matrace/",
            "h1": "Matrace v akci"
          },
          {
            "label": "Levné matrace",
            "href": "Kategorie_Matrace_levne-matrace.dc.html",
            "url": "/matrace/levne-matrace/",
            "h1": "Levné matrace"
          }
        ]
      }
    ]
  },
  {
    "label": "Rošty",
    "slug": "rosty",
    "href": "Kategorie_Rosty.dc.html",
    "url": "/lamelove-rosty/",
    "image": "/_blob/e58c131539e8ad6860c8e14b3cb0959a",
    "all": {
      "label": "Zobrazit všechny rošty",
      "href": "Kategorie_Rosty.dc.html"
    },
    "top": [
      {
        "kind": "promo",
        "label": "Postel s matrací a roštem",
        "sub": "Komplet se slevou",
        "href": "Kategorie_Komplety_komplet-postel-s-matracemi.dc.html",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd"
      },
      {
        "kind": "article",
        "title": "Lamelový rošt – jak ho vybrat k matraci",
        "href": "https://blog.svetspanku.cz/jak-vybrat-lamelovy-rost",
        "image": "/_blob/caad26ab5789e17cd9a815e694427300"
      }
    ],
    "groups": [
      {
        "title": "Rošty podle rozměru",
        "href": "Kategorie_Rosty_podle-rozmeru.dc.html",
        "url": "/lamelove-rosty/podle-rozmeru/",
        "h1": "Rošty podle rozměru",
        "image": "/_blob/9459bc77080c613fe49b26658905c0d9",
        "chips": "sizes",
        "items": [
          {
            "label": "80 × 200",
            "href": "Kategorie_Rosty_rost-80x200.dc.html",
            "url": "/lamelove-rosty/rost-80x200/",
            "h1": "Rošty 80×200 cm"
          },
          {
            "label": "90 × 200",
            "href": "Kategorie_Rosty_rost-90x200.dc.html",
            "url": "/lamelove-rosty/rost-90x200/",
            "h1": "Rošty 90×200 cm"
          },
          {
            "label": "100 × 200",
            "href": "Kategorie_Rosty_rost-100x200.dc.html",
            "url": "/lamelove-rosty/rost-100x200/",
            "h1": "Rošty 100×200 cm"
          },
          {
            "label": "120 × 200",
            "href": "Kategorie_Rosty_rost-120x200.dc.html",
            "url": "/lamelove-rosty/rost-120x200/",
            "h1": "Rošty 120×200 cm"
          },
          {
            "label": "140 × 200",
            "href": "Kategorie_Rosty_rost-140x200.dc.html",
            "url": "/lamelove-rosty/rost-140x200/",
            "h1": "Rošty 140×200 cm"
          },
          {
            "label": "160 × 200",
            "href": "Kategorie_Rosty_rost-160x200.dc.html",
            "url": "/lamelove-rosty/rost-160x200/",
            "h1": "Rošty 160×200 cm"
          },
          {
            "label": "180 × 200",
            "href": "Kategorie_Rosty_rost-180x200.dc.html",
            "url": "/lamelove-rosty/rost-180x200/",
            "h1": "Rošty 180×200 cm"
          },
          {
            "label": "Atypické rozměry",
            "href": "Kategorie_Rosty_rosty-na-miru.dc.html",
            "url": "/lamelove-rosty/rosty-na-miru/",
            "h1": "Rošty na míru"
          }
        ]
      },
      {
        "title": "Lamelové rošty pevné",
        "href": "Kategorie_Rosty_lamelove-rosty-pevne.dc.html",
        "url": "/lamelove-rosty/lamelove-rosty-pevne/",
        "h1": "Lamelové rošty pevné",
        "image": "/_blob/caad26ab5789e17cd9a815e694427300",
        "items": []
      },
      {
        "title": "Polohovací rošty",
        "href": "Kategorie_Rosty_lamelove-rosty-polohovaci.dc.html",
        "url": "/lamelove-rosty/lamelove-rosty-polohovaci/",
        "h1": "Polohovací lamelové rošty",
        "image": "/_blob/c4327c896c3672f1649ca99f1ecbface",
        "items": [
          {
            "label": "Manuálně polohovací",
            "href": "Kategorie_Rosty_manualne-polohovaci.dc.html",
            "url": "/lamelove-rosty/lamelove-rosty-polohovaci/manualne-polohovaci/",
            "h1": "Manuálně polohovací rošty"
          },
          {
            "label": "Elektricky polohovací",
            "href": "Kategorie_Rosty_lamelove-rosty-motorove.dc.html",
            "url": "/lamelove-rosty/lamelove-rosty-motorove/",
            "h1": "Elektricky polohovací (motorové) rošty"
          }
        ]
      },
      {
        "title": "Laťkové rošty",
        "href": "Kategorie_Rosty_latkove-rosty.dc.html",
        "url": "/lamelove-rosty/latkove-rosty/",
        "h1": "Laťkové rošty z masivu",
        "image": "/_blob/148aa05c1d8a1cefe0b02ab8da11bd39",
        "items": []
      },
      {
        "title": "Výklopné rošty (pro úložný prostor)",
        "href": "Kategorie_Rosty_vyklopne-rosty.dc.html",
        "url": "/lamelove-rosty/vyklopne-rosty/",
        "h1": "Výklopné rošty pro úložný prostor",
        "image": "/_blob/ae20c1cf530a2d75d099855576fc8afb",
        "items": []
      }
    ]
  },
  {
    "label": "Výhodné komplety / sety",
    "slug": "komplety",
    "href": "Kategorie_Komplety.dc.html",
    "url": "/komplety-akce/",
    "image": "/_blob/dfd6a27a2785e850d62aedd773271533",
    "all": {
      "label": "Zobrazit všechny komplety",
      "href": "Kategorie_Komplety.dc.html"
    },
    "short": "Komplety / sety",
    "top": [
      {
        "kind": "promo",
        "label": "Ušetříte až 30 %",
        "sub": "Oproti nákupu zvlášť",
        "href": "Kategorie_Komplety.dc.html",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd"
      }
    ],
    "groups": [
      {
        "title": "Komplety podle ceny",
        "href": "Kategorie_Komplety_podle-ceny.dc.html",
        "url": "/komplety-akce/podle-ceny/",
        "h1": "Komplety podle ceny",
        "image": "/_blob/bec57053bba98acc27cb6181af2ecaf2",
        "chips": "prices",
        "items": [
          {
            "label": "do 22 000 Kč",
            "href": "Kategorie_Komplety_do-22000.dc.html",
            "url": "/komplety-akce/do-22000/",
            "h1": "Komplety postelí s matracemi do 22 000 Kč"
          },
          {
            "label": "22 000 – 33 000 Kč",
            "href": "Kategorie_Komplety_do-33000.dc.html",
            "url": "/komplety-akce/do-33000/",
            "h1": "Komplety postelí s matracemi 22 000 – 33 000 Kč"
          },
          {
            "label": "33 000 – 44 000 Kč",
            "href": "Kategorie_Komplety_do-44000.dc.html",
            "url": "/komplety-akce/do-44000/",
            "h1": "Komplety postelí s matracemi 33 000 – 44 000 Kč"
          },
          {
            "label": "nad 44 000 Kč",
            "href": "Kategorie_Komplety_nad-44000.dc.html",
            "url": "/komplety-akce/nad-44000/",
            "h1": "Luxusní komplety postelí s matracemi"
          }
        ]
      },
      {
        "title": "Postel s matrací a roštem",
        "href": "Kategorie_Komplety_komplet-postel-s-matracemi.dc.html",
        "url": "/komplety-akce/komplet-postel-s-matracemi/",
        "h1": "Postel s matrací a roštem – komplety z masivu",
        "image": "/_blob/e181d2d2331563a8f08a99e8cf1cf922",
        "items": []
      },
      {
        "title": "Postel s úložným prostorem, matrací a roštem",
        "href": "Kategorie_Komplety_komplet-s-uloznym-prostorem.dc.html",
        "url": "/komplety-akce/komplet-s-uloznym-prostorem/",
        "h1": "Postele s úložným prostorem, matrací a roštem",
        "image": "/_blob/cd65ef2d3ec37b4c44ea9c75fb27e464",
        "items": []
      },
      {
        "title": "Dětské a patrové komplety",
        "href": "Kategorie_Komplety_detske-a-patrove-komplety.dc.html",
        "url": "/komplety-akce/detske-a-patrove-komplety/",
        "h1": "Dětské a patrové komplety",
        "image": "/_blob/796b776bdf1d4a9bf31b094689547727",
        "items": []
      },
      {
        "title": "Set ložnice",
        "href": "Kategorie_Komplety_set-loznice.dc.html",
        "url": "/komplety-akce/set-loznice/",
        "h1": "Ložnice z masivu jako set",
        "image": "/_blob/7a6c0d5d8c766981b00a382d2267e2e9",
        "items": []
      }
    ]
  },
  {
    "label": "Nábytek",
    "slug": "nabytek",
    "href": "Kategorie_Nabytek.dc.html",
    "url": "/nabytek/",
    "image": "/_blob/62799eee782850a7f388b83455378566",
    "all": {
      "label": "Zobrazit veškerý nábytek",
      "href": "Kategorie_Nabytek.dc.html"
    },
    "top": [
      {
        "kind": "promo",
        "label": "Ložnice na míru",
        "sub": "Ve stejném provedení jako postel",
        "href": "Kategorie_Komplety_set-loznice.dc.html",
        "image": "/_blob/7a6c0d5d8c766981b00a382d2267e2e9"
      }
    ],
    "groups": [
      {
        "title": "Komody",
        "href": "Kategorie_Nabytek_komody.dc.html",
        "url": "/nabytek/komody/",
        "h1": "Komody z masivu",
        "image": "/_blob/80504e0c5537776dfec28cc850910a33",
        "items": [
          {
            "label": "Komody se zásuvkami",
            "href": "Kategorie_Nabytek_komody-se-zasuvkami.dc.html",
            "url": "/nabytek/komody/komody-se-zasuvkami/",
            "h1": "Komody se zásuvkami z masivu"
          },
          {
            "label": "Komody s dveřmi",
            "href": "Kategorie_Nabytek_komody-s-dvermi.dc.html",
            "url": "/nabytek/komody/komody-s-dvermi/",
            "h1": "Komody s dveřmi z masivu"
          },
          {
            "label": "Závěsné komody a skříňky",
            "href": "Kategorie_Nabytek_zavesne-komody-a-skrinky.dc.html",
            "url": "/nabytek/komody/zavesne-komody-a-skrinky/",
            "h1": "Závěsné komody a skříňky z masivu"
          }
        ]
      },
      {
        "title": "Noční stolky",
        "href": "Kategorie_Nabytek_nocni-stolky-a-police.dc.html",
        "url": "/nabytek/nocni-stolky-a-police/",
        "h1": "Noční stolky z masivu",
        "image": "/_blob/4b2059e6dadbe71156efdb3f588066fc",
        "items": [
          {
            "label": "Se zásuvkami",
            "href": "Kategorie_Nabytek_se-zasuvkami.dc.html",
            "url": "/nabytek/nocni-stolky-a-police/se-zasuvkami/",
            "h1": "Noční stolky se zásuvkami"
          },
          {
            "label": "Bez zásuvek",
            "href": "Kategorie_Nabytek_bez-zasuvek.dc.html",
            "url": "/nabytek/nocni-stolky-a-police/bez-zasuvek/",
            "h1": "Noční stolky bez zásuvek"
          },
          {
            "label": "Závěsné noční stolky (na zeď)",
            "href": "Kategorie_Nabytek_zavesne-nocni-stolky.dc.html",
            "url": "/nabytek/nocni-stolky-a-police/zavesne-nocni-stolky/",
            "h1": "Noční stolky závěsné noční stolky (na zeď)"
          },
          {
            "label": "Police na zeď",
            "href": "Kategorie_Nabytek_police-na-zed.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Šatní skříně",
        "href": "Kategorie_Nabytek_skrine.dc.html",
        "url": "/nabytek/skrine/",
        "h1": "Šatní skříně z masivu",
        "image": "/_blob/311377c54f3cf43b42a16264b6070c4e",
        "items": [
          {
            "label": "Skříně s posuvnými dveřmi",
            "href": "Kategorie_Nabytek_s-posuvnymi-dvermi.dc.html",
            "url": "/nabytek/skrine/s-posuvnymi-dvermi/",
            "h1": "Skříně s posuvnými dveřmi z masivu"
          },
          {
            "label": "Samostatné skříně",
            "href": "Kategorie_Nabytek_samostatne-skrine.dc.html",
            "url": "/nabytek/skrine/samostatne-skrine/",
            "h1": "Samostatné skříně z masivu"
          }
        ]
      },
      {
        "title": "Police na zeď",
        "href": "Kategorie_Nabytek_police-na-zed.dc.html",
        "url": "/nabytek/police-na-zed/",
        "h1": "Police na zeď z masivu",
        "image": "/_blob/e7b7e510b4570b10bfe4f7781fc86381",
        "items": []
      },
      {
        "title": "Dětský nábytek",
        "href": "Kategorie_Nabytek_detsky-nabytek.dc.html",
        "url": "/nabytek/detsky-nabytek/",
        "h1": "Dětský nábytek z masivu",
        "image": "/_blob/247d462892685cbb4f5bc53bcd685cf0",
        "items": [
          {
            "label": "Dětské komody a skříně",
            "href": "Kategorie_Nabytek_detske-komody-a-skrine.dc.html",
            "url": "/nabytek/detsky-nabytek/detske-komody-a-skrine/",
            "h1": "Dětské komody a skříně z masivu"
          },
          {
            "label": "Závěsné police a skříňky",
            "href": "Kategorie_Nabytek_zavesne-police-a-skrinky.dc.html",
            "url": "/nabytek/detsky-nabytek/zavesne-police-a-skrinky/",
            "h1": "Závěsné police a skříňky z masivu"
          },
          {
            "label": "Dětské postele",
            "href": "Kategorie_Postele_detske-postele.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Doplňky do ložnice",
        "href": "Kategorie_Nabytek_doplnky-do-loznice.dc.html",
        "url": "/nabytek/doplnky-do-loznice/",
        "h1": "Doplňky do ložnice z masivu",
        "image": "/_blob/c06d0fd482a030df86a79ec2deabcab6",
        "items": [
          {
            "label": "Zrcadla",
            "href": "Kategorie_Nabytek_zrcadla.dc.html",
            "url": "/nabytek/zrcadla/",
            "h1": "Zrcadla v masivním rámu"
          },
          {
            "label": "Hodiny",
            "href": "Kategorie_Nabytek_hodiny.dc.html",
            "url": "/nabytek/hodiny/",
            "h1": "Dřevěné hodiny z masivu"
          }
        ]
      }
    ]
  },
  {
    "label": "Polštáře a přikrývky",
    "slug": "polstare",
    "href": "Kategorie_Polstare.dc.html",
    "url": "/polstare-a-prikryvky/",
    "image": "/_blob/4a1cc5a91262d28ed593605cf4ab8f26",
    "all": {
      "label": "Zobrazit všechny polštáře a přikrývky",
      "href": "Kategorie_Polstare.dc.html"
    },
    "top": [
      {
        "kind": "guide",
        "label": "Jak vybrat polštář",
        "sub": "Průvodce na blogu",
        "href": "Clanek.dc.html"
      },
      {
        "kind": "promo",
        "label": "Polštář patří pod hlavu, ne pod ramena",
        "sub": "Proč doporučujeme 40 × 70",
        "href": "Clanek.dc.html",
        "image": "/_blob/70bc87f80d300e8a2f6bda4666194268"
      }
    ],
    "groups": [
      {
        "title": "Polštáře podle rozměru",
        "href": "Kategorie_Polstare_podle-rozmeru.dc.html",
        "url": "/polstare-a-prikryvky/podle-rozmeru/",
        "h1": "Polštáře podle rozměru",
        "image": "/_blob/4a1cc5a91262d28ed593605cf4ab8f26",
        "items": [
          {
            "label": "40 × 70 – doporučujeme",
            "href": "Kategorie_Polstare_polstare-40x70.dc.html",
            "url": "/polstare-a-prikryvky/polstare-40x70/",
            "h1": "Polštáře 40×70 cm",
            "tip": true
          },
          {
            "label": "70 × 90 – klasický rozměr",
            "href": "Kategorie_Polstare_polstare-70x90.dc.html",
            "url": "/polstare-a-prikryvky/polstare-70x90/",
            "h1": "Polštáře 70×90 cm"
          },
          {
            "label": "Povlaky na polštář 40 × 70",
            "href": "Kategorie_Luzkoviny_povlaky-40x70.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Polštáře podle potřeby",
        "href": "Kategorie_Polstare_podle-potreby.dc.html",
        "url": "/polstare-a-prikryvky/podle-potreby/",
        "h1": "Polštáře podle potřeby",
        "image": "/_blob/70bc87f80d300e8a2f6bda4666194268",
        "items": [
          {
            "label": "Na krční páteř",
            "href": "Kategorie_Polstare_polstare-na-krcni-pater.dc.html",
            "url": "/polstare-a-prikryvky/polstare-na-krcni-pater/",
            "h1": "Polštáře na krční páteř"
          },
          {
            "label": "Na spaní na boku",
            "href": "Kategorie_Polstare_polstare-na-spani-na-boku.dc.html",
            "url": "/polstare-a-prikryvky/polstare-na-spani-na-boku/",
            "h1": "Polštáře na spaní na boku"
          },
          {
            "label": "Článek: Chrápání a spánková apnoe",
            "href": "Clanek.dc.html",
            "link": true
          }
        ]
      },
      {
        "title": "Polštáře podle typu",
        "href": "Kategorie_Polstare_podle-typu.dc.html",
        "url": "/polstare-a-prikryvky/podle-typu/",
        "h1": "Polštáře podle typu",
        "image": "/_blob/4a1cc5a91262d28ed593605cf4ab8f26",
        "items": [
          {
            "label": "Anatomické z paměťové pěny",
            "href": "Kategorie_Polstare_anatomicke-a-ortopedicke-polstare.dc.html",
            "url": "/polstare-a-prikryvky/anatomicke-a-ortopedicke-polstare/",
            "h1": "Anatomické a ortopedické polštáře z paměťové pěny"
          },
          {
            "label": "Klasické polštáře",
            "href": "Kategorie_Polstare_klasicke-polstare.dc.html",
            "url": "/polstare-a-prikryvky/klasicke-polstare/",
            "h1": "Klasické polštáře"
          },
          {
            "label": "Dětské polštáře",
            "href": "Kategorie_Polstare_detske-polstare.dc.html",
            "url": "/polstare-a-prikryvky/detske-polstare/",
            "h1": "Dětské polštáře"
          },
          {
            "label": "Antialergické polštáře",
            "href": "Kategorie_Polstare_antialergicke-polstare.dc.html",
            "url": "/polstare-a-prikryvky/antialergicke-polstare/",
            "h1": "Antialergické polštáře"
          },
          {
            "label": "Dekorační polštáře",
            "href": "Kategorie_Polstare_dekoracni-polstare.dc.html",
            "url": "/polstare-a-prikryvky/dekoracni-polstare/",
            "h1": "Dekorační polštáře"
          }
        ]
      },
      {
        "title": "Přikrývky",
        "href": "Kategorie_Polstare_prikryvky.dc.html",
        "url": "/polstare-a-prikryvky/prikryvky/",
        "h1": "Přikrývky",
        "image": "/_blob/e8917fef009de5a2b6aa618b6eab274f",
        "items": [
          {
            "label": "Sety přikrývka + polštář (1+1)",
            "href": "Kategorie_Polstare_sety-prikryvka-polstar.dc.html",
            "url": "/polstare-a-prikryvky/sety-prikryvka-polstar/",
            "h1": "Sety přikrývka a polštář"
          }
        ]
      },
      {
        "title": "Kolekce polštářů a přikrývek",
        "href": "Kategorie_Polstare_kolekce.dc.html",
        "url": "/polstare-a-prikryvky/kolekce/",
        "h1": "Kolekce polštářů a přikrývek",
        "image": "/_blob/9135676a05058510e7559225139ecd5d",
        "items": [
          {
            "label": "Bamboo – termoregulace",
            "href": "Kategorie_Polstare_kolekce-bamboo.dc.html",
            "url": "/polstare-a-prikryvky/kolekce-bamboo/",
            "h1": "Kolekce Bamboo"
          },
          {
            "label": "Antimikrobial Washable – pro alergiky",
            "href": "Kategorie_Polstare_kolekce-antimikrobial-washable.dc.html",
            "url": "/polstare-a-prikryvky/kolekce-antimikrobial-washable/",
            "h1": "Kolekce Antimikrobial Washable"
          },
          {
            "label": "Carbon Antistress – klidný spánek",
            "href": "Kategorie_Polstare_kolekce-carbon-antistress.dc.html",
            "url": "/polstare-a-prikryvky/kolekce-carbon-antistress/",
            "h1": "Kolekce Carbon Antistress"
          },
          {
            "label": "Aloe Vera",
            "href": "Kategorie_Polstare_kolekce-aloe-vera.dc.html",
            "url": "/polstare-a-prikryvky/kolekce-aloe-vera/",
            "h1": "Kolekce Aloe Vera"
          },
          {
            "label": "Cirrus – pro ty, kdo se potí",
            "href": "Kategorie_Polstare_kolekce-cirrus.dc.html",
            "url": "/polstare-a-prikryvky/kolekce-cirrus/",
            "h1": "Kolekce Cirrus"
          },
          {
            "label": "HEMPhoria – konopná",
            "href": "Kategorie_Polstare_kolekce-hemphoria.dc.html",
            "url": "/polstare-a-prikryvky/kolekce-hemphoria/",
            "h1": "Kolekce HEMPhoria"
          }
        ]
      }
    ]
  },
  {
    "label": "Povlečení a prostěradla",
    "slug": "luzkoviny",
    "href": "Kategorie_Luzkoviny.dc.html",
    "url": "/povleceni-a-prosteradla/",
    "image": "/_blob/e6e0d367624dc2976eb51684c3aafedb",
    "all": {
      "label": "Zobrazit všechna povlečení a prostěradla",
      "href": "Kategorie_Luzkoviny.dc.html"
    },
    "top": [
      {
        "kind": "article",
        "title": "Jak vybrat povlečení",
        "href": "https://blog.svetspanku.cz/jak-vybrat-povleceni",
        "image": "/_blob/e6e0d367624dc2976eb51684c3aafedb"
      },
      {
        "kind": "article",
        "title": "Roztoči v posteli a alergie",
        "href": "https://blog.svetspanku.cz/roztoci-a-alergie-v-posteli",
        "image": "/_blob/8a390213d7a03de388b2726d4453c347"
      }
    ],
    "groups": [
      {
        "title": "Povlečení",
        "href": "Kategorie_Luzkoviny_povleceni.dc.html",
        "url": "/povleceni-a-prosteradla/povleceni/",
        "h1": "Povlečení",
        "image": "/_blob/56aa44a9fe077e9955c51f753cc8f0e7",
        "items": [
          {
            "label": "Jednobarevné (one COLOR)",
            "href": "Kategorie_Luzkoviny_jednobarevne-povleceni.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/jednobarevne-povleceni/",
            "h1": "Jednobarevné povlečení"
          },
          {
            "label": "Povlečení se vzorem",
            "href": "Kategorie_Luzkoviny_povleceni-se-vzorem.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/povleceni-se-vzorem/",
            "h1": "Povlečení se vzorem"
          },
          {
            "label": "Dětské povlečení",
            "href": "Kategorie_Luzkoviny_detske-povleceni.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/detske-povleceni/",
            "h1": "Dětské povlečení"
          },
          {
            "label": "Dárkové sety povlečení",
            "href": "Kategorie_Luzkoviny_darkove-sety-povleceni.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/darkove-sety-povleceni/",
            "h1": "Dárkové sety povlečení"
          },
          {
            "label": "Prodloužené povlečení (140×220)",
            "href": "Kategorie_Luzkoviny_prodlouzene-povleceni.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/prodlouzene-povleceni/",
            "h1": "Prodloužené povlečení 140×220"
          }
        ]
      },
      {
        "title": "Povlečení podle materiálu",
        "href": "Kategorie_Luzkoviny_povleceni-podle-materialu.dc.html",
        "url": "/povleceni-a-prosteradla/povleceni-podle-materialu/",
        "h1": "Povlečení podle materiálu",
        "image": "/_blob/e6e0d367624dc2976eb51684c3aafedb",
        "items": [
          {
            "label": "Bavlna – renforcé",
            "href": "Kategorie_Luzkoviny_bavlnene-povleceni-renforce.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/bavlnene-povleceni-renforce/",
            "h1": "Bavlněné povlečení renforcé"
          },
          {
            "label": "Bavlna – perkál",
            "href": "Kategorie_Luzkoviny_bavlnene-povleceni-perkal.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/bavlnene-povleceni-perkal/",
            "h1": "Bavlněné povlečení perkál"
          },
          {
            "label": "Satén a mako satén",
            "href": "Kategorie_Luzkoviny_satenove-povleceni.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/satenove-povleceni/",
            "h1": "Saténové povlečení"
          },
          {
            "label": "Flanel",
            "href": "Kategorie_Luzkoviny_flanelove-povleceni.dc.html",
            "url": "/povleceni-a-prosteradla/povleceni/flanelove-povleceni/",
            "h1": "Flanelové povlečení"
          }
        ]
      },
      {
        "title": "Prostěradla",
        "href": "Kategorie_Luzkoviny_prosteradla.dc.html",
        "url": "/povleceni-a-prosteradla/prosteradla/",
        "h1": "Napínací prostěradla",
        "image": "/_blob/8a390213d7a03de388b2726d4453c347",
        "items": [
          {
            "label": "Jersey prostěradla",
            "href": "Kategorie_Luzkoviny_jersey-prosteradla.dc.html",
            "url": "/povleceni-a-prosteradla/prosteradla/jersey-prosteradla/",
            "h1": "Jersey prostěradla"
          },
          {
            "label": "Na vysoké matrace",
            "href": "Kategorie_Luzkoviny_prosteradla-na-vysoke-matrace.dc.html",
            "url": "/povleceni-a-prosteradla/prosteradla/prosteradla-na-vysoke-matrace/",
            "h1": "Prostěradla na vysoké matrace"
          },
          {
            "label": "90 × 200",
            "href": "Kategorie_Luzkoviny_prosteradla-90x200.dc.html",
            "url": "/povleceni-a-prosteradla/prosteradla/prosteradla-90x200/",
            "h1": "Prostěradla 90×200 cm"
          },
          {
            "label": "140 × 200",
            "href": "Kategorie_Luzkoviny_prosteradla-140x200.dc.html",
            "url": "/povleceni-a-prosteradla/prosteradla/prosteradla-140x200/",
            "h1": "Prostěradla 140×200 cm"
          },
          {
            "label": "160 × 200",
            "href": "Kategorie_Luzkoviny_prosteradla-160x200.dc.html",
            "url": "/povleceni-a-prosteradla/prosteradla/prosteradla-160x200/",
            "h1": "Prostěradla 160×200 cm"
          },
          {
            "label": "180 × 200",
            "href": "Kategorie_Luzkoviny_prosteradla-180x200.dc.html",
            "url": "/povleceni-a-prosteradla/prosteradla/prosteradla-180x200/",
            "h1": "Prostěradla 180×200 cm"
          }
        ]
      },
      {
        "title": "Povlaky na polštáře a přikrývky",
        "href": "Kategorie_Luzkoviny_povlaky.dc.html",
        "url": "/povleceni-a-prosteradla/povlaky/",
        "h1": "Povlaky na polštáře a přikrývky",
        "image": "/_blob/9135676a05058510e7559225139ecd5d",
        "items": [
          {
            "label": "Povlaky na polštář 40 × 70",
            "href": "Kategorie_Luzkoviny_povlaky-40x70.dc.html",
            "url": "/povleceni-a-prosteradla/povlaky/povlaky-40x70/",
            "h1": "Povlaky na polštář 40×70",
            "tip": true
          },
          {
            "label": "Povlaky na polštář 70 × 90",
            "href": "Kategorie_Luzkoviny_povlaky-70x90.dc.html",
            "url": "/povleceni-a-prosteradla/povlaky/povlaky-70x90/",
            "h1": "Povlaky na polštář 70×90"
          },
          {
            "label": "Povlaky na přikrývky",
            "href": "Kategorie_Luzkoviny_povlaky-na-prikryvky.dc.html",
            "url": "/povleceni-a-prosteradla/povlaky/povlaky-na-prikryvky/",
            "h1": "Povlaky na přikrývky"
          }
        ]
      },
      {
        "title": "Chrániče a potahy na matrace",
        "href": "Kategorie_Matrace_chranice-a-potahy.dc.html",
        "link": true,
        "image": "/_blob/f76e3488c27e0ec87274eb26193c8c4f",
        "items": []
      }
    ]
  },
  {
    "label": "Akce / Výprodej",
    "slug": "akce",
    "href": "Kategorie_Akce.dc.html",
    "url": "/akce/",
    "image": "/_blob/edd56eee566f1d974d13fb31f14a8118",
    "all": {
      "label": "Zobrazit všechny akce",
      "href": "Kategorie_Akce.dc.html"
    },
    "highlight": true,
    "short": "Akce",
    "top": [],
    "groups": [
      {
        "title": "Aktuální akce",
        "href": "Kategorie_Akce_aktualni-akce.dc.html",
        "url": "/akce/aktualni-akce/",
        "h1": "Aktuální akce",
        "image": "/_blob/edd56eee566f1d974d13fb31f14a8118",
        "items": []
      },
      {
        "title": "Výprodej",
        "href": "Kategorie_Akce_vyprodej.dc.html",
        "url": "/akce/vyprodej/",
        "h1": "Výprodej – poslední kusy za skvělé ceny",
        "image": "/_blob/8b63107c3b3df97b4c67e750ce6b91cd",
        "items": []
      },
      {
        "title": "Novinky",
        "href": "Kategorie_Akce_novinky.dc.html",
        "url": "/novinky/",
        "h1": "Novinky",
        "image": "/_blob/6b546453dfb90e0ec7ddb488eed7e6ec",
        "items": []
      },
      {
        "title": "Dárkový poukaz",
        "href": "Kategorie_Akce_darkovy-poukaz.dc.html",
        "url": "/akce/darkovy-poukaz/",
        "h1": "Dárkový poukaz Světspánku.cz",
        "image": "/_blob/a4bdfc3ddeb575fee8768a3cf2019524",
        "items": []
      },
      {
        "title": "Dárky k nákupu",
        "href": "Kategorie_Akce_darky-k-nakupu.dc.html",
        "url": "/akce/darky-k-nakupu/",
        "h1": "Dárky k nákupu",
        "image": "/_blob/70bc87f80d300e8a2f6bda4666194268",
        "items": []
      },
      {
        "title": "Výhodné komplety",
        "href": "Kategorie_Komplety.dc.html",
        "link": true,
        "image": "/_blob/dfd6a27a2785e850d62aedd773271533",
        "items": []
      }
    ]
  }
];

// Odkazy v horní liště hlavičky (desktop)
export const UTILITY = [
  {
    "label": "Výroba na míru",
    "href": "#vyroba-na-miru"
  },
  {
    "label": "Průvodce výběrem matrace",
    "href": "PruvodceMatrace.dc.html"
  },
  {
    "label": "Prodejny",
    "href": "#prodejny"
  },
  {
    "label": "Kontakty",
    "href": "Kontakty.dc.html"
  }
];

// Rychlé zkratky pod sekcemi v mobilním menu
export const QUICK = [
  {
    "label": "Průvodce výběrem matrace",
    "icon": "help-circle",
    "href": "PruvodceMatrace.dc.html"
  },
  {
    "label": "Prodejny (5)",
    "icon": "map-pin",
    "href": "#prodejny"
  },
  {
    "label": "Výroba na míru",
    "icon": "ruler-2",
    "href": "#vyroba-na-miru"
  },
  {
    "label": "+420 543 212 855",
    "icon": "phone",
    "href": "tel:+420543212855"
  }
];

if (typeof window !== 'undefined') { window.MENU = MENU; window.MENU_UTILITY = UTILITY; window.MENU_QUICK = QUICK; }
